#include "task_data.h"
#include <iostream>
#include <vector>
#include <algorithm>

void delaunay(std::vector<point> &vp, std::vector<triangle> &res){
    int n = vp.size();

    for (int i=0;i<vp.size();i++){
        vp[i].z = vp[i].x*vp[i].x + vp[i].y*vp[i].y;
    }

    int flag = 0;
    for (int i=0;i<n-2;i++){
        for (int j=i+1;j<n;j++){
            for (int k=i+1;k<n;k++){
                if (j!=k){
                    //вычисляем нормаль к треугольнику (i,j,k)
                    double xn = (vp[j].y - vp[i].y) * (vp[k].z - vp[i].z) - (vp[k].y - vp[i].y)*(vp[j].z-vp[i].z);
                    double yn = (vp[k].x - vp[i].x) * (vp[j].z - vp[i].z) - (vp[j].x - vp[i].x)*(vp[k].z-vp[i].z);
                    double zn = (vp[j].x - vp[i].x) * (vp[k].y - vp[i].y) - (vp[k].x - vp[i].x)*(vp[j].y-vp[i].y);

                    //проверяем только грани где zn<0

                    if (flag = (zn<0)){
                        for (int m=0;m<n;m++){
                            flag = flag && ((vp[m].x-vp[i].x)*xn + (vp[m].y-vp[i].y)*yn + (vp[m].z-vp[i].z)*zn <=0);
                        }
                    }

                    if (flag){
                        triangle tr;
                        tr.id_p1 = i;
                        tr.id_p2 = j;
                        tr.id_p3 = k;

                        res.push_back(tr);
                    }
                }
            }
        }
    }
}

/* Краскал */
double distance(point &p1, point &p2){
    return sqrt((p2.x-p1.x)*(p2.x-p1.x) + (p2.y - p1.y)*(p2.y-p1.y));
}

void sort_edge(std::vector<edge_tree> &A){
    int i,j;
    edge_tree temp;
    int n = A.size();

    for(i=0;i<n;i++){
        for(j=0;j<n-1;j++){
            if(A[j].weight > A[j+1].weight){
                temp = A[j];
                A[j] = A[j+1];
                A[j+1] = temp;
            }
        }
    }
}

int search(std::vector<int> &set_vertex, int i, int j){
    if(set_vertex[i]!=set_vertex[j]){
        return 1;
    }
    else {
       return 0;
    }
}


void union_(std::vector<int> &set_vertex, int a, int b, int n){
    for(int i=0;i<n;i++){
        if(set_vertex[i]==b){
            set_vertex[i] = a;
        }
    }
}

bool task_data :: run()
{
    int n = vector_of_points.size();
    std::vector<int> set;
    std::vector<edge_tree> edge_vector;
    delaunay(vector_of_points, triangle_vector);


    for (size_t i = 0; i<triangle_vector.size(); i++){
        edge_tree e1;
        e1.i = triangle_vector[i].id_p1;
        e1.j = triangle_vector[i].id_p2;
        e1.weight = distance(vector_of_points[triangle_vector[i].id_p1],vector_of_points[triangle_vector[i].id_p2]);

        edge_tree e2;
        e2.i = triangle_vector[i].id_p1;
        e2.j = triangle_vector[i].id_p3;
        e2.weight = distance(vector_of_points[triangle_vector[i].id_p1],vector_of_points[triangle_vector[i].id_p3]);

        edge_tree e3;
        e3.i = triangle_vector[i].id_p2;
        e3.j = triangle_vector[i].id_p3;
        e3.weight = distance(vector_of_points[triangle_vector[i].id_p2],vector_of_points[triangle_vector[i].id_p3]);

        edge_vector.push_back(e1);
        edge_vector.push_back(e2);
        edge_vector.push_back(e3);
    }

    for (int i=0;i<n;i++){
        set.push_back(i);
    }

    //через полный граф
    /*for (int i=0;i<n;i++){
        for (int j=0;j<n;j++){
            if (i<=j){
                edge e;
                e.i = i;
                e.j = j;
                e.weight = distance(vector_of_points[i],vector_of_points[j]);
                edge_vector.push_back(e);
            }
        }

        set.push_back(i);
    }*/


    sort_edge(edge_vector);

    double mincost = 0;
    for(int k=0; k<edge_vector.size();k++){
        if (search(set, edge_vector[k].i, edge_vector[k].j)){
                int a = set[edge_vector[k].i];
                int b = set[edge_vector[k].j];
                union_(set,a,b,n);

                mincost = mincost + edge_vector[k].j;
                //std::cout << edge_vector[k].i << " " << edge_vector[k].j << " " << edge_vector[k].weight << std::endl;
                result_vector.push_back(edge_vector[k]);
         }
    }

    //std::cout << mincost << std::endl;

    return true;
}
