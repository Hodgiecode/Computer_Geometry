#ifndef TASK_DATA_H
#define TASK_DATA_H
#include <math.h>
#include <vector>

struct point {
    double x, y, z;
    int id;
    point() { }
    point(double _x, double _y, int _id) : x(_x), y(_y),id(_id) { }
    point operator-(const point& p) const {
        return point(x - p.x, y - p.y, -1);
    }

    double length() { return sqrt(x * x + y * y); }

};


struct triangle {
    int id_p1;
    int id_p2;
    int id_p3;
};


struct edge_tree {
    int i;
    int j;
    double weight;
};

struct task_data {
    std::vector<point> vector_of_points;
    std::vector<edge_tree> result_vector;
    std::vector<triangle> triangle_vector;


    task_data(){

    }

    bool run();
};

#endif // TASK_DATA_H
