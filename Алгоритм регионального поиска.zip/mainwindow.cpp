#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "drawwidget.h"
#include "QMessageBox"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->draw_widget->SetTaskPtr(&current_task);
    ui->draw_widget->SetDefaultPoints();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked(){
    ui->draw_widget->region_point_search();

    QString v1 = QString::fromUtf8(ui->draw_widget->work_time.c_str());
    ui->lineEdit_6->setText(v1);
}


void MainWindow::on_pushButton_4_clicked(){
    ui->draw_widget->region_point_search_bruteforce();

    QString v1 = QString::fromUtf8(ui->draw_widget->work_time.c_str());
    ui->lineEdit_6->setText(v1);
}

void MainWindow::on_pushButton_2_clicked(){
    // инициализация задачи
    ui->draw_widget->clean();
}

void MainWindow::on_pushButton_3_clicked(){
    std::string p = ui->lineEdit->text().toStdString();

    if (p == ""){
        ui->draw_widget->points = 10;
        p = "10";
        QString v1 = QString::fromUtf8(p.c_str());
        ui->lineEdit->setText(v1);
    }

    std::string cx1 = ui->lineEdit_2->text().toStdString();
    std::string cy1 = ui->lineEdit_3->text().toStdString();

    std::string cx2 = ui->lineEdit_4->text().toStdString();
    std::string cy2 = ui->lineEdit_5->text().toStdString();

    if (cx1 == "" || cy1 == "" || cx2 == "" || cy2 == ""){
        ui->draw_widget->coord_x_1 = 200;
        ui->draw_widget->coord_y_1 = 200;

        ui->draw_widget->coord_x_2 = 400;
        ui->draw_widget->coord_y_2 = 400;

        cx1 = "200";
        cy1 = "200";
        cx2 = "400";
        cy2 = "400";

        QString v1 = QString::fromUtf8(cx1.c_str());
        ui->lineEdit_2->setText(v1);

        QString v2 = QString::fromUtf8(cy1.c_str());
        ui->lineEdit_3->setText(v2);

        QString v3 = QString::fromUtf8(cx2.c_str());
        ui->lineEdit_4->setText(v3);

        QString v4 = QString::fromUtf8(cy2.c_str());
        ui->lineEdit_5->setText(v4);
    }

    ui->draw_widget->coord_x_1 = atoi(ui->lineEdit_2->text().toStdString().c_str());
    ui->draw_widget->coord_y_1 = atoi(ui->lineEdit_3->text().toStdString().c_str());
    ui->draw_widget->coord_x_2 = atoi(ui->lineEdit_4->text().toStdString().c_str());
    ui->draw_widget->coord_y_2 = atoi(ui->lineEdit_5->text().toStdString().c_str());

    ui->draw_widget->points = atoi(ui->lineEdit->text().toStdString().c_str());
    ui->draw_widget->create_points();
}
