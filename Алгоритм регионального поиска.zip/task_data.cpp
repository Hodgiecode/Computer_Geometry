#include <iostream>
#include <vector>
#include "task_data.h"
#include <algorithm>

bool rectContains(std::vector<point> &rect, point &pnt){
    int xmin = rect[0].x;
    int xmax = rect[1].x;

    int ymin = rect[0].y;
    int ymax = rect[1].y;

    return ((pnt.x >= xmin && pnt.x <=xmax) && (pnt.y >= ymin && pnt.y <= ymax));
}

node * newNode(point &pnt){
  node * tree_node=(node*) malloc(sizeof(node));

  tree_node->data.x = pnt.x;
  tree_node->data.y = pnt.y;

  tree_node->left=NULL;
  tree_node->right=NULL;
  tree_node->color=true;
  tree_node->size=1;
  return tree_node;
}


node * insert(node * root, int depth, point &pnt){
  if(root==NULL){
     return newNode(pnt);
   }
   else {
      unsigned dimension = depth%2;
      if (dimension == 0){
          if(pnt.x < root->data.x){
             root->left=insert(root->left,depth+1,pnt);
           } else {
            root->right=insert(root->right,depth+1,pnt);
           }
      }

      if (dimension == 1){
          if(pnt.y < root->data.y){
             root->left=insert(root->left,depth+1,pnt);
           } else {
            root->right=insert(root->right,depth+1,pnt);
          }
      }
  }

  return root;
}

bool arePointsSame(point &point1,point &point2){
  if(point1.x!=point2.x && point1.y!=point2.y){
      return false;
  }

  return true;
}

bool search(node* root, point &pnt, size_t depth){
  if(root==NULL)
    return false;

  if(arePointsSame(root->data,pnt))
     return true;

  size_t dimension=depth % 2;
  if (dimension == 0){
    if (pnt.x < root->data.x)
        return search(root->left, pnt, depth + 1);
  }

  if (dimension == 1){
      if (pnt.y < root->data.y){
          return search(root->left, pnt, depth + 1);
      }
  }

  return search(root->right, pnt, depth + 1);
}


void rangeNode(node * root, std::vector<point> &rect,int depth, std::vector<point> &res){
  int xmin = rect[0].x;
  int xmax = rect[1].x;

  int ymin = rect[0].y;
  int ymax = rect[1].y;

  if(root==NULL)
     return;

  if(rectContains(rect,root->data))
     res.push_back(point(root->data.x, root->data.y, -1));

  int cd = depth%2;
  if(cd == 0){
    if(root->data.x > xmin)
        rangeNode(root->left,rect, depth+1, res);

    if(root->data.x <= xmax)
        rangeNode(root->right,rect, depth+1, res);
  }
  else {
    if(root->data.y > ymin){
        rangeNode(root->left,rect, depth+1, res);
    }

    if(root->data.y <= ymax)
        rangeNode(root->right,rect, depth+1, res);
  }
}


double distance (point &point1,point &point2){
   double x=0;
   x=(point1.x-point2.x)*(point1.x-point2.x) + (point1.y-point2.y)*(point1.y-point2.y) ;
   return sqrt(x);
}


node * nearestsearch(node *current,node * nearest, point &pnt){
  if(current==NULL || distance(nearest->data,pnt) < distance(current->data,pnt))
       return nearest;

   if(distance(current->data,pnt) < distance(nearest->data,pnt))
       nearest=current;

    node * nleft=nearestsearch(current->left,nearest,pnt);

    if(distance(nleft->data,pnt) < distance(nearest->data,pnt))
       nearest=nleft;

    node * nright=nearestsearch(current->right,nearest,pnt);
    if(distance(nright->data,pnt) < distance(nearest->data,pnt))
       nearest=nright;

    return nearest;
}

node *nearest(node * root, point &pnt){
  if(root==NULL)
     return NULL;
  return nearestsearch(root,root,pnt);
}


int height(node* node){
   if (node==NULL)
       return 0;
   else {
     int lheight = height(node->left);
     int rheight = height(node->right);

     if (lheight > rheight)
         return(lheight+1);
     else
        return(rheight+1);
   }
}


void printLevel(node* root, int level){
    if(root == NULL)
        return;
    if(level == 1)
        std::cout << root->data.x << " " << root->data.y << std::endl;
    else if (level > 1){
        printLevel(root->left, level-1);
        printLevel(root->right, level-1);
    }
}

void levelorder(node* root){
    int h = height(root);
    int i;
    for(i=1; i<=h; i++){
        printLevel(root, i);
        std::cout << std::endl;
   }
}

void inorder(node *node){
    if (node){
        inorder(node -> left);
        std::cout << node -> data.x << " " << node->data.y << std::endl;
        inorder(node -> right);
    }
}


bool task_data::run(){
    int n = vector_of_points.size();
    node *root = NULL;

    clock_t start = clock();
    for (int i=0; i<n; i++) {
        root = insert(root, 0, vector_of_points[i]);
        root->color=false;
    }

    levelorder(root);

    std::vector<point> r;
    r.push_back(A);
    r.push_back(B);

    rangeNode(root,r,0,result);
    clock_t end = clock();
    work_time = std::to_string((double)(end - start)/CLOCKS_PER_SEC);

    return true;
}

bool task_data::run_bruteforce(){
    clock_t start = clock();
    for (size_t i=0;i<vector_of_points.size();i++){
        if (A.x <= vector_of_points[i].x && B.x >= vector_of_points[i].x &&
            A.y <= vector_of_points[i].y && B.y >= vector_of_points[i].y){
            result.push_back(vector_of_points[i]);
        }
    }

    clock_t end = clock();
    work_time = std::to_string((double)(end - start)/CLOCKS_PER_SEC);
    return true;
}
