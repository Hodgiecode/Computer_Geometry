#include "ray_tracer.h"
#include <math.h>

void read(const char *filename, std::vector<TVec3f> &verts, std::vector<std::vector<int>> &faces){
    std::string m, x,y,z;
    std::ifstream fin(filename);
    std::vector<int> tmp;

    while (fin >> m >> x >> y >> z){
        if (m == "v"){
            verts.push_back(TVec3f(atoi(x.c_str()) , atoi(y.c_str()), atoi(z.c_str())));
        }

        if (m == "f"){
            tmp.push_back(atoi(x.c_str()));
            tmp.push_back(atoi(y.c_str()));
            tmp.push_back(atoi(z.c_str()));

            faces.push_back(tmp);

            tmp.clear();
        }
    }
}

TVec3f crossProduct(TVec3f vect_A, TVec3f vect_B){
    TVec3f cross_P;
    cross_P.x = vect_A.y * vect_B.z - vect_A.z * vect_B.y;
    cross_P.y = vect_A.z * vect_B.x - vect_A.x * vect_B.z;
    cross_P.z = vect_A.x * vect_B.y - vect_A.y * vect_B.x;

    return cross_P;
}

bool trace(const TVec3f &ray_src, const TVec3f &ray_dir,
           const std::vector<TObject*> &objects,
           const TVec3f &P){

    double tT;
    TVec3f tN;
    TVec3f tP;

    for (int q=0;q<objects.size();q++){
         if(objects[q]->IsIntersect(ray_src, ray_dir, tT, tP, tN)){
            return true;
         }
    }

    return false;
}


TVec3f cast_ray(const TVec3f &ray_src, const TVec3f &ray_dir,
             const std::vector<TObject*> &objects,
             const std::vector<Light> &lights, int depth){

    for (size_t q=0;q<objects.size();q++){
        double tT;
        TVec3f tN;
        TVec3f tP;
        TVec3f reflected_color;
        Material mat;

        if(objects[q]->IsIntersect(ray_src, ray_dir, tT, tP, tN)){
             tN.Normalize();
             mat = objects[q]->get_material();
             if (mat.reflectiveness > 0 && depth < 4){
                depth = depth + 1;
                TVec3f reflected = (2.0 * ((-1)*ray_dir * tN)*tN - (-1)*ray_dir);
                reflected.Normalize();

                TVec3f r_f_src = tP + (0.00001 * tN);
                TVec3f r_f_dir = reflected;

                reflected_color = cast_ray(r_f_src, r_f_dir, objects, lights, depth);
             } else {
                reflected_color = TVec3f(0,0,0);
             }

             double diffuse = 0.0;
             double specular = 0.0;
             bool path_obstructed = 0;

             for (int i=0;i<lights.size();i++){
                TVec3f light_dir = lights[i].position - tP;
                light_dir.Normalize();

                if ((tN * light_dir) > 0){
                    double normal_translation_factor = 0.00001;
                    TVec3f shadow_p;
                    path_obstructed = trace(tP +(normal_translation_factor*tN), light_dir, objects, shadow_p);

                    if (path_obstructed){
                        continue;
                    }
                }

                TVec3f reflected_specular = (2.0 * (light_dir * tN)) * tN - light_dir;
                reflected_specular.Normalize();
                double shade = tN * light_dir;
                double specular_reflection = (reflected_specular * (-1)*ray_dir);

                if (shade < 0){
                    shade = 0.0;
                }

                if (specular_reflection < 0){
                    specular_reflection = 0;
                }

                specular_reflection = powf(specular_reflection,mat.shininess) * mat.specular;
                diffuse += (shade * lights[i].intensity);
                specular += (specular_reflection * lights[i].intensity);
             }

             return mat.colour * (diffuse + mat.ambient) + TVec3f(1,1,1) *(!path_obstructed * specular) +
                     (reflected_color * mat.reflectiveness - path_obstructed * TVec3f(0.01,0.01,0.01));
            }
        }

    return TVec3f(0.298, 0.7058, 0.9843);
 }



TVec3f SimpleScene ::  get_pixel(int x, int y, int w, int h){
    double rX = Vw * (x - CCx) / Cw;
    double rY = Vh * (CCy - y) / Ch;

    TVec3f ray_src(rX, rY, Dist);
    TVec3f ray_dir(rX, rY, Dist);

    ray_src.Normalize();
    ray_dir.Normalize();

    int depth = 0;

    std::vector<Light> lv;
    lv.push_back(Light(TVec3f(-1.0, 1.0, 0.0), 1.8));
    lv.push_back(Light(TVec3f(0.0, -1, 5), 1.5));
    lv.push_back(Light(TVec3f(3.0, 2.0, 3.0), 2.0));


    TVec3f c = cast_ray(ray_dir, ray_src, objects, lv, depth);

    double mx = std::max(c.x, std::max(c.y, c.z));
    if (mx > 1){
        c = c * (1.0 / mx);
    }

    c.x = 255 * std::max(0.0, std::min(1.0, c.x));
    c.y = 255 * std::max(0.0, std::min(1.0, c.y));
    c.z = 255 * std::max(0.0, std::min(1.0, c.z));

    return c;
 }

/*--------------- СФЕРЫ -----------------------------*/

bool TSphere :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau)
{

  double A = ray_dir * ray_dir;
  TVec3f v = (ray_src - center);
  double B = ray_dir * v;
  double C = v * v - R * R;

  double D4 = B * B - A * C;

  if(D4 < 0)
    return false;

  double t1 = (- B - sqrt(D4) ) / A;
  double t2 = (-B + sqrt(D4) ) / A;

  if(t1 < 0 && t2 < 0)
    return false;

  else if(t1 < 0)
   tau = t2;
  else
    tau = t1;

  return true;
}

bool TSphere :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl)
{
  if(IsIntersect(ray_src, ray_dir, tau))
  {
    pt = ray_src + tau * ray_dir;
    nl = pt - center;

    nl.Normalize();
    return true;
  }
  return false;
}

/*---------------- КОНУС  ----------------------------*/

bool TCone :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau){

    double eps = 1e-9;

    TVec3f top;
    top.x = center.x;
    top.y = center.y + H;
    top.z = center.z;

    double a = (ray_dir.x * ray_dir.x) + (ray_dir.z * ray_dir.z) - (R/H * R/H) * (ray_dir.y * ray_dir.y);
    double b = 2 *((ray_src.x - center.x) * ray_dir.x + (ray_src.z - center.z) * ray_dir.z -
                   (R/H) * (R/H) *(-H + ray_src.y - center.y) * ray_dir.y);

    double c = -(R/H)*(R/H) *(H - ray_src.y + center.y) * (H - ray_src.y + center.y) +
            (ray_src.x - center.x) * (ray_src.x - center.x) +
            (ray_src.z - center.z) * (ray_src.z - center.z);

    double delta = b*b - (4*a*c);
    if (delta<eps){
        return false;
    }

    double t1 = (-b - sqrt(delta))/(2*a);
    double t2 = (-b + sqrt(delta))/(2*a);

    TVec3f pt = ray_src + t1 * ray_dir;
    if (pt.y >= center.y && pt.y <= center.y + H){
        tau = t1;
        return true;
    }

    pt = ray_src + t2 * ray_dir;
    if (pt.y >= center.y && pt.y <= center.y + H){
        tau = t2;
        return true;
    }

    return false;
}

bool TCone :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl){

    TVec3f top;
    top.x = center.x;
    top.y = center.y + H;
    top.z = center.z;

    double eps = 1e-9;

    if(IsIntersect(ray_src, ray_dir, tau))
    {
      pt = ray_src + tau * ray_dir;
      double alpha = atan2(pt.x - center.x, pt.z - center.z);
      double theta = atan2(R,H);
      nl = TVec3f(sin(alpha) * cos(theta), sin(theta),cos(alpha) * cos(theta));
      nl.Normalize();

      return true;
    }

    return false;
}

/*---------------- ЦИЛИНДР ----------------------------*/

double cap_hit(TVec3f c, TVec3f N, TVec3f ray_src, TVec3f ray_dir, double r) {
    double t = -1;

    double ldotn = ray_dir * N;
    if (ldotn > 0) {
        t = ((c - ray_src)* N) / ldotn;
        TVec3f ip = ray_src + t * ray_dir;
        bool v = (ip - c)*(ip - c) < r*r;
        if (!v) {
            t = -1;
        }
    }

    return t;
}

bool TCylinder :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau){

    TVec3f h = center_top - center_bottom;
    TVec3f a_bottom = ray_src - center_bottom;
    TVec3f a_bottom_h = crossProduct(a_bottom, h);
    TVec3f ray_dir_h = crossProduct(ray_dir, h);

    double h2 = h * h;

    double a = ray_dir_h * ray_dir_h;
    double b = 2 * ray_dir_h * a_bottom_h;
    double c = a_bottom_h * a_bottom_h - (R * R - h2);
    double d = b * b - 4 * a * c;

    tau = -1;
    double t2;

    TVec3f ip;

    if (d>=0){
        tau = (-b - sqrt(d))/(2*a);
        t2 = (-b + sqrt(d))/(2*a);

        if (t2 < tau && t2 >= 0) {
            tau = t2;
        }

        if (tau >=0){
            ip = ray_src + tau * ray_dir;
            TVec3f h_ = center_top - center_bottom;
            bool v = h_ * (ip - center_bottom) > 0 && h_ * (ip - center_top) < 0;
            if (!v){
                tau = -1;
            }
        }
    }

    TVec3f v = ip - center_bottom;
    TVec3f tmp = (v * h * h);
    tmp.x = tmp.x / (h*h);
    tmp.y = tmp.y / (h*h);
    tmp.z = tmp.z / (h*h);

    normal_ = v - tmp;

    TVec3f ncap = center_top - center_bottom;
    double tcap = cap_hit(center_bottom, ncap, ray_src, ray_dir, R);

    if ((tcap >= 0 && tcap < tau) || tau < 0) {
        tau = tcap;
        normal_ = ncap;
    }

    ncap = (center_bottom - center_top);
    tcap = cap_hit(center_top, ncap, ray_src, ray_dir, R);

    if ((tcap >= 0 && tcap < tau) || tau < 0) {
        tau = tcap;
        normal_ = ncap;
    }

    if (tau < 0) {
        return false;
    }

    return true;
}

bool TCylinder :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl){

    if(IsIntersect(ray_src, ray_dir, tau))
    {
       pt = ray_src + tau * ray_dir;
       nl = normal_;
       nl.Normalize();

       return true;
    }

    return false;
}

/*------------------- ТОР ---------------------------*/

bool TTorus :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau){

    TVec3f centerToRayOrigin = ray_src - center;
    double centerToRayOriginDotDirection = ray_dir * centerToRayOrigin;
    double	centerToRayOriginDotDirectionSquared = centerToRayOrigin * centerToRayOrigin;
    double innerRadiusSquared = r * r;
    double outerRadiusSquared = R * R;

    double axisDotCenterToRayOrigin	= axis * centerToRayOrigin;
    double	axisDotRayDirection = axis * ray_dir;
    double	a = 1 - axisDotRayDirection * axisDotRayDirection;
    double	b = 2 * (centerToRayOrigin * ray_dir - axisDotCenterToRayOrigin * axisDotRayDirection);
    double c = centerToRayOriginDotDirectionSquared - axisDotCenterToRayOrigin * axisDotCenterToRayOrigin;
    double	d = centerToRayOriginDotDirectionSquared + outerRadiusSquared - innerRadiusSquared;

    double A = 1;
    double B = 4 * centerToRayOriginDotDirection;
    double C = 2 * d + B * B * 0.25 - 4 * outerRadiusSquared * a;
    double D = B * d - 4 * outerRadiusSquared * b;
    double E = d * d - 4 * outerRadiusSquared * c;


    double a3 = A * A * A;
    double a2 = A * A;
    double b4 = B * B * B * B;
    double b3 = B * B * B;
    double b2 = B * B;
    double c3 = C * C * C;
    double c2 = C * C;
    double d2 = D * D;

    double delta;
    double P = 8 * A * C - 3 * b2;

    double R_ = b3 + 8 * D * a2 - 4 * A * B * C;
    double delta0 = c2 - 3.0 * B * D + 12.0 * A * E;
    double delta1 = 2.0 * c3 - 9.0 * B * C * D + 27.0 * b2 * E + 27.0 * A * d2 - 72.0 * A * C * E;
    double D_ = 64 * a3 * E - 16 * a2 * c2 + 16 * A * b2 * C - 16 * a2 * B * D - 3 * b4;

    double p = (P / (8 * a2));
    double q = (R_ / (8 * a3));
    double y = (delta1 * delta1 - 4 * delta0 * delta0 * delta0);

    delta = y / -27;
    double qrt = sqrt(y);
    double Q = cbrt(((delta1 + qrt) / 2.0));
    double S;
    double fi = 0;

     if (delta > 0) {
        fi = acos((delta1) / (2 * sqrt(delta0 * delta0 * delta0)));
        S = 0.5f * sqrt(-(2.0f / 3.0f) * p +
                            (2.0f / (3.0f * a)) * sqrt(delta0) * cos(fi / 3.0f));
     } else {
         S = 0.5 * sqrt((-2.0 / 3.0) * p + (1.0 / (3.0 * A)) * (Q + delta0 / Q));
     }

     double rt0 = sqrt(-4 * S * S - 2 * p + (q / S));
     double rt1 = sqrt(-4 * S * S - 2 * p - (q / S));
     double z0 = -(B / (4 * A)) - S + 0.5 * rt0;
     double z1 = -(B / (4 * A)) - S - 0.5 * rt0;
     double z2 = -(B / (4 * A)) + S + 0.5 * rt1;
     double z3 = -(B / (4 * A)) + S - 0.5 * rt1;

     tau = INT_MAX;

     double t_min = 0;
     double t_max = 0;

     if (z0 <= tau && z0 > t_min) { tau = z0; }

     if (z1 <= tau && z1 > t_min) { tau = z1; }

     if (z2 <= tau && z2 > t_min) { tau = z2; }

     if (z3 <= tau && z3 > t_min) { tau = z3; }

     if (tau == INT_MAX){
         return false;
     }

     return true;
}

bool TTorus :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl){

    if(IsIntersect(ray_src, ray_dir, tau))
    {
       pt = ray_src + tau * ray_dir;
       TVec3f centerToPoint = pt - center;
       double	centerToPointDotAxis = centerToPoint * axis;
       TVec3f direction = centerToPoint - axis * centerToPointDotAxis;
       direction.Normalize();
       nl = pt - center + direction * R;
       nl.Normalize();
       return true;
    }

    return false;
}

/*------------------- ПЛОСКОСТИ ---------------*/
bool TPlane :: inside(TVec3f &pt){
    TVec3f ua = B - A;
    TVec3f ub = C - B;
    TVec3f uc = D - C;
    TVec3f ud = A - D;
    TVec3f va = pt - A;
    TVec3f vb = pt - B;
    TVec3f vc = pt - C;
    TVec3f vd = pt - D;

    double ka = (crossProduct(ua, va) * normal);
    double kb = (crossProduct(ub, vb) * normal);
    double kc = (crossProduct(uc, vc) * normal);
    double kd = (crossProduct(ud, vd) * normal);

    if (ka > 0 && kb > 0 && kc > 0 && kd > 0){
        return true;
    }

    if (ka < 0 && kb < 0 && kc < 0 && kd < 0){
        return true;
    }

    return false;
}

bool TPlane :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau){

    double eps = 1e-9;

    normal = crossProduct((C - B), (A - B));
    normal.Normalize();

    TVec3f vdif = A - ray_src;
    double d_dot_n = ray_dir * normal;
    if (fabs(d_dot_n) < eps){
        return false;
    }

    tau = (vdif * normal)/d_dot_n;
    if (tau < eps){
        return false;
    }

    TVec3f pt = ray_src + ray_dir * tau;
    if (inside(pt)){
        return true;
    }

    return false;
}

bool TPlane :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl){

    if(IsIntersect(ray_src, ray_dir, tau))
    {
       pt = ray_src + tau * ray_dir;
       nl = normal;
       return true;
    }

    return false;
}


/*------------ ТРЕУГОЛЬНИКИ ----------------------------------*/


bool TTriangle :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau){

    double eps = 1e-9;
    TVec3f edge1 = B - A;
    TVec3f edge2 = C - A;

    TVec3f pvec = crossProduct(ray_dir, edge2);
    double det = edge1 * pvec;

    if (det < eps){
        return false;
    }

    TVec3f tvec = ray_src - A;
    double u = tvec * pvec;

    if (u<0 || u > det){
        return false;
    }

    TVec3f qvec = crossProduct(tvec, edge1);
    double v = ray_dir * qvec;

    if (v < 0 || u + v > det){
        return false;
    }

    tau = edge2 * qvec * (1.0/det);

    return tau;
}

bool TTriangle :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl){

    if(IsIntersect(ray_src, ray_dir, tau))
    {
      pt = ray_src + tau * ray_dir;
      nl = crossProduct(B - A, C - A);
      nl.Normalize();
      return true;
    }

    return false;
}
