#ifndef KIRKPATRICK_H
#define KIRKPATRICK_H

#pragma once
#include "graph.h"
#include "util.h"
#include "task_data.h"
#include "triangle.h"
#include <memory>
#include <vector>

struct triangle_type;

struct kirkpatrick_type {
   kirkpatrick_type(point_arr const&);
   bool query(point_type const&) const;
   void get_triangle(std::vector<point> &result);

private:
   point_arr _outer_points;
   graph_type _graph;
   std::shared_ptr<triangle_type> _top_triangle;
   std::vector<segment_type> _triangulation;
};

#endif // KIRKPATRICK_H
