#include <iostream>
#include <vector>
#include "task_data.h"
#include <algorithm>
#include "kirkpatrick.h"
#include <time.h>
#include <string>

bool task_data::run(){
    point_arr vp;

    for (size_t i=0;i<vector_of_points.size();i++){
        int x = (int)vector_of_points[i].x;
        int y = (int)vector_of_points[i].y;

        vp.push_back(point_type(x,y));
    }

    point_type pnt = point_type((int)pt.x, (int)pt.y);

    clock_t start = clock();
    kirkpatrick_type *p = new kirkpatrick_type(vp);

    if (p->query(pnt) == 1){
        p->get_triangle(result);
        clock_t end = clock();

        work_time = std::to_string((double)(end - start)/CLOCKS_PER_SEC);
        return true;
    }

    return false;
}
