#pragma once
#include "kirkpatrick.h"
#include "triangle.h"
#include "task_data.h"

const size_t MAX_DEGREE = 8;
typedef std::set<std::shared_ptr<triangle_type>> triangle_set;
typedef std::map<point_type, triangle_set> triangle_map;

std::vector<int> myvect;

void add_triangle(graph_type& graph, point_type const& p1, point_type const& p2,
      point_type const& p3, bool is_inside, triangle_map& triangles,
      triangle_set& generated_triangles) {

    graph.add_edge(p1, p2);
   graph.add_edge(p2, p3);
   graph.add_edge(p3, p1);
   auto t = std::make_shared<triangle_type>(p1, p2, p3, is_inside);
   triangles[p1].insert(t);
   triangles[p2].insert(t);
   triangles[p3].insert(t);
   generated_triangles.insert(t);
}

void triangulate_polygon(point_arr const& points, graph_type& graph,
      triangle_map& triangles, bool is_inside,
      triangle_set& generated_triangles) {
   point_arr avail_points;
   for(auto pt: points) {                     // sequentially clipping ears
      while(avail_points.size() > 1) {
         auto jt = avail_points.rbegin();
         if(!is_ear(*(jt + 1), *jt, pt, points))
             break;

         add_triangle(graph, *(jt + 1), *jt, pt, is_inside, triangles,
               generated_triangles);
         avail_points.pop_back();
      }

      avail_points.push_back(pt);
   }
}

void triangulate_pockets(point_arr const& points, graph_type& graph,
      point_arr& convex_hull, triangle_map& triangles) {
   triangle_set tmp;
   size_t leftmost = 0;
   for(size_t i = 0; i != points.size(); ++i) {
      if(points[i].x < points[leftmost].x) leftmost = i;
   }

   size_t i = leftmost;
   convex_hull.push_back(points[(i++) % points.size()]);

   convex_hull.push_back(points[(i++) % points.size()]);

   for(; i - leftmost != points.size() + 1; ++i) {
      auto pt = points[i % points.size()];
      while(convex_hull.size() > 1) {
         auto jt = convex_hull.rbegin();               // jt is the last item in convex hull, jt+1 is a previous one
         if(!is_right_turn(*(jt + 1), *jt, pt))        // if right turn, then it's supposedly a pocket
             break;
         bool res = true;
         for(auto p: points) {                                       // check that no more points lie in this triangle
            if(p == *(jt + 1) || p == *jt || p == pt) continue;
            if(inside_triangle(pt, *jt, *(jt + 1), p)) { res = false; break; }
         }
         if(!res) break;

         add_triangle(graph, pt, *jt, *(jt + 1), false, triangles, tmp);       // add this pocket to graph as a triangle

         convex_hull.pop_back();               // because it is a pocket, last vertex on convex hull won't do
      }
      convex_hull.push_back(pt);

   }
}


void triangulate_with_outer_triangle(point_arr const& convex_hull,
      point_arr const& outer_points, graph_type& graph, triangle_map& triangles) {
   triangle_set tmp;

   add_triangle(graph, convex_hull[0], outer_points[2], outer_points[0], false,
         triangles, tmp);
   size_t last_seen = 0;
   for(size_t i = 1; i != convex_hull.size(); ++i) {

      if(is_left_turn(outer_points[last_seen], convex_hull[i], convex_hull[i - 1])) {

         add_triangle(graph, convex_hull[i - 1], outer_points[last_seen], convex_hull[i],
               false, triangles, tmp);
      }
      if(last_seen == 2) continue;
      if(is_right_turn(outer_points[last_seen + 1], convex_hull[i], convex_hull[i + 1])) {

         add_triangle(graph, outer_points[last_seen], outer_points[last_seen + 1],
            convex_hull[i], false, triangles, tmp);
         last_seen += 1;
      }
   }
}

void initial_triangulation(point_arr const& points, point_arr const& outer_points,
      graph_type& graph, triangle_map& triangles) {

   triangle_set tris;
   triangulate_polygon(points, graph, triangles, true, tris);
   point_arr convex_hull;

   triangulate_pockets(points, graph, convex_hull, triangles);

   triangulate_with_outer_triangle(convex_hull, outer_points, graph, triangles);
}


void retriangulate(point_arr& poly, point_type const& pt,          // poly is counter-clockwise points that surround pt
      graph_type& graph, triangle_map& triangles) {
   triangle_set const old_triangles(triangles[pt]);

   triangle_set new_triangles;
   triangulate_polygon(poly, graph, triangles, false, new_triangles);   // _is_inside variable for new triangles does not matter cause they all will have children

   for(auto ot: old_triangles) {
      for(auto nt: new_triangles) {
         if(intersects(*ot, *nt)) {
            nt->add_child(ot);

         }
      }
      for(auto& el: triangles) {

         size_t res = el.second.erase(ot);

      }
   }
   triangles.erase(pt);
}


bool refine(graph_type& graph, triangle_map& triangles) {
   point_arr iset = graph.independent_set(MAX_DEGREE);
   if(iset.empty())
       return false;

   for(auto pt: iset) {

      point_arr poly = sort_counter_clockwise(pt, graph.neighbours(pt));

      retriangulate(poly, pt, graph, triangles);
   }
   graph.remove(iset);

   return true;
}

std::shared_ptr<triangle_type> refinement(graph_type& graph, triangle_map& triangles) {
   for(;;) {
      if(!refine(graph, triangles))
          break;
   }

   return *(triangles.begin()->second.begin());
}

point_arr find_outer_triangle(point_arr const& points) {
   point_arr res;
   point_type lower_left;
   int c = 0;
   for(auto pt: points) {
      if(pt.x < lower_left.x) lower_left.x = pt.x;
      if(pt.y < lower_left.y) lower_left.y = pt.y;
      if(pt.x + pt.y > c) c = pt.x + pt.y;
   }
   lower_left += vector_type(-10,-10);
   c += 10;
   res.push_back(lower_left);
   res.push_back(point_type(c - lower_left.y, lower_left.y));
   res.push_back(point_type(lower_left.x, c - lower_left.x));


   return res;
}

kirkpatrick_type::kirkpatrick_type(point_arr const& points):
   _outer_points(find_outer_triangle(points)),
   _graph(_outer_points)  {

   _graph.add_poly(points);

   point_arr points_copy = points;
   if(!is_counter_clockwise(points)) {
      std::reverse_copy(points.begin(), points.end(), points_copy.begin());
   }

   triangle_map triangles;
   initial_triangulation(points_copy, _outer_points, _graph, triangles);

   _triangulation = _graph.edges();

   _top_triangle = refinement(_graph, triangles);
}

bool kirkpatrick_type::query(point_type const& pt) const {
    if (_top_triangle->query(pt,myvect)){
        return true;
    }

    return false;
}

void kirkpatrick_type::get_triangle(std::vector<point> &result){
    std::vector<point> tmp;
    for (size_t i=0;i<myvect.size();i=i+2){
        point p = point(myvect[i],myvect[i+1],-1);
        result.push_back(p);
    }
    //for(auto segm: _triangulation){
      //  tmp.push_back(point(segm[0].x,segm[0].y,-1));
       // tmp.push_back(point(segm[1].x,segm[1].y,-1));
       // result.push_back(tmp);
        //tmp.clear();
    //}
}
