#ifndef TASK_DATA_H
#define TASK_DATA_H

#include <map>
#include <set>
#include <vector>
#include <memory>
#include <algorithm>
#include <math.h>

struct point {
    double x;
    double y;
    int id;

    point() {} //конструктор без параметров
    point(double x_, double y_, int id_): x(x_), y(y_), id(id_) {} //конструктор с параметрами

    double length() { return sqrt(x * x + y * y); }

    point operator+(const point& op) const
    {
        return point(x + op.x, y + op.y, -1);
    }

    point operator-(const point& op) const
    {
        return  point(x - op.x, y - op.y, -1);
    }
};

inline point operator*(const double& t, const point& v)
{
  return point(t * v.x, t * v.y, -1);
}

/*--------------*/
struct vector_type {
   int x, y;
   vector_type(int x, int y) : x(x), y(y) {}
};

inline int operator ^ (vector_type const & v1, vector_type const & v2){
     int x1 = v1.x, y1 = v1.y, x2 = v2.x, y2 = v2.y;
     return x1 * y2 - x2 * y1;
}


inline int operator * (vector_type const & v1, vector_type const & v2){
     int x1 = v1.x, y1 = v1.y, x2 = v2.x, y2 = v2.y;
     return x1 * x2 + y1 * y2;
}

inline vector_type const operator - (vector_type const & v) { return vector_type(-v.x, -v.y); }
/*---------------*/

struct point_type {
     int x, y;
     point_type(int x, int y): x(x), y(y) {}
     point_type(): x(0), y(0) {}

     point_type & operator += (vector_type const & delta){
        x += delta.x;
        y += delta.y;
        return *this;
     }
};

inline bool operator < (point_type const & a, point_type const & b){
        if (a.x == b.x)
            return a.y < b.y;
        else
            return a.x < b.x;
}

inline bool operator > (point_type const & a, point_type const & b){
        return b < a;
}

inline bool operator == (point_type const & a, point_type const & b){
        return (a.x == b.x) && (a.y == b.y);
}

inline bool operator != (point_type const & a, point_type const & b){
        return !(a == b);
}

inline vector_type const operator - (point_type const & a, point_type const & b){
        return vector_type(a.x - b.x, a.y - b.y);
}

inline point_type const operator + (point_type const & pt, vector_type const & delta){
        point_type res(pt);
        res += delta;
        return res;
}

/*----------------------*/

struct segment_type{
       segment_type() {}

       segment_type(point_type const & beg, point_type const & end)
           : beg(beg)
           , end(end)
       {}

       point_type const & operator[] (size_t i) const
       {
           switch (i)
           {
           case 0: return beg;
           case 1: return end;
           default:
               throw -1;
           }
       }

       point_type & operator[] (size_t i)
       {
           switch (i)
           {
           case 0: return beg;
           case 1: return end;
           default:
               throw -1;
           }
       }

   private:
       point_type beg, end;
};

inline point_type const & min(segment_type const & seg) { return std::min(seg[0], seg[1]); }
inline point_type const & max(segment_type const & seg) { return std::max(seg[0], seg[1]); }

inline bool operator == (segment_type const & a, segment_type const & b){
       return (a[0] == b[0]) && (a[1] == b[1]);
}


inline bool operator != (segment_type const & a, segment_type const & b){
       return !(a == b);
}

struct task_data {
    std::vector<point> vector_of_points;
    point pt;
    std::vector<point> result;
    std::string work_time;

    task_data(){

    }

    bool run();
};

#endif // TASK_DATA_H
