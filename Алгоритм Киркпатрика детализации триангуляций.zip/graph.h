#ifndef GRAPH_H
#define GRAPH_H

#pragma once
#include <map>
#include <set>
#include "util.h"
#include "task_data.h"

struct graph_type {
   graph_type(point_arr const& special_points);
   void add(point_type const&);
   void add_edge(segment_type const& e) { add_edge(e[0], e[1]); }
   void add_edge(point_type const&, point_type const&);
   void add_poly(point_arr const&);
   segment_arr edges() const;
   point_arr independent_set(size_t max_degree) const;
   std::set<point_type> neighbours(point_type const& p) const { return _graph.at(p); }
   void remove(point_type const&);
   void remove(point_arr const&);

private:
   std::map<point_type, std::set<point_type> > _graph;
   point_arr _special_points;
};



#endif // GRAPH_H
