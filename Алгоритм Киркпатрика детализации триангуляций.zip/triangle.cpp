#include "triangle.h"

bool intersects(triangle_type const& t1, triangle_type const& t2) {
   segment_arr s1, s2;
   s1.push_back(segment_type(t1.p1(), t1.p2()));
   s1.push_back(segment_type(t1.p3(), t1.p2()));
   s1.push_back(segment_type(t1.p1(), t1.p3()));
   s2.push_back(segment_type(t2.p1(), t2.p2()));
   s2.push_back(segment_type(t2.p3(), t2.p2()));
   s2.push_back(segment_type(t2.p1(), t2.p3()));
   bool res = false;
   for(auto x: s1) {
      for(auto y: s2) {
         if(intersects(x, y)) res = true;
      }
   }
   return res;
}

bool triangle_type::inside(point_type const& pt) const {
   return inside_triangle(_p1, _p2, _p3, pt);
}

bool triangle_type::query(point_type const& pt, std::vector<int> &pv) const {
   if(!inside(pt))
       return false;

   if(_children.empty())
       return _is_inside;

   for(auto t: _children) {
      pv.clear();
      if (t->query(pt,pv)){
          pv.push_back(t->p1().x);
          pv.push_back(t->p1().y);

          pv.push_back(t->p2().x);
          pv.push_back(t->p2().y);

          pv.push_back(t->p3().x);
          pv.push_back(t->p3().y);
          return true;
      }
   }

   return false;
}

