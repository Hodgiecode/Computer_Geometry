#include "ray_tracer.h"


TColor SimpleScene ::  get_pixel(int x, int y){
    double rX = Vw * (x - CCx) / Cw;
    double rY = Vh * (CCy - y) / Ch;

    TVec3f ray_src(rX, rY, Dist);
    TVec3f ray_dir(rX, rY, Dist);


    bool intersect = false;
    double tau;
    TVec3f N;
    TVec3f P;
    TColor Col;

    for(size_t q(0); q < objects.size(); q++)
    {
      double tT;
      TVec3f tN;
      TVec3f tP;
      TColor tCol;

      if(objects[q]->IsIntersect(ray_src, ray_dir, tT, tP, tN))
      {
        if(!intersect || tT < tau)
        {
          tau = tT;
          N = tN;
          Col = objects[q]->get_color();
          P = tP;
        }

        intersect = true;
      }
    }

    if(!intersect)
      return ambient_color;

    TVec3f ldir = light_pos - P;
    ldir.Normalize();

    double lforce = ambient_light;
    double f = ldir * N;
    if(f > 0)
    {
      lforce += f * light_force;
    }

    return Col.apply_force(lforce);
 }


bool TSphere :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau)
{

  double A = ray_dir * ray_dir;
  TVec3f v = (ray_src - center);
  double B = ray_dir * v;
  double C = v * v - R * R;

  double D4 = B * B - A * C;

  if(D4 < 0)
    return false;

  double t1 = (- B - sqrt(D4) ) / A;
  double t2 = (-B + sqrt(D4) ) / A;

  if(t1 < 0 && t2 < 0)
    return false;

  else if(t1 < 0)
   tau = t2;
  else
    tau = t1;

  return true;
}

bool TSphere :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl)
{
  if(IsIntersect(ray_src, ray_dir, tau))
  {
    pt = ray_src + tau * ray_dir;
    nl = pt - center;

    nl.Normalize();
    return true;
  }
  return false;
}


TVec3f crossProduct(TVec3f vect_A, TVec3f vect_B){
    TVec3f cross_P;
    cross_P.x = vect_A.y * vect_B.z - vect_A.z * vect_B.y;
    cross_P.y = vect_A.z * vect_B.x - vect_A.x * vect_B.z;
    cross_P.z = vect_A.x * vect_B.y - vect_A.y * vect_B.x;

    return cross_P;
}


bool TTriangle :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau){

    double eps = 1e-9;
    TVec3f e1 = B - A;
    TVec3f e2 = C - A;
    TVec3f p = crossProduct(ray_dir, e2);

    double a = e1 * p;
    if (a < eps && a < -eps){
        return false;
    }

    double f = 1 / a;
    TVec3f s = ray_src - A;
    double u = f * (s * p);

    if (u<0.0 || u>1.0){
        return false;
    }

    TVec3f q = crossProduct(s,e1);
    double v = f * (ray_dir * q);

    if (v<0.0 || u + v > 1.0){
        return false;
    }

    tau = f * (e2 * q);
    return true;
}

bool TTriangle :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl){

    if(IsIntersect(ray_src, ray_dir, tau))
    {
      pt = ray_src + tau * ray_dir;
      nl = crossProduct(B - A, C - A);
      nl.Normalize();
      return true;
    }

    return false;
}

