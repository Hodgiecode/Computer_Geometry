#include "mywidget.h"
#include "mywidget.h"
#include <QPainter>
#include <QImage>
#include "ray_tracer.h"

MyWidget::MyWidget(QWidget *parent) : QWidget(parent)
{
    triangle_flag = 0;
    sphere_flag = 0;
}

void MyWidget::paintEvent(QPaintEvent *event)
{
  QPainter p(this);
  int W = width();
  int H = height();
  int mode = 0;

  if (sphere_flag == 1){
      mode = 0;
  }

  if (triangle_flag == 1){
      mode = 1;
  }

  SimpleScene sc(W, H, mode);
  QImage img(W, H, QImage::Format_RGB32);

  if (triangle_flag == 1 || sphere_flag == 1){
    for(int y = 0; y < H; y++)
      for(int x = 0; x < W; x++)
      {
        TColor col = sc.get_pixel(x, y);
          img.setPixelColor(x, y, QColor(col.R, col.G, col.B));
      }

    p.drawImage(0, 0, img);
    triangle_flag = 0;
    sphere_flag = 0;
  }
}

void MyWidget::ray_trace_triangle(){
    triangle_flag = 1;
    sphere_flag = 0;
    repaint();
}

void MyWidget::ray_trace_sphere(){
    triangle_flag = 0;
    sphere_flag = 1;
    repaint();
}

