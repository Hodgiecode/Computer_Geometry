#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->draw_widget->SetTaskPtr(&current_task);
    ui->draw_widget->SetDefaultPoints();
    QString v1 = QString::fromUtf8(ui->draw_widget->weights.c_str());
    ui->lineEdit->setText(v1);
}

MainWindow::~MainWindow(){
    delete ui;
}

void MainWindow::on_pushButton_clicked(){
    ui->draw_widget->weights = ui->lineEdit->text().toStdString();
    ui->draw_widget->RationalBezier();
}

void MainWindow::on_pushButton_2_clicked(){
    ui->draw_widget->BernsteinPolynom();
}

void MainWindow::on_pushButton_3_clicked(){
    std::string p = ui->lineEdit_2->text().toStdString();
    std::string p_ = std::to_string(atoi(p.c_str()) + 1);

    QString v1 = QString::fromUtf8(p_.c_str());
    ui->lineEdit_2->setText(v1);

    std::string old_weights = ui->lineEdit->text().toStdString();
    std::string new_weights = old_weights + "0.5";

    QString v2 = QString::fromUtf8(new_weights.c_str());
    ui->lineEdit->setText(v2);

    ui->draw_widget->AddPoint();
}

void MainWindow::on_pushButton_4_clicked(){
    ui->draw_widget->SplitBezier();
}

void MainWindow::on_pushButton_5_clicked(){
    std::string p = ui->lineEdit_2->text().toStdString();

    if (p == ""){
        ui->draw_widget->points = 10;
        p = "10";
        QString v1 = QString::fromUtf8(p.c_str());
        ui->lineEdit_2->setText(v1);

        ui->draw_widget->weights = "";
        for (int i=0; i < 10;i++){
            ui->draw_widget->weights += " 0.5";
        }
    }

    ui->draw_widget->points = atoi(ui->lineEdit_2->text().toStdString().c_str());
    ui->draw_widget->create_points();

    QString v1 = QString::fromUtf8(ui->draw_widget->weights.c_str());
    ui->lineEdit->setText(v1);
}
