#include "drawwidget.h"
#include <QPainter>
#include <QMouseEvent>
#include <sstream>

const int circ_size = 20;

DrawWidget::DrawWidget(QWidget *parent) : QWidget(parent)
{
    pTask = 0;
    m_bMovePointFlag = false;
}


void DrawWidget::paintEvent(QPaintEvent *event){
    QPainter p(this);

    if(pTask){
        for (int i=0;i<pTask->vector_of_points.size();i++){
            p.drawArc(pTask->vector_of_points[i].x - circ_size / 2, pTask->vector_of_points[i].y - circ_size / 2, circ_size, circ_size, 0, 360 * 16);
        }

        for (int i=0;i<pTask->vector_of_points.size();i++){
            if (i < pTask->vector_of_points.size() - 1){
                p.drawLine(pTask->vector_of_points[i].x, pTask->vector_of_points[i].y,
                           pTask->vector_of_points[i+1].x, pTask->vector_of_points[i+1].y);
            }
        }

        QPen penHLines(QColor("#ff0000"), 5);
        p.setPen(penHLines);


        for (int i=0;i<pTask->curve.size();i++){
            if (i < pTask->curve.size() - 1){
                p.drawLine(pTask->curve[i].x, pTask->curve[i].y,
                           pTask->curve[i+1].x, pTask->curve[i+1].y);
            }
        }


        if (pTask->left.size()>0 && pTask->right.size()>0){
            QPen penHLines(QColor("#ff0000"), 5);
            p.setPen(penHLines);

            for (int i=0;i<pTask->left.size();i++){
                  if (i < pTask->left.size() - 1){
                       p.drawLine(pTask->left[i].x, pTask->left[i].y,
                             pTask->left[i+1].x, pTask->left[i+1].y);
                  }
            }

            QPen penHLines1(QColor("#0000ff"), 5);
            p.setPen(penHLines1);

            for (int i=0;i<pTask->right.size();i++){
                  if (i < pTask->right.size() - 1){
                       p.drawLine(pTask->right[i].x, pTask->right[i].y,
                             pTask->right[i+1].x, pTask->right[i+1].y);
                  }
            }

        }


        if (pTask->new_points.size()>0){
            QPen penHLines1(QColor("#0000ff"), 5);
            p.setPen(penHLines1);

            pTask->vector_of_points.clear();

            for (int i=0;i<pTask->new_points.size();i++){
                p.drawArc(pTask->new_points[i].x - circ_size / 2, pTask->new_points[i].y - circ_size / 2, circ_size, circ_size, 0, 360 * 16);

                point t;
                t.x = pTask->new_points[i].x;
                t.y = pTask->new_points[i].y;
                t.id = i;

                pTask->vector_of_points.push_back(t);
            }

            QPen penHLines2(QColor("#ff0000"), 5);
            p.setPen(penHLines2);

            for (int i=0;i<pTask->new_curve.size();i++){
                if (i < pTask->new_curve.size() - 1){
                    p.drawLine(pTask->new_curve[i].x, pTask->new_curve[i].y,
                               pTask->new_curve[i+1].x, pTask->new_curve[i+1].y);
                }
            }

        }


        if (rb_flag == 1){

            std::stringstream ss(weights);
            std::string item;

            pTask->point_weights.clear();
            while(std::getline(ss, item, ' ')){
                pTask->point_weights.push_back(atof(item.c_str()));
            }

            pTask->rational_bezier();
        }

        if (bp_flag == 1){
            pTask->bernstein_polynom();
        }

        if (sp_flag == 1){
            pTask->split_bezier();
        }

        if (ed_flag == 1){
            pTask->elevation_degree();
        }

        pTask->curve.clear();
        pTask->left.clear();
        pTask->right.clear();
        pTask->point_weights.clear();
        pTask->new_points.clear();
        pTask->new_curve.clear();
    }
}

void DrawWidget::SetDefaultPoints()
{
    pTask->vector_of_points.clear();
    int amount_of_points = 10;

    weights = "";

    for (int i=0;i<amount_of_points;i++){
        weights += "0.5 ";
    }

    if(pTask){
        int w = width();
        int h = height();

        for (int i=0;i<amount_of_points;i++){
            pTask->vector_of_points.push_back( point(100+i*20,300+i*20,i));
        }
     }
}

void DrawWidget::mouseMoveEvent(QMouseEvent *event)
{
  if(m_bMovePointFlag)
  {
    for (int i=0;i<pTask->vector_of_points.size();i++){
       int id = pTask->vector_of_points[i].id;

       if(last_moved_point_id == id)
        {
          pTask->vector_of_points[i].x = event->x();
          pTask->vector_of_points[i].y = event->y();

          repaint();

          break;
        }
    }
  }
}

void DrawWidget::mousePressEvent(QMouseEvent *event)
{
   if(event->button() == Qt::LeftButton)
    {
      int XX = event->x();
      int YY = event->y();

       point v(XX, YY, -1);
       for (int i=0;i<pTask->vector_of_points.size();i++){

          if((v - pTask->vector_of_points[i]).length() < circ_size / 2){
              m_bMovePointFlag = true;
              last_moved_point_id = i;
              break;
          }
       }

    }
}

void DrawWidget::mouseReleaseEvent(QMouseEvent *event)
{
  m_bMovePointFlag = false;
}



void DrawWidget::BernsteinPolynom(){
    bp_flag = 1;
    sp_flag = 0;
    rb_flag = 0;
    ed_flag = 0;
    pTask->bernstein_polynom();
    repaint();
}


void DrawWidget::SplitBezier(){
    rb_flag = 0;
    bp_flag = 0;
    sp_flag = 1;
    ed_flag = 0;
    pTask->split_bezier();
    repaint();
}


void DrawWidget::RationalBezier(){
    rb_flag = 1;
    bp_flag = 0;
    sp_flag = 0;
    ed_flag = 0;

    std::stringstream ss(weights);
    std::string item;

    pTask->point_weights.clear();
    while(std::getline(ss, item, ' ')){
        pTask->point_weights.push_back(atof(item.c_str()));
    }

    pTask->rational_bezier();
    repaint();
}

void DrawWidget::AddPoint(){
    rb_flag = 0;
    bp_flag = 0;
    sp_flag = 0;
    ed_flag = 1;
    pTask->elevation_degree();
    repaint();
}
