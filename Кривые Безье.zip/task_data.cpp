#include "task_data.h"

int factorial(int n){
    int ret = 1;
    for (int i=1;i<=n;i++){
        ret = ret * i;
    }

    return ret;
}

double bernstein(int i, int n, double t){
    return (factorial(n)/(factorial(i)*factorial(n-i))) * pow(t,i) * pow(1-t, n -i);
}

bool task_data::bernstein_polynom(){
    if (vector_of_points.size()<3){
        return false;
    }

    point bp1,bp2;
    bp1 = vector_of_points[0];

    for (double t=0;t<=1;t=t+0.01){

        bp2 = point(0,0,-1);

        for (int i=0;i<vector_of_points.size();++i){
            point cur_point = point(vector_of_points[i].x, vector_of_points[i].y,  vector_of_points.size()-1);
            bp2 = bp2 + bernstein(i, vector_of_points.size() - 1, t) * cur_point;
        }

        curve.push_back(bp1);
        curve.push_back(bp2);
        bp1 = bp2;
    }

    return true;
}

/*-----------------------------------------*/

void split(std::vector<point> &vector_of_points, std::vector<point> &left,
           std::vector<point> &right, double t){

    if (vector_of_points.size() == 1){
        left.push_back(vector_of_points[0]);
        right.push_back(vector_of_points[0]);
    } else {
        left.push_back(vector_of_points[0]);
        right.push_back(vector_of_points[vector_of_points.size()-1]);

        for (size_t i=0;i<vector_of_points.size()-1;i++){
            vector_of_points[i].x = (1 - t) * vector_of_points[i].x + t * vector_of_points[i + 1].x;
            vector_of_points[i].y = (1 - t) * vector_of_points[i].y + t * vector_of_points[i + 1].y;
        }

        vector_of_points.pop_back();
        split(vector_of_points, left, right, t);
    }
}

bool task_data::split_bezier(){
    std::vector<point> tmp_ = vector_of_points;

    double t = 0.5;

    split(tmp_, left,right, t);
    return true;
}

/*------------------------------- */
double task_data::weights(int i, double t, int k){
    if(k==0){
        return point_weights[i];
    }

    return (1 - t) * weights(i, t, k-1) + t * weights(i+1,t,k-1);
}

point task_data::point_get(int i, double t, int k){
    if(k == 0){
        return point_weights[i] * vector_of_points[i] * (1 / weights(0, t, vector_of_points.size()-1));
    }
    return (1-t) * point_get(i,t,k-1) + t * point_get(i+1, t, k-1);
}

bool task_data::rational_bezier(){
    std :: vector<int> coeff;
    std :: vector<int> tmp;

    if (vector_of_points.size() < 2){
        return false;
    }

    coeff.resize(vector_of_points.size());
    tmp.resize(vector_of_points.size());

    coeff[0] = 1;
    coeff[0] = 1;

    for(size_t cur_size = 3; cur_size <= vector_of_points.size(); cur_size++){
        tmp[0] = 1;
        tmp[cur_size - 1] = 1;
        for(size_t t = 1; t < cur_size - 1; t++){
          tmp[t] = coeff[t - 1] + coeff[t];
        }

        coeff = tmp;
    }

    if (coeff.empty()){
        return false;
    }

    int points_num = 50;
    double step = 1.0 / (points_num - 1);

    for (size_t i=0;i<vector_of_points.size();i++){
        point_weights.push_back(0.5);
    }

    for(size_t i = 0; i < points_num; i++){
      curve.push_back(point_get(0, double(i)/points_num, vector_of_points.size() - 1));
    }

    return true;
}


bool task_data::elevation_degree(){
    new_points.push_back(vector_of_points[0]);

    int n = vector_of_points.size() - 1;
    for (size_t i=1;i<n; i++){
        point t;
        t.x = vector_of_points[i-1].x * (i/double(n + 1)) + vector_of_points[i].x
                * (1 - (i/ double(n+1)));

        t.y =  vector_of_points[i-1].y * (i/double(n + 1)) + vector_of_points[i].y
                * (1 - (i/ double(n+1)));

        new_points.push_back(t);
    }

    new_points.push_back(vector_of_points[n]);


    /* для новых точек строим строим кривую */

    if (new_points.size()<3){
        return false;
    }

    point bp1,bp2;
    bp1 = new_points[0];

    for (double t=0;t<=1;t=t+0.01){

        bp2 = point(0,0,-1);

        for (int i=0;i<new_points.size();++i){
            point cur_point = point(new_points[i].x, new_points[i].y,  new_points.size()-1);
            bp2 = bp2 + bernstein(i, new_points.size() - 1, t) * cur_point;
        }

        new_curve.push_back(bp1);
        new_curve.push_back(bp2);
        bp1 = bp2;
    }


    return true;
}
