#ifndef MYWIDGET_H
#define MYWIDGET_H

#include <QWidget>

class MyWidget : public QWidget
{
    Q_OBJECT
public:
    explicit MyWidget(QWidget *parent = nullptr);

    void ray_trace_triangle();
    void ray_trace_sphere();
    void ray_trace_cone();
    void ray_trace_cylinder();
    void ray_trace_torus();

    int triangle_flag = 0;
    int sphere_flag = 0;
    int cone_flag = 0;
    int cylinder_flag = 0;
    int torus_flag = 0;

signals:

public slots:
    void paintEvent(QPaintEvent *event);
};

#endif // MYWIDGET_H
