#ifndef TASK_DATA_H
#define TASK_DATA_H

#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <algorithm>

struct point {
    double x;
    double y;
    int id;

    point() {} //конструктор без параметров
    point(double x_, double y_, int id_): x(x_), y(y_), id(id_) {} //конструктор с параметрами

    double length() { return sqrt(x * x + y * y); }

    point operator+(const point& op) const{
        return point(x + op.x, y + op.y, -1);
    }

    point operator-(const point& op) const {
        return  point(x - op.x, y - op.y, -1);
    }

    bool operator ==(const point & b) const{
        return fabs(y - b.y) < 1.0e-9 && fabs(x - b.x) < 1.0e-9;
    }

    bool operator !=(const point & b) const{
        return fabs(y - b.y) > 1.0e-9 || fabs(x - b.x) > 1.0e-9;
    }

    bool operator <(const point & b) const {
        if (y < b.y - 1.0e-9) return true;
        else if (y > b.y + 1.0e-9) return false;
        else if (x < b.x - 1.0e-9) return true;
        else return false;
    }

};

inline point operator*(const double& t, const point& v){
  return point(t * v.x, t * v.y, -1);
}

struct segment{
    point beg, end;
    segment & operator = (segment const & b) { beg = b.beg; end = b.end; return *this; }
    segment(const segment & b) : beg(b.beg), end(b.end) {}
    segment(const point & _beg, const point & _end) : beg(_beg), end(_end) {}
};


class event_less
{
public:
    bool operator()(const std::pair<double, int> & a, const std::pair<double, int> & b) const
    {
        if (a.first < b.first - 1.0e-9)
            return true;
        else if (a.first > b.first + 1.0e-9)
            return false;
        else if (a.second < b.second)
            return true;
        return false;
    }
};


struct task_data {
    std::vector<point> vector_of_points;
    std::vector<point> intersections;

    task_data(){

    }

    bool run();
};


#endif // TASK_DATA_H
