#include "drawwidget.h"
#include <QPainter>
#include <QMouseEvent>

const int circ_size = 20;

DrawWidget::DrawWidget(QWidget *parent) : QWidget(parent){
    pTask = 0;
    m_bMovePointFlag = false;
}


void DrawWidget::paintEvent(QPaintEvent *event){
    QPainter p(this);

    if(pTask){
        for (int i=0;i<pTask->vector_of_points.size();i++){
            p.drawArc(pTask->vector_of_points[i].x - circ_size / 2, pTask->vector_of_points[i].y - circ_size / 2, circ_size, circ_size, 0, 360 * 16);
        }

        for (int i=0;i<pTask->vector_of_points.size();i=i+2){
            p.drawLine(pTask->vector_of_points[i].x,pTask->vector_of_points[i].y,
                       pTask->vector_of_points[i+1].x, pTask->vector_of_points[i+1].y);
        }


        QPen penHLines2(QColor("#000000"),3);
        p.setPen(penHLines2);

        for (int i=0;i<pTask->intersections.size();i++){
            p.drawArc(pTask->intersections[i].x - circ_size / 2, pTask->intersections[i].y - circ_size / 2, circ_size, circ_size, 0, 360 * 16);
        }
     }

     pTask->intersections.clear();
}

void DrawWidget::run(){
    pTask->run();
    repaint();
}

void DrawWidget::clean(){
    pTask->intersections.clear();
    pTask->vector_of_points.clear();
    SetDefaultPoints();
}

void DrawWidget::SetDefaultPoints(){
    if(pTask){
        repaint();
    }
}

void DrawWidget::mouseMoveEvent(QMouseEvent *event){
  if(m_bMovePointFlag)
  {
    for (int i=0;i<pTask->vector_of_points.size();i++){
       int id = pTask->vector_of_points[i].id;

       if(last_moved_point_id == id)
        {
          pTask->vector_of_points[i].x = event->x();
          pTask->vector_of_points[i].y = event->y();

          repaint();

          break;
        }
    }
  }
}

void DrawWidget::mousePressEvent(QMouseEvent *event)
{
   if(event->button() == Qt::LeftButton)
    {
      int XX = event->x();
      int YY = event->y();

       point v(XX, YY, -1);
       for (int i=0;i<pTask->vector_of_points.size();i++){

          if((v - pTask->vector_of_points[i]).length() < circ_size / 2){
              m_bMovePointFlag = true;
              last_moved_point_id = i;
              break;
          }
       }

    }
}

void DrawWidget::mouseReleaseEvent(QMouseEvent *event)
{
  m_bMovePointFlag = false;
}

void DrawWidget::create_segments(){
    double eps = 20;
    pTask->vector_of_points.clear();

    int h = 500;
    int w = 400;

    int points = 2 * segments;

    while (pTask->vector_of_points.size() < points){
        point p = point(qrand() % h + 100, qrand() % w + 100, pTask->vector_of_points.size());

        int flag = 0;
        for (size_t i=0;i < pTask->vector_of_points.size();i++){
            if (fabs(pTask->vector_of_points[i].x - p.x) < eps &&
                fabs(pTask->vector_of_points[i].y - p.y) < eps){
                flag = 1;
                break;
            }
        }

       if (flag == 0){
          pTask->vector_of_points.push_back(p);
       }
    }

    repaint();
}
