#include "task_data.h"
#include <iostream>



bool task_data :: run()
{
    //на вход поступает вектор точек

    point A = vector_of_points[0];
    point B = vector_of_points[1];
    point C = vector_of_points[2];

    double l = (B.x - A.x) * (C.y - A.y);
    double r = (C.x - A.x) * (B.y - A.y);
    double e = (abs(l) + abs(r)) * std::numeric_limits<double>::epsilon() * 4;
    double det = l - r;

    coord_1 = std::to_string(A.x)+" "+std::to_string(A.y);
    coord_2 = std::to_string(B.x)+" "+std::to_string(B.y);
    coord_3 = std::to_string(C.x)+" "+std::to_string(C.y);

    if (det > e){
        result = "right";
        return true;
    }

    if (det < -e){
        result = "left";
        return true;
    }

    result = "collinear";
    return true ;
}

