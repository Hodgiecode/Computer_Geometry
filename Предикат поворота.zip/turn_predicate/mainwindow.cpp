#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "drawwidget.h"
#include "QMessageBox"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->draw_widget->SetTaskPtr(&current_task);
    ui->draw_widget->SetDefaultPoints();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    // инициализация задачи
    ui->draw_widget->calc();
    QString v1 = QString::fromUtf8(ui->draw_widget->coord_1.c_str());
    QString v2 = QString::fromUtf8(ui->draw_widget->coord_2.c_str());
    QString v3 = QString::fromUtf8(ui->draw_widget->coord_3.c_str());
    QString v4 = QString::fromUtf8(ui->draw_widget->result.c_str());

    ui->lineEdit->setText(v1);
    ui->lineEdit_2->setText(v2);
    ui->lineEdit_3->setText(v3);
    ui->lineEdit_4->setText(v4);
}

void MainWindow::on_pushButton_2_clicked(){
    // инициализация задачи
    ui->draw_widget->clean();
    QString v1 = QString::fromUtf8(ui->draw_widget->coord_1.c_str());
    QString v2 = QString::fromUtf8(ui->draw_widget->coord_2.c_str());
    QString v3 = QString::fromUtf8(ui->draw_widget->coord_3.c_str());
    QString v4 = QString::fromUtf8(ui->draw_widget->result.c_str());

    ui->lineEdit->setText(v1);
    ui->lineEdit_2->setText(v2);
    ui->lineEdit_3->setText(v3);
    ui->lineEdit_4->setText(v4);
}
