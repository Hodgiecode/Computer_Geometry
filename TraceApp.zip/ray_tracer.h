#ifndef RAY_TRACER_H
#define RAY_TRACER_H

#include <math.h>
#include <vector>
#include <algorithm>

struct TColor
{
  unsigned short R;
  unsigned short G;
  unsigned short B;

  TColor() { }
  TColor(unsigned short iR, unsigned short iG, unsigned short iB) : R(iR), G(iG), B(iB) { }

  TColor apply_force(double lforce) const
  {
      unsigned short tR = std :: min(255, int(lforce * R));
      unsigned short tG = std :: min(255, int(lforce * G));
      unsigned short tB = std :: min(255, int(lforce * B));
      return TColor(tR, tG, tB);
  }
};

struct TVec3f
{
  double x;
  double y;
  double z;

  TVec3f() { }
  TVec3f(double iX, double iY, double iZ) : x(iX), y(iY), z(iZ) { }

  TVec3f operator+(const TVec3f& v) const
  {
    return TVec3f(x + v.x, y + v.y, z + v.z);
  }

  TVec3f operator-(const TVec3f& v) const
  {
    return TVec3f(x - v.x, y - v.y, z - v.z);
  }

  double operator*(const TVec3f& v) const
  {
    return x * v.x + y * v.y + z * v.z;
  }

  TVec3f operator*(const double& f) const
  {
    return TVec3f(x * f, y * f, z * f);
  }

  double length() const
  {
    return sqrt(x * x + y * y + z * z);
  }

  void Normalize()
  {
    double l = length();
    if(l > 0)
    {
      x /= l;
      y /= l;
      z /= l;
    }
  }
};

inline TVec3f operator*(const double& f, const TVec3f& v)
{
  return v * f;
}

class TObject
{
protected:
   TColor color;
public:
   TObject() : color(0, 0, 0) { }
   TObject(const TColor& col) : color(col) { }
   const TColor& get_color() const { return color; }

   virtual bool IsIntersect(const TVec3f& ray_src,
                            const TVec3f& ray_dir,
                            double& tau) = 0;

   virtual bool IsIntersect(const TVec3f& ray_src,
                            const TVec3f& ray_dir,
                            double& tau,
                            TVec3f& pt,
                            TVec3f& nl) = 0;
};




class TSphere : public TObject
{

public:

    // center?
    TVec3f center;
    double R;

    TSphere(const TVec3f& iC, const double& iR, const TColor& col) :
        TObject (col), center(iC), R(iR)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);
};


class SimpleScene
{

protected:

  double Vw;
  double Vh;
  double Dist;

  int CCx, CCy;

  int Cw;
  int Ch;

  double ambient_light;
  TColor ambient_color;

  TVec3f light_pos;
  double light_force;

  std :: vector<TObject*> objects;

public:
  SimpleScene(int W, int H) : Cw(W), Ch(H)
  {
    Vh = 1;
    Vw = double (Cw * Vh) / Ch; 1.0;


    Dist = 1;

    CCx = W / 2;
    CCy = H / 2;

    ambient_color = TColor(70, 70, 70);
    ambient_light = 0.2;

    light_force = 1.8;
    light_pos = TVec3f(-1, 1, 0);

    objects.push_back(new TSphere(TVec3f(0, 0, 5), 2, TColor(128, 0, 0)));
  }

  TColor get_pixel(int x, int y);
};

#endif // RAY_TRACER_H
