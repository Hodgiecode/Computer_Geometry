#include "ray_tracer.h"
#include <math.h>

 bool TSphere :: IsIntersect(const TVec3f& ray_src,
                         const TVec3f& ray_dir,
                         double& tau)
 {

   double A = ray_dir * ray_dir;
   TVec3f v = (ray_src - center);
   double B = ray_dir * v;
   double C = v * v - R * R;

   double D4 = B * B - A * C;

   if(D4 < 0)
     return false;

   double t1 = (- B - sqrt(D4) ) / A;
   double t2 = (-B + sqrt(D4) ) / A;

   if(t1 < 0 && t2 < 0)
     return false;

   else if(t1 < 0)
    tau = t2;
   else
     tau = t1;

   return true;
 }

 bool TSphere :: IsIntersect(const TVec3f& ray_src,
                         const TVec3f& ray_dir,
                         double& tau,
                         TVec3f& pt,
                         TVec3f& nl)
 {
   if(IsIntersect(ray_src, ray_dir, tau))
   {
     pt = ray_src + tau * ray_dir;
     nl = pt - center;
     nl.Normalize();
     return true;
   }
   return false;
 }

 TColor SimpleScene ::  get_pixel(int x, int y)
 {
    double rX = Vw * (x - CCx) / Cw;
    double rY = Vh * (CCy - y) / Ch;

    TVec3f ray_src(rX, rY, Dist);
    TVec3f ray_dir(rX, rY, Dist);

    bool intersect = false;
    double tau;
    TVec3f N;
    TVec3f P;
    TColor Col;

    for(size_t q(0); q < objects.size(); q++)
    {
      double tT;
      TVec3f tN;
      TVec3f tP;
      TColor tCol;

      if(objects[q]->IsIntersect(ray_src, ray_dir, tT, tP, tN))
      {
        if(!intersect || tT < tau)
        {
          tau = tT;
          N = tN;
          Col = objects[q]->get_color();
          P = tP;
        }

        intersect = true;
      }
    }

    if(!intersect)
      return ambient_color;

    TVec3f ldir = light_pos - P;
    ldir.Normalize();

    double lforce = ambient_light;
    double f = ldir * N;
    if(f > 0)
    {
      lforce += f * light_force;
    }

    return Col.apply_force(lforce);
 }
