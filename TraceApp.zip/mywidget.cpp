#include "mywidget.h"
#include <QPainter>
#include <QImage>
#include "ray_tracer.h"

MyWidget::MyWidget(QWidget *parent) : QWidget(parent)
{

}

void MyWidget::paintEvent(QPaintEvent *event)
{
  QPainter p(this);
  int W = width();
  int H = height();

  SimpleScene sc(W, H);
  QImage img(W, H, QImage::Format_RGB32);

  for(int y = 0; y < H; y++)
    for(int x = 0; x < W; x++)
    {
      TColor col = sc.get_pixel(x, y);
        img.setPixelColor(x, y, QColor(col.R, col.G, col.B));//QColor(x % 255, 100, 255 - y % 255));
    }
  p.drawImage(0, 0, img);
  //p.drawImage()
}
