#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "ray_tracer.h"

