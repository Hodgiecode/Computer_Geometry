#include "mywidget.h"
#include "mywidget.h"
#include <QPainter>
#include <QImage>
#include "ray_tracer.h"

MyWidget::MyWidget(QWidget *parent) : QWidget(parent)
{
    triangle_flag = 0;
    sphere_flag = 0;
    cone_flag = 0;
    cylinder_flag = 0;
    torus_flag = 0;
    scene_flag = 0;
}

void MyWidget::paintEvent(QPaintEvent *event)
{
  QPainter p(this);
  int W = width();
  int H = height();
  int mode = 0;

  if (sphere_flag == 1){
      mode = 0;
  }

  if (triangle_flag == 1){
      mode = 1;
  }

  if (cone_flag == 1){
      mode = 2;
  }

  if (cylinder_flag == 1){
      mode = 3;
  }

  if (torus_flag == 1){
      mode = 4;
  }

  if (scene_flag == 1){
      mode = 5;
  }

  SimpleScene sc(W, H, mode);
  QImage img(W, H, QImage::Format_RGB32);

  if (triangle_flag == 1 || sphere_flag == 1 || cone_flag == 1 || cylinder_flag == 1 || torus_flag == 1 || scene_flag == 1){
    for(int y = 0; y < H; y++)
      for(int x = 0; x < W; x++)
      {
        TColor col = sc.get_pixel(x, y);
          img.setPixelColor(x, y, QColor(col.R, col.G, col.B));
      }

    p.drawImage(0, 0, img);
    triangle_flag = 0;
    sphere_flag = 0;
    cone_flag = 0;
    cylinder_flag = 0;
    torus_flag = 0;
    scene_flag = 0;
  }
}

void MyWidget::ray_trace_triangle(){
    triangle_flag = 1;
    sphere_flag = 0;
    cone_flag = 0;
    cylinder_flag = 0;
    torus_flag = 0;
    scene_flag = 0;
    repaint();
}

void MyWidget::ray_trace_sphere(){
    triangle_flag = 0;
    sphere_flag = 1;
    cone_flag = 0;
    cylinder_flag = 0;
    torus_flag = 0;
    scene_flag = 0;
    repaint();
}

void MyWidget::ray_trace_cone(){
    triangle_flag = 0;
    sphere_flag = 0;
    cone_flag = 1;
    cylinder_flag = 0;
    torus_flag = 0;
    scene_flag = 0;
    repaint();
}


void MyWidget::ray_trace_cylinder(){
    triangle_flag = 0;
    sphere_flag = 0;
    cone_flag = 0;
    cylinder_flag = 1;
    torus_flag = 0;
    scene_flag = 0;
    repaint();
}

void MyWidget::ray_trace_torus(){
    triangle_flag = 0;
    sphere_flag = 0;
    cone_flag = 0;
    cylinder_flag = 0;
    torus_flag = 1;
    scene_flag = 0;
    repaint();
}

void MyWidget::ray_trace_scene(){
    triangle_flag = 0;
    sphere_flag = 0;
    cone_flag = 0;
    cylinder_flag = 0;
    torus_flag = 0;
    scene_flag = 1;
    repaint();
}
