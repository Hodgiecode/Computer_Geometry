#ifndef RAY_TRACER_H
#define RAY_TRACER_H

#include <math.h>
#include <vector>
#include <algorithm>
#include <iostream>

struct TColor
{
  unsigned short R;
  unsigned short G;
  unsigned short B;

  TColor() { }
  TColor(unsigned short iR, unsigned short iG, unsigned short iB) : R(iR), G(iG), B(iB) { }

  TColor apply_force(double lforce) const
  {
      unsigned short tR = std :: min(255, int(lforce * R));
      unsigned short tG = std :: min(255, int(lforce * G));
      unsigned short tB = std :: min(255, int(lforce * B));
      return TColor(tR, tG, tB);
  }

  ~TColor(){}
};

struct TVec3f
{
  double x;
  double y;
  double z;

  TVec3f() { }
  TVec3f(double iX, double iY, double iZ) : x(iX), y(iY), z(iZ) { }

  TVec3f operator+(const TVec3f& v) const
  {
    return TVec3f(x + v.x, y + v.y, z + v.z);
  }

  TVec3f operator-(const TVec3f& v) const
  {
    return TVec3f(x - v.x, y - v.y, z - v.z);
  }

  double operator*(const TVec3f& v) const
  {
    return x * v.x + y * v.y + z * v.z;
  }

  TVec3f operator*(const double& f) const
  {
    return TVec3f(x * f, y * f, z * f);
  }

  double length() const
  {
    return sqrt(x * x + y * y + z * z);
  }

  void Normalize()
  {
    double l = length();
    if(l > 0)
    {
      x /= l;
      y /= l;
      z /= l;
    }
  }
};

inline TVec3f operator*(const double& f, const TVec3f& v)
{
  return v * f;
}

/*---------------------------------------*/
struct Albedo {
    double i1;
    double i2;
    double i3;
    double i4;
    Albedo (const double &i_1, const double &i_2,
            const double &i_3, const double &i_4
            ): i1(i_1), i2(i_2), i3(i_3), i4(i_4) {}
};

struct Light {
    Light (const TVec3f &p, const double &i): position(p), intensity(i) {}
    TVec3f position;
    double intensity;
};

struct Material {
    double refractive_index = 1;
    Albedo albedo = Albedo(1,0,0,0);
    TVec3f diff_color=TVec3f(0,0,0);
    double specular_exponent = 0;
};

/*------------------------------*/


class TObject
{
protected:
   TColor color;
   Material material;
public:
   TObject() : color(0, 0, 0) { }
   TObject(const TColor& col) : color(col) { }
   TObject(const TColor& col, const Material &mat) : color(col), material(mat) { }
   const TColor& get_color() const { return color; }
   const Material& get_material() const { return material; }

   virtual bool IsIntersect(const TVec3f& ray_src,
                            const TVec3f& ray_dir,
                            double& tau) = 0;

   virtual bool IsIntersect(const TVec3f& ray_src,
                            const TVec3f& ray_dir,
                            double& tau,
                            TVec3f& pt,
                            TVec3f& nl) = 0;

   ~TObject(){}
};

class TTriangle : public TObject
{

public:
    TVec3f A;
    TVec3f B;
    TVec3f C;

    TTriangle(const TVec3f& iA, const TVec3f& iB, const TVec3f& iC, const TColor& col, const Material& mat) :
        TObject (col, mat), A(iA), B(iB), C(iC)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);

    ~TTriangle(){}
};

class TSphere : public TObject
{

public:
    TVec3f center;
    double R;

    TSphere(const TVec3f& iC, const double R_, const TColor& col, const Material& mat) :
        TObject (col, mat), center(iC), R(R_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);
};

class TCone : public TObject
{

public:
    TVec3f center;
    double H;
    double R;

    TCone(const TVec3f& iC, const double H_, const double R_, const TColor& col,const Material& mat) :
        TObject (col, mat), center(iC), H(H_), R(R_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);
};

class TCylinder : public TObject
{

public:
    TVec3f center_bottom;
    TVec3f center_top;
    double R;
    TVec3f center;
    TVec3f normal_;

    TCylinder(const TVec3f& iB, const TVec3f& iT, const double R_, const TColor& col, const Material& mat) :
        TObject (col, mat), center_bottom(iB), center_top(iT), R(R_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);
};

class TTorus : public TObject
{

public:
    TVec3f center;
    TVec3f axis;
    double r, R;

    TTorus(const TVec3f& iC,  const double R1, const double R2, const TVec3f& axis_, const TColor& col, const Material& mat) :
        TObject (col, mat), center(iC), r(R1), R(R2), axis(axis_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);
};

class TPlane : public TObject
{

public:
    TVec3f A;
    TVec3f B;
    TVec3f C;
    TVec3f D;
    TVec3f normal;

    TPlane(const TVec3f& A_,const TVec3f& B_,
           const TVec3f& C_,const TVec3f& D_,
           const TColor& col) :
           TObject (col), A(A_), B(B_), C(C_), D(D_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);

    bool inside(TVec3f &pt);
};




class SimpleScene
{

protected:

  double Vw;
  double Vh;
  double Dist;

  int CCx, CCy;

  int Cw;
  int Ch;

  int mode;

  double ambient_light;
  TColor ambient_color;

  TVec3f light_pos;
  double light_force;

public:
  std :: vector<TObject*> objects;
  std :: vector<TObject*> box;
  std::vector<Light> light_vector;

  SimpleScene(int W, int H, int M) : Cw(W), Ch(H), mode(M)
  {
      Vh = 1;
      Vw = double (Cw * Vh) / Ch; 1.0;

      Dist = 1;

      CCx = W / 2;
      CCy = H / 2;

      ambient_color = TColor(70, 70, 70);
      ambient_light = 0.2;


      Light light_data1(TVec3f(-1, 1, 0),1.8);
      Light light_data2(TVec3f(1, 0, 1),0.5);


      Light light_data3(TVec3f(-2, 2, 2.0), 1.5);
      Light light_data4(TVec3f(3, 5, -2.5), 1.8);
      Light light_data5(TVec3f(3, 2, 3), 1.7);

      light_vector.push_back(light_data3);
      light_vector.push_back(light_data4);
      light_vector.push_back(light_data5);

      Material mirror;
      mirror.refractive_index = 1;
      mirror.albedo = Albedo(0.0,10.0,0.8,0.0);
      mirror.diff_color = TVec3f(1,1,1);
      mirror.specular_exponent = 1425.0;


      if (M == 0){
        objects.push_back(new TSphere(TVec3f(0, 0, 5), 2, TColor(128, 0, 0), mirror));
      }

      if (M == 1){
        objects.push_back(new TTriangle(TVec3f(0, -0.05, 0.2), TVec3f(0.1, 0.05, 0.25),
                                        TVec3f(0.1, -0.06, 0.2), TColor(128, 0, 0), mirror));
        objects.push_back(new TTriangle(TVec3f(-0.1, 0.05, 0.4), TVec3f(0.1, 0.05, 0.25),
                                        TVec3f(0, -0.05, 0.2), TColor(128, 0, 0), mirror));
      }

      if (M == 2){
        objects.push_back(new TCone(TVec3f(0, -1.0, 5), 2, 2, TColor(128, 0, 0), mirror));
      }

      if (M == 3){
          objects.push_back(new TCylinder(TVec3f(0, 0, 5), TVec3f(0, -1.8, 5), 2, TColor(128, 0, 0), mirror));
      }

      if (M == 4){
        objects.push_back(new TTorus(TVec3f(0, 0, 5), 0.2, 0.8, TVec3f(-2, 0, 3), TColor(128, 0, 0), mirror));
      }

      if (M == 5){
         //центр
         box.push_back(new TPlane(TVec3f(-2,1.0,4),TVec3f(-2,-1.0,4),TVec3f(2,-1.0,4), TVec3f(2,1.0,4), TColor(100, 0, 100)));

         //боковые стенки
         box.push_back(new TPlane(TVec3f(-5,-4.0,4),TVec3f(-4.5,1.8,4),TVec3f(-2,1.0,4), TVec3f(-2,-1.0,4), TColor(0, 0, 255)));
         box.push_back(new TPlane(TVec3f(2,-1.0,4), TVec3f(2,1.0,4), TVec3f(5, 2.0,4), TVec3f(4,-3.0,4), TColor(0, 255, 0)));

         //пол и потолок
         box.push_back(new TPlane(TVec3f(-3,-1.0,4),TVec3f(-3,-2.0,4),TVec3f(3,-2.0,4), TVec3f(3,-1.0,4), TColor(0, 255, 255)));
         box.push_back(new TPlane(TVec3f(-2,-1.0,4), TVec3f(-5,2.0,4),TVec3f(5,2.0,4), TVec3f(5, 1.0,4), TColor(180, 0, 180)));

         objects.push_back(new TCylinder(TVec3f(-1.5, 0, 5), TVec3f(-1.5, -1.8, 5), 2, TColor(128, 0, 0), mirror));


         objects.push_back(new TTriangle(TVec3f(-1, -1.5, 5), TVec3f(1, -1, 5),
                                         TVec3f(0, -2, 5), TColor(128, 0, 0), mirror));
         objects.push_back(new TTriangle(TVec3f(-1, -1.5, 5), TVec3f(0, 0, 4),
                                         TVec3f(1, -1, 5), TColor(128, 0, 0), mirror));

         objects.push_back(new TSphere(TVec3f(1.5, -0.5, 5), 0.5, TColor(128, 0, 0), mirror));

         objects.push_back(new TCone(TVec3f(1.5, -1.5, 5), 0.5, 0.5, TColor(128, 0, 0), mirror));

      }

   }

  ~SimpleScene(){

      for (int i=0;i<objects.size();i++){
          delete objects[i];
      }

      objects.clear();

      for (int i=0;i<box.size();i++){
          delete box[i];
      }

      objects.clear();

  }

  TColor get_pixel(int x, int y);


};

#endif // RAY_TRACER_H
