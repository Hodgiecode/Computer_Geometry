#include "ray_tracer.h"

TColor SimpleScene ::  get_pixel(int x, int y){
    double rX = Vw * (x - CCx) / Cw;
    double rY = Vh * (CCy - y) / Ch;

    TVec3f ray_src(rX, rY, Dist);
    TVec3f ray_dir(rX, rY, Dist);


    bool intersect = false;
    double tau;
    TVec3f N;
    TVec3f P;
    TColor Col;

    for(size_t q(0); q < objects.size(); q++)
    {
      double tT;
      TVec3f tN;
      TVec3f tP;
      TColor tCol;

      if(objects[q]->IsIntersect(ray_src, ray_dir, tT, tP, tN))
      {
        if(!intersect || tT < tau)
        {
          tau = tT;
          N = tN;
          Col = objects[q]->get_color();
          P = tP;
        }

        intersect = true;
      }
    }

    if(!intersect)
      return ambient_color;

    TVec3f ldir = light_pos - P;
    ldir.Normalize();

    double lforce = ambient_light;
    double f = ldir * N;
    if(f > 0)
    {
      lforce += f * light_force;
    }

    return Col.apply_force(lforce);
 }

/*--------------- СФЕРЫ -----------------------------*/

bool TSphere :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau)
{

  double A = ray_dir * ray_dir;
  TVec3f v = (ray_src - center);
  double B = ray_dir * v;
  double C = v * v - R * R;

  double D4 = B * B - A * C;

  if(D4 < 0)
    return false;

  double t1 = (- B - sqrt(D4) ) / A;
  double t2 = (-B + sqrt(D4) ) / A;

  if(t1 < 0 && t2 < 0)
    return false;

  else if(t1 < 0)
   tau = t2;
  else
    tau = t1;

  return true;
}

bool TSphere :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl)
{
  if(IsIntersect(ray_src, ray_dir, tau))
  {
    pt = ray_src + tau * ray_dir;
    nl = pt - center;

    nl.Normalize();
    return true;
  }
  return false;
}

/*------------ ТРЕУГОЛЬНИКИ ----------------------------------*/

TVec3f crossProduct(TVec3f vect_A, TVec3f vect_B){
    TVec3f cross_P;
    cross_P.x = vect_A.y * vect_B.z - vect_A.z * vect_B.y;
    cross_P.y = vect_A.z * vect_B.x - vect_A.x * vect_B.z;
    cross_P.z = vect_A.x * vect_B.y - vect_A.y * vect_B.x;

    return cross_P;
}


bool TTriangle :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau){

    double eps = 1e-9;
    TVec3f e1 = B - A;
    TVec3f e2 = C - A;
    TVec3f p = crossProduct(ray_dir, e2);

    double a = e1 * p;
    if (a < eps && a < -eps){
        return false;
    }

    double f = 1 / a;
    TVec3f s = ray_src - A;
    double u = f * (s * p);

    if (u<0.0 || u>1.0){
        return false;
    }

    TVec3f q = crossProduct(s,e1);
    double v = f * (ray_dir * q);

    if (v<0.0 || u + v > 1.0){
        return false;
    }

    tau = f * (e2 * q);
    return true;
}

bool TTriangle :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl){

    if(IsIntersect(ray_src, ray_dir, tau))
    {
      pt = ray_src + tau * ray_dir;
      nl = crossProduct(B - A, C - A);
      nl.Normalize();
      return true;
    }

    return false;
}

/*---------------- КОНУС  ----------------------------*/

bool TCone :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau){

    double eps = 1e-9;

    TVec3f top;
    top.x = center.x;
    top.y = center.y + H;
    top.z = center.z;

    TVec3f axis	= (center - top);
    axis.Normalize();

    TVec3f bottomCenterToRayOrigin = ray_src - top;
    double rayDirectionDotAxis = ray_dir * axis;
    double bottomCenterToRayOriginDotAxis = bottomCenterToRayOrigin * axis;
    double radiansPerHeight = R / (center - top).length();

    TVec3f u = ray_dir + axis * (-rayDirectionDotAxis);
    TVec3f v = bottomCenterToRayOrigin + axis * (-bottomCenterToRayOriginDotAxis);
    double  w = bottomCenterToRayOriginDotAxis * radiansPerHeight;
    double	radiansPerDirection = rayDirectionDotAxis * radiansPerHeight;

    double a = u * u - radiansPerDirection * radiansPerDirection;
    double closestRoot = -1;
    double root		= 0;

    if (fabs(a) > eps) {
        double b = 2 * (u * v - w * radiansPerDirection);
        double c = v * v - w * w;
        double d = b * b - 4 * a * c;

        if (d < 0.0) {
          return false;
        }


        root = (-b - sqrt(d))/(2.0 * a);

        if (root > 0.0) {
          TVec3f point = ray_src + root * ray_dir;
          TVec3f bottomCenterToPoint = point - top;
          TVec3f topToPoint = point - center;

          if ((axis * bottomCenterToPoint) > 0.0 && ((-1)*axis * topToPoint) > 0.0) {
            closestRoot = root;
          }
        }

        root = (-b + d)/(2 * a);

        if (root > 0.0) {
          TVec3f point = ray_src + root * ray_dir;
          TVec3f bottomCenterToPoint = top;
          TVec3f topToPoint = point - center;

          if ((axis * bottomCenterToPoint) > 0.0 && ((-1)*axis * topToPoint) > 0.0) {
            if (closestRoot < 0.0) {
              closestRoot = root;
            } else if (root < closestRoot) {
              closestRoot = root;
            }
          }
        }
    }

    if (fabs(rayDirectionDotAxis) < eps) {
        if (closestRoot > 0.0) {
          tau = closestRoot;
          return true ;
        }

        return false;
    }

    root = ((-1)*axis)*(ray_src - center) / rayDirectionDotAxis;
    if (root > 0.0){
        TVec3f topToPoint = ray_src + root * ray_dir - center;
        if ((topToPoint * topToPoint) < R * R)
        {

          if (closestRoot < 0.0) {
            closestRoot = root;
          } else if (root < closestRoot) {
            closestRoot = root;
          }
        }
     }

    if (closestRoot > 0.0) {
        tau = closestRoot;
        return true ;
    }

    return false;
}

bool TCone :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl){

    TVec3f top;
    top.x = center.x;
    top.y = center.y + H;
    top.z = center.z;

    double eps = 1e-9;

    if(IsIntersect(ray_src, ray_dir, tau))
    {
      TVec3f axis	= (center - top);
      axis.Normalize();
      pt = ray_src + tau * ray_dir;

      TVec3f  pointPositionRelativelyToBottom	= pt - center;
      if (fabs(axis * (pointPositionRelativelyToBottom)) < eps &&
            (pointPositionRelativelyToBottom * pointPositionRelativelyToBottom) < R * R) {
          nl = axis;
      } else {
          TVec3f approximatedNormal = pt - (axis * (pt - center)*(axis) + center);
          double radiansPerHeight = R / (center - top).length();

          nl = approximatedNormal + axis * (-radiansPerHeight * approximatedNormal.length());
          nl.Normalize();
      }


      return true;
    }

    return false;
}

/*---------------- ЦИЛИНДР ----------------------------*/

double cap_hit(TVec3f c, TVec3f N, TVec3f ray_src, TVec3f ray_dir, double r) {
    double t = -1;

    double ldotn = ray_dir * N;
    if (ldotn > 0) {
        t = ((c - ray_src)* N) / ldotn;
        TVec3f ip = ray_src + t * ray_dir;
        bool v = (ip - c)*(ip - c) < r*r;
        if (!v) {
            t = -1;
        }
    }

    return t;
}

bool TCylinder :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau){

    TVec3f h = center_top - center_bottom;
    TVec3f a_bottom = ray_src - center_bottom;
    TVec3f a_bottom_h = crossProduct(a_bottom, h);
    TVec3f ray_dir_h = crossProduct(ray_dir, h);

    double h2 = h * h;

    double a = ray_dir_h * ray_dir_h;
    double b = 2 * ray_dir_h * a_bottom_h;
    double c = a_bottom_h * a_bottom_h - (R * R - h2);
    double d = b * b - 4 * a * c;

    tau = -1;
    double t2;

    TVec3f ip;

    if (d>=0){
        tau = (-b - sqrt(d))/(2*a);
        t2 = (-b + sqrt(d))/(2*a);

        if (t2 < tau && t2 >= 0) {
            tau = t2;
        }

        if (tau >=0){
            ip = ray_src + tau * ray_dir;
            TVec3f h_ = center_top - center_bottom;
            bool v = h_ * (ip - center_bottom) > 0 && h_ * (ip - center_top) < 0;
            if (!v){
                tau = -1;
            }
        }
    }

    TVec3f v = ip - center_bottom;
    TVec3f tmp = (v * h * h);
    tmp.x = tmp.x / (h*h);
    tmp.y = tmp.y / (h*h);
    tmp.z = tmp.z / (h*h);

    normal_ = v - tmp;

    TVec3f ncap = center_top - center_bottom;
    double tcap = cap_hit(center_bottom, ncap, ray_src, ray_dir, R);

    if ((tcap >= 0 && tcap < tau) || tau < 0) {
        tau = tcap;
        normal_ = ncap;
    }

    ncap = (center_bottom - center_top);
    tcap = cap_hit(center_top, ncap, ray_src, ray_dir, R);

    if ((tcap >= 0 && tcap < tau) || tau < 0) {
        tau = tcap;
        normal_ = ncap;
    }

    if (tau < 0) {
        return false;
    }

    return true;
}

bool TCylinder :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl){

    if(IsIntersect(ray_src, ray_dir, tau))
    {
       pt = ray_src + tau * ray_dir;
       nl = normal_;
       nl.Normalize();
       return true;
    }

    return false;
}
/*------------------- ТОР ---------------------------*/



bool TTorus :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau){

    TVec3f centerToRayOrigin = ray_src - center;
    double centerToRayOriginDotDirection = ray_dir * centerToRayOrigin;
    double	centerToRayOriginDotDirectionSquared = centerToRayOrigin * centerToRayOrigin;
    double innerRadiusSquared = r * r;
    double outerRadiusSquared = R * R;

    double axisDotCenterToRayOrigin	= axis * centerToRayOrigin;
    double	axisDotRayDirection = axis * ray_dir;
    double	a = 1 - axisDotRayDirection * axisDotRayDirection;
    double	b = 2 * (centerToRayOrigin * ray_dir - axisDotCenterToRayOrigin * axisDotRayDirection);
    double c = centerToRayOriginDotDirectionSquared - axisDotCenterToRayOrigin * axisDotCenterToRayOrigin;
    double	d = centerToRayOriginDotDirectionSquared + outerRadiusSquared - innerRadiusSquared;

    double A = 1;
    double B = 4 * centerToRayOriginDotDirection;
    double C = 2 * d + B * B * 0.25f - 4 * outerRadiusSquared * a;
    double D = B * d - 4 * outerRadiusSquared * b;
    double E = d * d - 4 * outerRadiusSquared * c;

    double a3 = A * A * A;
    double a2 = A * A;
    double b4 = B * B * B * B;
    double b3 = B * B * B;
    double b2 = B * B;
    double c3 = C * C * C;
    double c2 = C * C;
    double d2 = D * D;

    double delta;
    double P = 8 * A * C - 3 * b2;

    double R_ = b3 + 8 * D * a2 - 4 * A * B * C;
    double delta0 = c2 - 3.0 * B * D + 12.0 * A * E;
    double delta1 = 2.0 * c3 - 9.0 * B * C * D + 27.0 * b2 * E + 27.0 * A * d2 - 72.0 * A * C * E;
    double D_ = 64 * a3 * E - 16 * a2 * c2 + 16 * A * b2 * C - 16 * a2 * B * D - 3 * b4;

    double p = (P / (8 * a2));
    double q = (R_ / (8 * a3));
    double y = (delta1 * delta1 - 4 * delta0 * delta0 * delta0);

    delta = y / -27;
    double qrt = sqrt(y);
    double Q = cbrt(((delta1 + qrt) / 2.0));
    double S;
    double fi = 0;

     if (delta > 0) {
        fi = acos((delta1) / (2 * sqrt(delta0 * delta0 * delta0)));
        S = 0.5f * sqrt(-(2.0f / 3.0f) * p +
                            (2.0f / (3.0f * a)) * sqrt(delta0) * cos(fi / 3.0f));
     } else {
         S = 0.5 * sqrt((-2.0 / 3.0) * p + (1.0 / (3.0 * A)) * (Q + delta0 / Q));
     }

     double rt0 = sqrt(-4 * S * S - 2 * p + (q / S));
     double rt1 = sqrt(-4 * S * S - 2 * p - (q / S));
     double z0 = -(B / (4 * A)) - S + 0.5 * rt0;
     double z1 = -(B / (4 * A)) - S - 0.5 * rt0;
     double z2 = -(B / (4 * A)) + S + 0.5 * rt1;
     double z3 = -(B / (4 * A)) + S - 0.5 * rt1;

     tau = INT_MAX;

     double t_min = 0;
     double t_max = 0;

     if (z0 <= tau && z0 > t_min) { tau = z0; }

     if (z1 <= tau && z1 > t_min) { tau = z1; }

     if (z2 <= tau && z2 > t_min) { tau = z2; }

     if (z3 <= tau && z3 > t_min) { tau = z3; }

     if (tau == INT_MAX){
         return false;
     }

     return true;
}

bool TTorus :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl){

    if(IsIntersect(ray_src, ray_dir, tau))
    {
       pt = ray_src + tau * ray_dir;
       TVec3f centerToPoint = pt - center;
       double	centerToPointDotAxis = centerToPoint * axis;
       TVec3f direction = centerToPoint - axis * centerToPointDotAxis;
       direction.Normalize();
       nl = pt - center + direction * R;
       nl.Normalize();
       return true;
    }

    return false;
}
