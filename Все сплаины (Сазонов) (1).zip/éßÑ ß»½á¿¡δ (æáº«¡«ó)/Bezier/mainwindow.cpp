#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "drawwidget.h"
#include "QMessageBox"



MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->draw_widget->SetPointContainers(&construct_points,
                                        &curve_points,
                                        &tangent_vectors,
                                        &point_weights);

    QObject::connect(ui->draw_widget, SIGNAL(pointChanged(int)),
               this, SLOT(on_ConstrucPointChange(int)));

    QObject::connect(ui->draw_widget, SIGNAL(selectedPointChanged(int)),
               this, SLOT(on_SelectedPointChange(int)));

    CurrentCurveType = NO_CURVE;

    // ������ ���� ������ � ���� ������
    ui->curveTypeComboBox->addItem(QString("No curve"), QVariant(NO_CURVE));
    ui->curveTypeComboBox->addItem(QString("Bezier"), QVariant(BEZIER));
    ui->curveTypeComboBox->addItem(QString("DE-Castelie Bezier"), QVariant(DE_CASTELIE));
    ui->curveTypeComboBox->addItem(QString("Rational Bezier curve"), QVariant(RATIONAL_BEZIER));
    ui->curveTypeComboBox->addItem(QString("Hermite spline"), QVariant(HERMIT));
    ui->curveTypeComboBox->addItem(QString("Cubic spline"), QVariant(CUBIC_SPLINE));
    ui->curveTypeComboBox->addItem(QString("Lagrange spline"), QVariant(LAGRANGE));
    ui->curveTypeComboBox->addItem(QString("Pseudo elastic Hermite spline"), QVariant(PSEUDO_ELASTIC));

    SelectedPointNum = -1;
    ui->paramSlider->setRange(0, macro_max_weight);
    ui->paramSlider->setValue(macro_default_weight);

    ui->paramSlider->setEnabled(false);
    ui->paramValue->setEnabled(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButtonSetConstructPoints_clicked()
{
  ui->draw_widget->SetAddPointFlag(true);
}

std::vector<double>solve(const std::vector<double>&a,
                         const std::vector<double>&b,
                         const std::vector<double>&c,
                         const std::vector<double>&d)
{
    std::vector<double>mod_b;
    mod_b.resize(b.size());
    mod_b[0]=b[0];
    for(int q = 1; q < b.size();q++){
        mod_b[q] = b[q]-c[q-1]*a[q]/b[q-1];
    }
    std::vector<double>ret;
    ret.resize(a.size());
    ret.back()=d.back()/mod_b.back();
    for(int l = d.size()-2;l>=0;l--){
        ret[l]=(d[l]-c[l]*ret[l+1])/mod_b[l];
    }
    return ret;
}


                              /////// Bezier ///////////


void MainWindow::compute_bezier_coeff(size_t num)
{
  if(num < 2)
    return;

  bezier_coeff.resize(num);
  bezier_coeff[0] = 1;
  bezier_coeff[1] = 1;
  std :: vector<int> sub_array;
  sub_array.resize(num);
  for(size_t cur_size = 3; cur_size <= num; cur_size++)
  {
    sub_array[0] = 1;
    sub_array[cur_size - 1] = 1;
    for(size_t t(1); t < cur_size -1; t++)
    {
      sub_array[t] = bezier_coeff[t - 1] + bezier_coeff[t];
    }

    bezier_coeff = sub_array;
  }
}

TPoint bezier_point_get(const std :: vector<TPoint>& pts,
                        const std :: vector<int>& coeff,
                        double t)
{
  TPoint ret(0, 0);
  int n = pts.size();

  for(int q(0); q < n; q++)
    ret = ret + coeff[q] * pow(t, q) * pow(1 - t, n - q - 1) * pts[q];

  return ret;
}


void MainWindow::compute_bezier_curve()
{
  if(bezier_coeff.empty())
    return;


  double step = 1.0 / (curve_points_num - 1);
  curve_points.resize(curve_points_num);

  for(size_t q(0); q < curve_points_num; q++)
  {
      curve_points[q]=de_castelie_get(0,double(q)/curve_points_num,construct_points.size()-1);
    //curve_points[q] = bezier_point_get(construct_points, bezier_coeff, step * q);
  }
}

                  ///////////////////////  Cubic    /////////////////////


std::vector <double> new_parametr(std::vector <TPoint>& c_points, int x)
{
    std::vector <double> tmp(c_points.size());
    tmp[0] = 0;
    for (int i = 1; i < c_points.size(); i++)
    {
        if (x == 0)
            tmp[i] = tmp[i - 1] + (c_points[i] - c_points[i - 1]).length();
        else tmp[i] = i;
    }

    return tmp;
}

std::vector <TPoint> GausCub(std::vector <double> &A, std::vector <double> &B, std::vector <double> &C, std::vector <TPoint> &D)
{
    int i;
    int vectorSize = D.size();
    for (i = 2; i < vectorSize; i++)
    {
        B[i] = B[i] - C[i - 1] * (A[i] / B[i - 1]);
        D[i] = D[i] - D[i - 1] * (A[i] / B[i - 1]);
    }

    std::vector <TPoint> X(vectorSize);
    X[vectorSize - 1] = D[vectorSize - 1] * (1/ B[vectorSize - 1]);
    for (i = vectorSize - 2; i > 0; i--)
    {
        X[i] = (D[i] - C[i] * X[i + 1]) * (1/ B[i]);
    }

    return X;
}

std::vector <TPoint> coefS(std::vector <TPoint>& c_points, std::vector <double> par_t)
{
    int sz = c_points.size();
    int i;
    TPoint null_elem(0,0);
    std::vector <TPoint> tmpSVec(sz), D(sz - 1);
    std::vector <double> A(sz - 1), B(sz - 1), C(sz - 1), X(sz), Y(sz);

    TPoint a, b;

    for (i = 1; i < sz - 1; i++)
    {
        a = 6*((c_points[i + 1] - c_points[i]) *(1/ (par_t[i + 1] - par_t[i])));
        b = 6*((c_points[i] - c_points[i - 1]) *(1/ (par_t[i] - par_t[i - 1])));

        if (i > 1) {
            A[i - 1] = par_t[i] - par_t[i - 1];
        }

        B[i] = 2 * (par_t[i + 1] - par_t[i - 1]);
        C[i] = par_t[i + 1] - par_t[i];
        D[i] = a - b;
    }
    tmpSVec = GausCub(A, B, C, D);

    tmpSVec.resize(sz);
    tmpSVec[sz - 1] = null_elem;
    tmpSVec[0] = null_elem;

    return tmpSVec;
}

TPoint cubic_curve_point_get(std::vector <TPoint>& c_points, double t, std::vector <double> par_t, std::vector <TPoint>& S)
{
    int i;
    TPoint tmpSVec(0, 0);
    double w;
    for (i = 0; i < par_t.size() - 1; i++)
    {
        if (t >= par_t[i] && t <= par_t[i + 1])
        {
            w = (t - par_t[i]) / (par_t[i + 1] - par_t[i]);
            break;
        }
    }
    TPoint a, b, c, d;
    double e;
    a = (1 - w) * c_points[i];
    b = w * c_points[i + 1];
    c = (-2 * w + 3 * w * w - w * w * w) * S[i];
    d = (-w + w * w *w) * S[i + 1];
    e = ((par_t[i + 1] - par_t[i]) * (par_t[i + 1] - par_t[i])) / 6;

    tmpSVec = a + b + (c + d) * e;

    return tmpSVec;
}

void MainWindow::compute_cubic_curve(){
    double t = 0.0;
    std::vector <double> parameter_t;
    parameter_t = new_parametr(construct_points, 0);
    std::vector <TPoint> S;

    S = coefS(construct_points, parameter_t);

    double step = (parameter_t[parameter_t.size() - 1] - 1) / (curve_points_num - 1);
    curve_points.resize(curve_points_num);


    for(int q(0); q < curve_points_num; q++, t += step)
    {
       curve_points[q] = cubic_curve_point_get(construct_points, t, parameter_t, S);
    }
}




/////////////////////            De Castelie              ////////////////////
void MainWindow::compute__de_castelie_bezier_coeff(size_t num)
{
  if(num < 2)
    return;

  bezier_coeff.resize(num);
  bezier_coeff[0] = 1;
  bezier_coeff[1] = 1;
  std :: vector<int> sub_array;
  sub_array.resize(num);
  for(size_t cur_size = 3; cur_size <= num; cur_size++)
  {
    sub_array[0] = 1;
    sub_array[cur_size - 1] = 1;
    for(size_t t(1); t < cur_size -1; t++)
    {
      sub_array[t] = bezier_coeff[t - 1] + bezier_coeff[t];
    }

    bezier_coeff = sub_array;
  }
}

TPoint MainWindow::de_castelie_get(int i, double t, int k){
    if(k==0)
        return construct_points[i];
    return (1-t)*de_castelie_get(i,t,k-1)+t*de_castelie_get(i+1,t,k-1);
}


TPoint de_castelie_point_get(const std :: vector<TPoint>& pts,
                        const std :: vector<int>& coeff,
                        double t)
{
  TPoint ret(0, 0);
  int n = pts.size();

  for(int q(0); q < n; q++)
    ret = ret + coeff[q] * pow(t, q) * pow(1 - t, n - q - 1) * pts[q];

  return ret;
}

void MainWindow::compute_de_castelie_bezier_curve()
{
  if(bezier_coeff.empty())
    return;

  double step = 1.0 / (curve_points_num - 1);
  curve_points.resize(curve_points_num);

  for(size_t q(0); q < curve_points_num; q++)
  {
      curve_points[q]=de_castelie_get(0,double(q)/curve_points_num,construct_points.size()-1);
    //curve_points[q] = bezier_point_get(construct_points, bezier_coeff, step * q);
  }

  ui->draw_widget->update();
}





///////////////////         Rational Bezier      ///////////////////////
double MainWindow::rational_bezier_weights(int i, double t, int k)
{
    if(k==0)
        return point_weights[i];
    return (1-t)*rational_bezier_weights(i,t,k-1)+t*rational_bezier_weights(i+1,t,k-1);
}

TPoint MainWindow::rational_bezier_point_get(int i, double t, int k)
{
    if(k==0)
        return point_weights[i]*construct_points[i]*(1/rational_bezier_weights(0,t,construct_points.size()-1));
    return (1-t)*rational_bezier_point_get(i,t,k-1)+t*rational_bezier_point_get(i+1,t,k-1);
}

void MainWindow::compute_rational_bezier_curve()
{
  if(bezier_coeff.empty())
    return;

  double step = 1.0 / (curve_points_num - 1);
  curve_points.resize(curve_points_num);

  for(size_t q(0); q < curve_points_num; q++)
  {
      curve_points[q]=rational_bezier_point_get(0,double(q)/curve_points_num,construct_points.size()-1);
  }

  ui->draw_widget->update();
}





//////////////////                Lagrange        /////////////////////////
double L_i(int i, int n, double t){
    double ret = 1.0;
    for(int q = 0; q < n; q++)
        if(q != i)
            ret *= ((t - q)/(i - q));
    return ret;
}

TPoint lagrange_point_get(const std::vector<TPoint>&pts, double t){
    TPoint ret(0,0);
    int n = pts.size();
    for(int i = 0; i < n; i++)
        ret = ret + L_i(i,n,t)*pts[i];
    return ret;
}

void MainWindow::compute_lagrange_curve(){
    int n = construct_points.size();
    double step = (double(n-1-0))/(curve_points_num - 1);
    curve_points.resize(curve_points_num);
    for(size_t q(0); q < curve_points_num; q++)
        curve_points[q] = lagrange_point_get(construct_points, step*q);
}






//////////////////////////////////   Hermit  ///////////////////////////////////////////////////



void MainWindow::compute_hermite_coeff(const std :: vector<TPoint>& pts)
{
  int num = pts.size();
  if(num < 2)
    return;

  hermite_coeff.resize(num);

  std :: vector<double> t_array;
  t_array.resize(num);
  t_array[0] = 0.0;
  for(size_t i = 1; i < num; i++) {
    t_array[i] = (pts[i] - pts[i-1]).length() + t_array[i-1];
  }
  hermite_coeff = t_array;
}

TPoint hermite_point_get(const std :: vector<TPoint>& pts,
                        const std :: vector<double>& coeff,
                        const std :: vector<TPoint>& tan,
                        double t)
{
  TPoint ret(0, 0);
  int n = pts.size();

  int curve_portion_num = -1;
  if(t >= coeff.back())
    return pts.back();

  for(int q(0); q < coeff.size() - 1; q++)
  {
    if(t >= coeff[q] && t < coeff[q + 1])
      curve_portion_num = q;
  }

  if(curve_portion_num < 0)
     throw 1;

  double w = (t - coeff[curve_portion_num]) / (coeff[curve_portion_num+ 1] - coeff[curve_portion_num]);
  double g0 = 1 - 3.0*pow(w,2) + 2.0*pow(w,3);
  double g1 = w - 2.0*pow(w,2) + pow(w,3);
  double h0 = 3.0*pow(w,2) - 2.0*pow(w,3);
  double h1 = -pow(w,2) + pow(w,3);
  return g0* pts[curve_portion_num] + 1000 * g1*tan[curve_portion_num] +
          h0*pts[curve_portion_num+1] + 1000 * h1*tan[curve_portion_num+1];

}



void MainWindow::compute_hermite_spline()
{
  if(hermite_coeff.empty())
    return;

  double step = (hermite_coeff.back() - hermite_coeff.front()) / (curve_points_num - 1);
  curve_points.resize(curve_points_num);

  for(size_t q(0); q < curve_points_num; q++)
  {
    curve_points[q] = hermite_point_get(construct_points, hermite_coeff, tangent_vectors, hermite_coeff[0] +(step * q));
  }
  ui->draw_widget->update();
}




////////////////////////// Elastic ////////////////////////////////////

TPoint MainWindow::elastic_point_get(double t)
{
    int cnum=-1;
    if(t<0)
        return construct_points.front();
    if(t>=t_construct.back())
        return construct_points.back();
    for(int q = 0; q < construct_points.size()-1; q++){
        if(t>=t_construct[q]&&t<t_construct[q+1]){
            cnum = q;
            break;
        }
    }
    double w = (t-t_construct[cnum])/(t_construct[cnum+1]-t_construct[cnum]);
    double g0 = 1 - 3.0*pow(w,2) + 2.0*pow(w,3);
    double g1 = w - 2.0*pow(w,2) + pow(w,3);
    double h0 = 3.0*pow(w,2) - 2.0*pow(w,3);
    double h1 = -pow(w,2) + pow(w,3);
    return construct_points[cnum]*g0+g1*derivatives[cnum]+construct_points[cnum+1]*h0+derivatives[cnum+1]*h1;
}

void MainWindow::compute_pseudo_elastic()
{
    //��������� �������� t
    t_construct.resize(construct_points.size());
    t_construct.front()=0;
    for(int q=1;q<t_construct.size();q++)
        t_construct[q]=t_construct[q-1]+(construct_points[q]-construct_points[q-1]).length();
    //������� ����������� � ������� ������
    std::vector<double>a,b,c,d,x_new,y_new;
    a.resize(construct_points.size());
    b.resize(construct_points.size());
    c.resize(construct_points.size());
    d.resize(construct_points.size());
    x_new.resize(construct_points.size());
    y_new.resize(construct_points.size());
    derivatives.resize(construct_points.size());

    std::vector<double>k;
    k.resize(construct_points.size());

    a.front()=0;
    b.front()=2;
    c.back()=0;
    k.front()=0;
    k.back()=1;

    for(int q = 1; q < construct_points.size()-1;q++){
        k[q]=(t_construct[q]-t_construct[q-1])/(t_construct[q+1]-t_construct[q]);
    }

    c.front()=k[1];
    d.front()=3*(construct_points[1].x-construct_points[0].x);
    a.back()=1;
    b.back()=2;
    d.back()=3*(construct_points[construct_points.size()-1].x-construct_points[construct_points.size()-2].x);;

    for(int q = 1;q < construct_points.size()-1;q++)
    {
        a[q]=1;
        b[q]=2*(k[q]+k[q]*k[q]);
        c[q]=k[q]*k[q];//*k[q+1];
        d[q]=3*(construct_points[q]-construct_points[q-1]).x+
             3*(construct_points[q+1]-construct_points[q]).x*k[q]*k[q];
    }

    x_new=solve(a,b,c,d);
    for(int q = 0; q < construct_points.size();q++)
        derivatives[q].x=x_new[q];

    for(int q = 1;q < construct_points.size()-2;q++)
    {
        d[q]=3*(construct_points[q]-construct_points[q-1]).y+
             3*(construct_points[q+1]-construct_points[q]).y*k[q]*k[q];
    }

    y_new=solve(a,b,c,d);
    for(int q = 0; q < construct_points.size();q++)
        derivatives[q].y=y_new[q];

    //������� ��� ����� ������
    int n = construct_points.size();
    double step = (t_construct.back()-t_construct.front())/(curve_points_num - 1);
    curve_points.resize(curve_points_num);
    for(size_t q(0); q < curve_points_num; q++)
        curve_points[q] = elastic_point_get(step*q);
}



void MainWindow::BuildCurve()
{
  CurrentCurveType = ui->curveTypeComboBox->currentData().toInt();
  switch(CurrentCurveType)
  {
    case BEZIER:
      compute_bezier_coeff(construct_points.size());
      compute_bezier_curve();

    break;

  case DE_CASTELIE:
    compute__de_castelie_bezier_coeff(construct_points.size());
    compute_de_castelie_bezier_curve();
break;
    case RATIONAL_BEZIER:
      compute_bezier_coeff(construct_points.size());
      compute_rational_bezier_curve();
      break;

    case CUBIC_SPLINE:
      compute_cubic_curve();
    break;

    case HERMIT:
      compute_hermite_coeff(construct_points);
      compute_hermite_spline();
    break;

    case LAGRANGE:
      compute_lagrange_curve();
    break;

    case PSEUDO_ELASTIC:
      compute_pseudo_elastic();
      break;

    case NO_CURVE:
    break;

    default: QMessageBox::information(this, QString("Error"),
                                    QString("This curve isn't realized"),
                                    QMessageBox::Ok);
  }
  ui->draw_widget->repaint();
}

void MainWindow::on_pushButtonBuildCurve_clicked()
{
  BuildCurve();
}

void MainWindow::on_ConstrucPointChange(int s)
{
  BuildCurve();
}

void MainWindow::ActivateSliderForWeights(int q)
{
  if(q >= 0)
  {
    ui->paramSlider->setEnabled(true);
    //ui->paramValue->setEnabled(true);
    ui->paramSlider->setValue(point_weights[q]);
    ui->paramValue->setText(QString::number(point_weights[q]));
  }
  else
  {
    ui->paramSlider->setEnabled(false);
    //ui->paramValue->setEnabled(false);
  }
}

void MainWindow::on_SelectedPointChange(int s)
{
  SelectedPointNum = s;
  ActivateSliderForWeights(s);
}

int delta(int i, int j)
{
  return (i == j) ? 1 : 0;
}

void MainWindow::on_pushButton_4_clicked()
{
  if(bezier_coeff.size() && CurrentCurveType == BEZIER)
  {
    std :: vector<TPoint> new_constr;
    new_constr.resize(construct_points.size() + 1);
    new_constr[0] = construct_points[0];
    new_constr.back() = construct_points.back();
    int n = construct_points.size() - 1;
    for(size_t q(1); q < construct_points.size(); q++)
    {
      new_constr[q] = (double(n + 1 - q) / (n + 1)) * construct_points[q] * (1 - delta(n + 1, q))+
                      (double(q) / (n+1)) * construct_points[q - 1] * (1 - delta(0, q));
    }

    construct_points = new_constr;
    BuildCurve();
  }
}

void MainWindow::on_paramSlider_actionTriggered(int action)
{
  //ui->draw_widget->SetDrawWeights(ui->checkBoxDrawWeights->isChecked());
  double d = (point_weights[SelectedPointNum] = ui->paramSlider->value());
  ui->paramValue->setText(QString::number(d));
  ui->draw_widget->repaint();
}

void MainWindow::on_checkBoxDrawTangents_stateChanged(int arg1)
{
  ui->draw_widget->SetDrawTangents(ui->checkBoxDrawTangents->isChecked());
  ui->draw_widget->repaint();
}

void MainWindow::on_checkBoxDrawWeights_stateChanged(int arg1)
{
  ui->draw_widget->SetDrawWeights(ui->checkBoxDrawWeights->isChecked());
  ui->draw_widget->repaint();
}

void MainWindow::on_pushButtonRemovePoint_clicked()
{
  if(SelectedPointNum)
  {
    tangent_vectors.erase(tangent_vectors.begin() + SelectedPointNum);
    construct_points.erase(construct_points.begin() + SelectedPointNum);
    point_weights.erase(point_weights.begin() + SelectedPointNum);
    BuildCurve();
  }
}
