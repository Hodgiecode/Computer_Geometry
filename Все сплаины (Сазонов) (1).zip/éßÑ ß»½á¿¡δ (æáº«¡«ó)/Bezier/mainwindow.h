#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "math_lib2d.h"

namespace Ui {
class MainWindow;
}

enum { NO_CURVE = -1,
       BEZIER = 0,
       LAGRANGE = 1,
       HERMIT = 2,
       DE_CASTELIE,
       RATIONAL_BEZIER,
       CUBIC_SPLINE,
       BEZIER_SPLINE,
       RATIONAL_BEZIER_SPLINE,
       PSEUDO_ELASTIC
     };

const size_t curve_points_num = 100;
class MainWindow : public QMainWindow
{
    Q_OBJECT
    std :: vector<TPoint> derivatives;
    std :: vector<TPoint> tangent_vectors;
    std :: vector<TPoint> construct_points;
    std :: vector<TPoint> curve_points;
    std :: vector<double> point_weights;
    std :: vector<double> t_construct;

    std :: vector<int> bezier_coeff;
    std :: vector<double> hermite_coeff;
    int CurrentCurveType;
    int SelectedPointNum;

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_pushButtonSetConstructPoints_clicked();

    void on_pushButtonBuildCurve_clicked();
    void on_ConstrucPointChange(int s);
    void on_SelectedPointChange(int s);

    void on_pushButton_4_clicked();

    void on_paramSlider_actionTriggered(int action);

    void on_checkBoxDrawTangents_stateChanged(int arg1);

    void on_checkBoxDrawWeights_stateChanged(int arg1);

    void on_pushButtonRemovePoint_clicked();

    void BuildCurve();

private:
    Ui::MainWindow *ui;

    void compute_bezier_coeff(size_t num);
    void compute_bezier_curve();
    void compute_rational_bezier_curve();
    void compute_hermite_coeff(const std::vector<TPoint>&pts);
    void compute_hermite_spline();
    void compute_lagrange_curve();
    void compute__de_castelie_bezier_coeff(size_t num);
    void compute_de_castelie_bezier_curve();
    void compute_cubic_curve();
    void compute_pseudo_elastic();
    TPoint cubic_point_get(double t,int q);
    TPoint elastic_point_get(double t);
    TPoint de_castelie_get(int i, double t, int k);
    TPoint bezier_point_get(int i, double t, int k);
    TPoint rational_bezier_point_get(int i, double t, int k);
    double rational_bezier_weights(int i, double t, int k);
    void ActivateSliderForWeights(int q);
};

#endif // MAINWINDOW_H
