#include "drawwidget.h"
#include <QMouseEvent>
#include <QPainter>

const int font_size = 24;

int circ_size = 20;
int small_circ_size = 15;
int mark_size = 20;
int tangent_size = 80;

DrawWidget::DrawWidget(QWidget *parent) :
    QWidget(parent), F2draw("Times new roman", font_size), FM2draw(F2draw)
{
  construct_points = 0;
  curve_points = 0;
  add_points_flag = false;
  move_point_flag = false;
  move_point_num = -1;
  selected_point_num = -1;
  m_bdraw_tangents = true;
  m_bdraw_weights = true;
  edited_tangent = -1;
}

void DrawWidget::mousePressEvent(QMouseEvent * event)
{
  if(event->button() == Qt::LeftButton)
  {
    if(add_points_flag)
    {
      cursor_location = TPoint(event->x(), event->y());
      construct_points->push_back(cursor_location);
      point_weights->push_back(macro_default_weight);
      tangent_vectors->push_back(TPoint(1, 0));
      repaint();
    }
    else
    {
      // Проверяем, не попало ли в радиус
      cursor_location = TPoint(event->x(), event->y());
      for(size_t q(0); q < construct_points->size(); q++)
      {
        const TPoint& pt((*construct_points)[q]);
        if((cursor_location - pt).length() < circ_size)
        {
          move_point_flag = true;
          move_point_num = q;
          setMouseTracking(true);
          setCursor(Qt::DragMoveCursor);
          break;
        }
      }

      if(!move_point_flag)
      {
        for(size_t q(0); q < construct_points->size(); q++)
        {
          const TPoint& pt((*construct_points)[q]);
          if((cursor_location - pt - tangent_size * (*tangent_vectors)[q]).length() < small_circ_size)
          {
            edited_tangent = q;
            setMouseTracking(true);
            setCursor(Qt::DragMoveCursor);
            break;
          }
        }
      }
    }
  }
  else if(event->button() == Qt::MidButton)
  {

  }
  else if(event->button() == Qt::RightButton)
  {
    if(add_points_flag)
    {
      SetAddPointFlag(false);
      setCursor(Qt::ArrowCursor);
      repaint();
    }
  }
}

void DrawWidget::mouseMoveEvent(QMouseEvent * event)
{
  if(add_points_flag)
  {
    cursor_location = TPoint(event->x(), event->y());
    repaint();
  }
  else if(move_point_flag)
  {
    cursor_location = TPoint(event->x(), event->y());
    TPoint & pt((*construct_points)[move_point_num]);
    pt.x = cursor_location.x;
    pt.y = cursor_location.y;
    repaint();
  }
  else if(edited_tangent >= 0)
  {
    cursor_location = TPoint(event->x(), event->y());
    const TPoint & pt((*construct_points)[edited_tangent]);
    TPoint & tgpt((*tangent_vectors)[edited_tangent]);
    TPoint vec(cursor_location.x - pt.x, cursor_location.y - pt.y);
    vec.Normalize();
    tgpt = vec;

    repaint();
  }

}

void DrawWidget::mouseReleaseEvent(QMouseEvent * event)
{
  if(move_point_flag)
  {
    move_point_flag = false;
    move_point_num = -1;
    setCursor(Qt::ArrowCursor);
    setMouseTracking(false);

    emit pointChanged(0);
  }

  if(edited_tangent >= 0)
  {
    edited_tangent = -1;
    setCursor(Qt::ArrowCursor);
    setMouseTracking(false);

    emit pointChanged(0);

  }
}

void DrawWidget::wheelEvent(QWheelEvent * event)
{

}

void DrawWidget::leaveEvent(QEvent * event)
{

}

void DrawWidget::resizeEvent(QResizeEvent * event)
{

}



void DrawWidget::draw_control_point(int x, int y, QPainter& p, int point_num)
{
  p.drawEllipse(x - circ_size / 2, y - circ_size / 2, circ_size, circ_size);

  if(point_num >= 0)
  {
    QString str;
    str = QString("C%1")
              .arg(point_num);

    int pixelsWide = FM2draw.width(str);
    int pixelsHigh = FM2draw.height();

    p.drawText(x - pixelsWide / 2, y - pixelsHigh / 2, pixelsWide, pixelsHigh, Qt::AlignRight, str );
  }

}

void DrawWidget::draw_tangent(const TPoint& pt, const TPoint& tang, QPainter& p)
{
  TPoint end_pt = pt + tangent_size * tang;
  p.drawLine(pt.x, pt.y, end_pt.x, end_pt.y);
  p.drawEllipse(end_pt.x - small_circ_size / 2, end_pt.y - small_circ_size / 2, small_circ_size, small_circ_size);
}

void DrawWidget::draw_weigths(const TPoint& pt, double w, QPainter& p)
{
  p.drawText(pt.x + circ_size / 2, pt.y + circ_size / 2, QString::number(w));
}

void DrawWidget::paintEvent(QPaintEvent *)
{
  QPainter p(this);
  if(construct_points)
  {
    for(size_t q(0); q < construct_points->size(); q++)
    {
      const TPoint &pt = (*construct_points)[q];

      if(selected_point_num == q)
      {
        QPen pen(Qt::red);
        p.setPen(pen);
      }
      else
      {
        QPen pen(Qt::darkBlue);
        p.setPen(pen);
      }
      draw_control_point(pt.x, pt.y, p, q);
    }


    QPen dash_pen(Qt::DashLine);
    p.setPen(dash_pen);


    for(size_t q(1); q < construct_points->size(); q++)
    {
      const TPoint &pt = (*construct_points)[q];
      const TPoint &pt_ex = (*construct_points)[q - 1];

      p.drawLine(pt.x, pt.y, pt_ex.x, pt_ex.y);
    }

    if(m_bdraw_tangents)
    {
      QPen pen(Qt::green);
      p.setPen(pen);
      for(size_t q(0); q < construct_points->size(); q++)
      {
        const TPoint &pt = (*construct_points)[q];
        draw_tangent(pt, (*tangent_vectors)[q], p);
      }
    }

    if(m_bdraw_weights)
    {
      QPen pen(Qt::black);
      p.setPen(pen);
      for(size_t q(0); q < construct_points->size(); q++)
      {
        const TPoint &pt = (*construct_points)[q];
        draw_weigths(pt, (*point_weights)[q], p);
      }
    }

    if(add_points_flag && !construct_points->empty())
    {
      const TPoint &pt_ex = construct_points->back();
      p.drawLine(pt_ex.x, pt_ex.y, cursor_location.x, cursor_location.y);
    }

  }

  if(curve_points && (curve_points->size() > 1) )
  {
    QPen pen(Qt::red);
    p.setPen(pen);

    for(size_t q(1); q < curve_points->size(); q++)
    {
      const TPoint &pt = (*curve_points)[q];
      const TPoint &pt_ex = (*curve_points)[q - 1];

      p.drawLine(pt.x, pt.y, pt_ex.x, pt_ex.y);
    }
  }
}

void DrawWidget::mouseDoubleClickEvent(QMouseEvent* event)
{
  TPoint cur_pos(event->pos().x(), event->pos().y());
  selected_point_num = -1;
  for(size_t q(0); q < construct_points->size(); q++)
  {
    const TPoint& pt((*construct_points)[q]);
    if((pt - cur_pos).length() < circ_size)
    {
      selected_point_num = q;
      emit selectedPointChanged(q);
      break;
    }
  }
  repaint();
}
