#ifndef MATH_LIB2D_H
#define MATH_LIB2D_H
#include <iostream>
#include <math.h>

struct TPoint
{
  double x;
  double y;
  TPoint() { }
  TPoint(double ix, double iy) : x(ix), y(iy) { }

  TPoint operator+(const TPoint& src) const { return TPoint(x + src.x, y + src.y); }
  TPoint operator-(const TPoint& src) const { return TPoint(x - src.x, y - src.y); }
  double operator*(const TPoint& src) const { return (x  * src.x +  y * src.y); }
  TPoint operator*(double d) const { return TPoint(d * x, d * y); }
  double length() const { return sqrt(x * x + y * y); }
  double manhattan_length() const { return fabs(x) + fabs(y); }
  bool operator<(const TPoint& tp) const
  {
    return (x < tp.x) || (x == tp.x && y < tp.y);
  }

  void to_stream(std :: ostream& os) const
  {
    os << "("<< x <<", " << y << ")";
  }

  double tcos(const TPoint& v) const
  {
    return ((x * v.x) + (y * v.y)) / (length() * v.length());
  }

  double tsin(const TPoint& v) const
  {
    return fabs((x * v.y) - (y * v.x)) / (length() * v.length());
  }

  void Normalize()
  {
    double l = length();
    if(l > 0)
    {
      double inv = 1.0 / l;
      x *= inv;
      y *= inv;
    }
  }
};

inline TPoint operator*(const double&d, const TPoint& pt)
{
 return TPoint(d * pt.x, d * pt.y);
}

inline std :: ostream& operator<<(std ::ostream& os, const TPoint& p)
{
  p.to_stream(os);
  return os;
}


// Should be top > bottom, right > left;
struct bbox
{
  double left;
  double bottom;
  double right;
  double top;

  double area() const { return fabs(left - right) * fabs(top - bottom); }
  bbox() : left(0), bottom(0), right(-1), top(-1) { }
  bbox(const TPoint& pt) : left(pt.x), bottom(pt.y), right(pt.x), top(pt.y) { }

  void enlarge(const TPoint& pt)
  {
    if(pt.x < left)
      left = pt.x;
    else if(pt.x > right)
      right = pt.x;

    if(pt.y < bottom)
      bottom = pt.y;
    else if(pt.y > top)
      top = pt.y;
  }

  bbox(const TPoint& pt1, const TPoint& pt2)
  {
    left = right = pt1.x;
    top = bottom = pt1.y;
    enlarge(pt2);
  }

  bool is_valid() const { return (left <= right) && (top >= bottom); }

  void to_stream(std :: ostream& os) const
  {
    os << "bbox(" << left << ", " << bottom << ", " << right << ", " << top << ")";
  }

  double height() const { return top - bottom; }
  double width() const { return right - left; }
};

inline std :: ostream& operator<<(std :: ostream& os, const bbox& b)
{
  b.to_stream(os);
  return os;
}

#endif // MATH_LIB2D_H
