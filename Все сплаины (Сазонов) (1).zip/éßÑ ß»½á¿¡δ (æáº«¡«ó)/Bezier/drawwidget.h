#ifndef DRAWWIDGET_H
#define DRAWWIDGET_H

#include <QWidget>
#include "math_lib2d.h"
#include <QFont>
#include <QFontMetrics>

#define macro_max_weight 100
#define macro_default_weight 50

class DrawWidget : public QWidget
{

    std :: vector<TPoint>* construct_points;
    std :: vector<TPoint>* curve_points;
    std :: vector<TPoint> * tangent_vectors;
    std :: vector<double> * point_weights;

    bool add_points_flag;
    TPoint cursor_location;

    bool move_point_flag;
    int move_point_num;

    int selected_point_num;

    QFont F2draw;
    QFontMetrics FM2draw;

    bool m_bdraw_weights;
    bool m_bdraw_tangents;

    int edited_tangent;

    Q_OBJECT
public:

    void SetDrawWeights(bool w) { m_bdraw_weights = w; }
    void SetDrawTangents(bool t) { m_bdraw_tangents = t; }

    explicit DrawWidget(QWidget *parent = 0);

    virtual void mouseDoubleClickEvent(QMouseEvent* event);
    virtual void mousePressEvent(QMouseEvent * event);
    virtual void mouseMoveEvent(QMouseEvent * event);
    virtual void mouseReleaseEvent(QMouseEvent * event);
    virtual void wheelEvent(QWheelEvent * event);
    virtual void leaveEvent(QEvent * event);
    virtual void resizeEvent(QResizeEvent * event);
    virtual void paintEvent(QPaintEvent *);

    void SetAddPointFlag(bool f)
    {
      add_points_flag = f;
      if(f)
      {
        setCursor(Qt::CrossCursor);
        setMouseTracking(true);
      }
      else
      {
        setCursor(Qt::ArrowCursor);
          setMouseTracking(false);
      }
    }

    void SetPointContainers(std :: vector<TPoint>* ctp,
                            std :: vector<TPoint>* crvp,
                            std :: vector<TPoint> * tv,
                            std :: vector<double> * pw)
    {
      construct_points = ctp;
      curve_points = crvp;
      tangent_vectors = tv;
      point_weights = pw;
    }

signals:
    void pointChanged(int newValue);
    void selectedPointChanged(int newValue);

public slots:

private:
    void draw_control_point(int x, int y, QPainter& p, int point_num);
    void draw_tangent(const TPoint& pt, const TPoint& tang, QPainter& p);
    void draw_weigths(const TPoint& pt, double w, QPainter& p);

};

#endif // DRAWWIDGET_H
