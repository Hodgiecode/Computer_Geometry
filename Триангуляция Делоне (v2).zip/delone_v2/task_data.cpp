#include <iostream>
#include <vector>
#include "task_data.h"
#include <algorithm>

double calc_radius(point p1, point p2, point p3){
    double a = sqrt((p2.x - p1.x)*(p2.x - p1.x) + (p2.y - p1.y)*(p2.y - p1.y));
    double b = sqrt((p3.x - p2.x)*(p3.x - p2.x) + (p3.y - p2.y)*(p3.y - p2.y));
    double c = sqrt((p3.x - p1.x)*(p3.x - p1.x) + (p3.y - p1.y)*(p3.y - p1.y));
    double p = (a+b+c)/2;
    double R = (a*b*c)/(4*sqrt(p*(p-a)*(p-b)*(p-c)));
    return R;
}

point calc_center(point p1, point p2, point p3){
    double a2 = ((p2.x - p3.x)*(p2.x - p3.x) + (p2.y - p3.y)*(p2.y - p3.y));
    double b2 = ((p1.x - p3.x)*(p1.x - p3.x) + (p1.y - p3.y)*(p1.y - p3.y));
    double c2 = ((p1.x - p2.x)*(p1.x - p2.x) + (p1.y - p2.y)*(p1.y - p2.y));

    double a = sqrt(a2);
    double b = sqrt(b2);
    double c = sqrt(c2);

    double alpha = acos((b2 + c2 - a2)/(2*b*c));
    double beta = acos((a2 + c2 - b2)/(2*a*c));
    double gamma = acos((a2 + b2 - c2)/(2*a*b));

    double x =(p1.x*sin(2*alpha)+p2.x*sin(2*beta)+p3.x*sin(2*gamma))/(sin(2*alpha)+sin(2*beta)+sin(2*gamma));
    double y =(p1.y*sin(2*alpha)+p2.y*sin(2*beta)+p3.y*sin(2*gamma))/(sin(2*alpha)+sin(2*beta)+sin(2*gamma));

    point p;
    p.x = x;
    p.y = y;

    return p;
}

void delaunay(std::vector<point> &vp, std::vector<triangle> &res){
    int n = vp.size();

    for (int i=0;i<vp.size();i++){
        vp[i].z = vp[i].x*vp[i].x + vp[i].y*vp[i].y;
    }

    int flag = 0;
    for (int i=0;i<n-2;i++){
        for (int j=i+1;j<n;j++){
            for (int k=i+1;k<n;k++){
                if (j!=k){
                    //вычисляем нормаль к треугольнику (i,j,k)
                    double xn = (vp[j].y - vp[i].y) * (vp[k].z - vp[i].z) - (vp[k].y - vp[i].y)*(vp[j].z-vp[i].z);
                    double yn = (vp[k].x - vp[i].x) * (vp[j].z - vp[i].z) - (vp[j].x - vp[i].x)*(vp[k].z-vp[i].z);
                    double zn = (vp[j].x - vp[i].x) * (vp[k].y - vp[i].y) - (vp[k].x - vp[i].x)*(vp[j].y-vp[i].y);

                    //проверяем только грани где zn<0

                    if (flag = (zn<0)){
                        for (int m=0;m<n;m++){
                            flag = flag && ((vp[m].x-vp[i].x)*xn + (vp[m].y-vp[i].y)*yn + (vp[m].z-vp[i].z)*zn <=0);
                        }
                    }

                    if (flag){
                        triangle tr;
                        tr.p1 = vp[i];
                        tr.p2 = vp[j];
                        tr.p3 = vp[k];

                        tr.radius = calc_radius(vp[i],vp[j],vp[k]);
                        tr.center = calc_center(vp[i],vp[j],vp[k]);
                        res.push_back(tr);
                    }
                }
            }
        }
    }
}

bool task_data::run(){
    delaunay(vector_of_points, triangle_vector);
    return true ;
}

