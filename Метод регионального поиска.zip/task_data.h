#ifndef TASK_DATA_H
#define TASK_DATA_H
#include <math.h>
#include <vector>
#include <string>

struct point {
    double x;
    double y;
    double z;
    int id;

    point() {} //конструктор без параметров
    point(double x_, double y_, int id_): x(x_), y(y_), id(id_) {} //конструктор с параметрами

    double length() { return sqrt(x * x + y * y); }

    point operator+(const point& op) const
    {
        return point(x + op.x, y + op.y, -1);
    }

    point operator-(const point& op) const
    {
        return  point(x - op.x, y - op.y, -1);
    }
};

inline point operator*(const double& t, const point& v){
  return point(t * v.x, t * v.y, -1);
}

typedef struct Node_{
  point data;
  struct Node_ *left;
  struct Node_ *right;
  bool color;
  int size;
} node;


struct task_data {
    std::vector<point> vector_of_points;
    point A; //левый нижний угол
    point B; //верхний правый угол
    std::vector<point> result;
    std::string work_time;

    task_data(){

    }

    bool run();
    bool run_bruteforce();
};

#endif // TASK_DATA_H
