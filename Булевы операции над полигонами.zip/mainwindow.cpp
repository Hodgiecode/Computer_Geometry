#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "drawwidget.h"
#include "QMessageBox"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->draw_widget->SetTaskPtr(&current_task);
    ui->draw_widget->SetDefaultPoints();
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_2_clicked()
{
    // инициализация задачи
    ui->draw_widget->Difference2();
}

void MainWindow::on_pushButton_clicked()
{
    // инициализация задачи
    ui->draw_widget->Intersection();
}

void MainWindow::on_pushButton_3_clicked()
{
    // инициализация задачи
    ui->draw_widget->Union();
}


void MainWindow::on_pushButton_4_clicked()
{
    // инициализация задачи
    ui->draw_widget->Clipper_Intersection();
}

void MainWindow::on_pushButton_5_clicked()
{
    // инициализация задачи
    ui->draw_widget->Clipper_Union();
}

void MainWindow::on_pushButton_7_clicked()
{
    // инициализация задачи
    ui->draw_widget->Clipper_Difference2();
}

void MainWindow::on_pushButton_8_clicked()
{
    // инициализация задачи
    ui->draw_widget->Clean();
}

void MainWindow::on_pushButton_6_clicked(){
    std::string p = ui->lineEdit->text().toStdString();

    if (p == ""){
        ui->draw_widget->points_2 = 10;
        p = "10";
        QString v1 = QString::fromUtf8(p.c_str());
        ui->lineEdit->setText(v1);
    }

    ui->draw_widget->points_2 = atoi(ui->lineEdit->text().toStdString().c_str());
    ui->draw_widget->create_points_2();
}


void MainWindow::on_pushButton_9_clicked(){
    std::string p = ui->lineEdit_2->text().toStdString();

    if (p == ""){
        ui->draw_widget->points_1 = 10;
        p = "10";
        QString v1 = QString::fromUtf8(p.c_str());
        ui->lineEdit_2->setText(v1);
    }

    ui->draw_widget->points_1 = atoi(ui->lineEdit_2->text().toStdString().c_str());
    ui->draw_widget->create_points_1();
}
