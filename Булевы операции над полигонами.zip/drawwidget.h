#ifndef DRAWWIDGET_H
#define DRAWWIDGET_H
#include <QWidget>
#include "task_data.h"

class DrawWidget : public QWidget
{
    Q_OBJECT;

public :
    task_data * pTask;

public:
    explicit DrawWidget(QWidget *parent = nullptr);
    void SetDefaultPoints();

    void paintEvent(QPaintEvent *event);
    void SetTaskPtr(task_data * p) { pTask = p; }

    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);

    void Difference1();
    void Difference2();
    void Intersection();
    void Union();

    void Clipper_Intersection();
    void Clipper_Difference1();
    void Clipper_Difference2();
    void Clipper_Union();

    void Clean();


    int diff_flag1;
    int diff_flag2;
    int intersection_flag;
    int union_flag;

    int clipper_diff_flag1;
    int clipper_diff_flag2;
    int clipper_intersection_flag;
    int clipper_union_flag;

    int points_1, points_2;

    void create_points_1();
    void create_points_2();


protected:
    bool m_bMovePointFlag;
    int last_moved_point_id;
    int last_moved_polygon;
signals:

};

#endif // DRAWWIDGET_H
