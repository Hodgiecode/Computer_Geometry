#include "task_data.h"

/*-----------------------*/

int intersection_point(segment &seg1, segment &seg2, point &p){
   double val = 0;

   double x1 = seg1.p.x;
   double y1 = seg1.p.y;

   double x2 = seg1.q.x;
   double y2 = seg1.q.y;

   double x3 = seg2.p.x;
   double y3 = seg2.p.y;

   double x4 = seg2.q.x;
   double y4 = seg2.q.y;
   double n = 0;

   if (y2 - y1 > 1e-9 || y2 - y1 < 1e-9){
       double q = (x2 - x1)/(y1 - y2);
       double sn = (x3 - x4) + (y3 - y4)*q;
       if (!sn){
           return 0;
       }

       double fn = (x3 - x1) + (y3 - y1) * q;
       n = fn/sn;
   }

   else {
       if (!(y3 - y4)){
           return 0;
       }

       n = (y3 - y1)/(y3 - y4);
   }

   p.x = x3 + (x4 - x3) * n;
   p.y = y3 + (y4 - y3) * n;
   return 1;
}

int dcmp(double a, double b) {
  return fabs(a - b) <= 1e-9 ? 0 : a < b ? -1 : 1;
}

bool same(point p1, point p2){
    return (p2.x-p1.x)<1e-9 && (p2.y-p1.y)<1e-9;
}

bool intersect1d(double l1, double r1, double l2, double r2) {
    if (l1 > r1){
        std::swap(l1, r1);
    }

    if (l2 > r2){
        std::swap(l2, r2);
    }

    return std::max(l1, l2) <= std::min(r1, r2) + 1e-9;
}


int vec(const point& a, const point& b, const point& c) {
    double s = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
    return abs(s) < 1e-9 ? 0 : s > 0 ? +1 : -1;
}

bool intersect(point p1, point p2, point p3, point p4){
    return intersect1d(p1.x, p2.x, p3.x, p4.x) &&
           intersect1d(p1.y, p2.y, p3.y, p4.y) &&
           vec(p1, p2, p1) * vec(p1, p2, p4) <= 0 &&
           vec(p3, p4, p1) * vec(p3, p4, p2) <= 0;
}

bool task_data::intersectSeg(std::set<segment>::iterator seg1Iter, std::set<segment>::iterator seg2Iter){
   if (seg1Iter == sweepSet.end() || seg2Iter == sweepSet.end()){
      return false;
   }

   return intersect(seg1Iter->p, seg1Iter->q, seg2Iter->p, seg2Iter->q);
}

std::set<segment>::iterator task_data::after(std::set<segment>::iterator cur) {
   return cur == sweepSet.end() ? sweepSet.end() : ++cur;
}

std::set<segment>::iterator task_data::before(std::set<segment>::iterator cur) {
   return cur == sweepSet.begin() ? sweepSet.end() : --cur;
}

void task_data::FoundIntersection(int i, int j) {
    point p;
    std::cout << i+1 << " " << j+1;
    int v = intersection_point(init_segments[i], init_segments[j], p);

    if (v==1){
        res.push_back(p);
    }
}

void task_data::bentley_ottman(std::vector<segment> &segments){
    int n = segments.size();
    init_segments = segments;

    for (int i=0;i<n;i++){
      events[2*i] = {segments[i].p, ENTRY, i};
      events[2*i+1] = {segments[i].q, EXIT, i};
    }

    std::sort(events, events+2*n);

    for (int i=0; i<2*n; i++) {
      if (events[i].type == ENTRY) {
          auto status = sweepSet.insert(segments[events[i].seg_idx]);
          std::set<segment>::iterator cur = status.first, below = before(cur), above = after(cur);

          if(!status.second) {
            FoundIntersection(cur->seg_idx, events[i].seg_idx);
          } else {
            if(intersectSeg(cur, above)){
                FoundIntersection(cur->seg_idx, above->seg_idx);
            }

            if(intersectSeg(cur, below)){
                FoundIntersection(cur->seg_idx, below->seg_idx);
            }
         }
      } else {
          std::set<segment>::iterator cur = sweepSet.find(segments[events[i].seg_idx]);

          if(cur == sweepSet.end()){
            continue;
          }

          std::set<segment>::iterator below = before(cur), above = after(cur);

          if(intersectSeg(above, below)){
                FoundIntersection(above->seg_idx, below->seg_idx);
          }
          sweepSet.erase(cur);
        }
     }
 }

/*------------------------*/

bool task_data :: run(){
    std::vector<segment> segment_vector;
    std::vector<point> res;

    int k=0;
    for (int i=0;i<vector_of_points.size()-1;i=i+2){
        segment_vector.push_back(segment(vector_of_points[i],vector_of_points[i+1],k));
        k=k+1;
    }

    bentley_ottman(segment_vector);

    return true ;
}
