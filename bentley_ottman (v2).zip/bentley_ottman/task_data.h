#ifndef TASK_DATA_H
#define TASK_DATA_H

#include <math.h>
#include <vector>
#include <algorithm>
#include <iostream>
#include <set>
#include <queue>
#include <map>
#include <cmath>
#include <complex>


struct point {
    double x;
    double y;
    int id;

    point() {} //конструктор без параметров
    point(double x_, double y_, int id_): x(x_), y(y_), id(id_) {} //конструктор с параметрами

    double length() { return sqrt(x * x + y * y); }

    point operator+(const point& op) const{
        return point(x + op.x, y + op.y, -1);
    }

    point operator-(const point& op) const {
        return  point(x - op.x, y - op.y, -1);
    }

};

int dcmp(double a, double b);
bool same(point p1, point p2);


inline bool operator <(point &a, point &b) {
    if (dcmp(a.x, b.x) != 0){
        return dcmp(a.x, b.x) < 0;
    }

    return dcmp(a.y, b.y) < 0;
}

inline point operator*(const double& t, const point& v){
  return point(t * v.x, t * v.y, -1);
}


struct segment {
    point p, q;
    int seg_idx;

    segment() {seg_idx = -1;}
    segment(point p_, point q_, int seg_idx_) {
       if (q_ < p_){
            std::swap(p_, q_);
        }

      p = p_, q = q_, seg_idx = seg_idx_;
    }

    double CY(int x) const {
      if (dcmp(p.x, q.x) == 0){
         return p.y;
      }

      double t = 1.0 * (x - p.x)/(q.x - p.x);
      return p.y + (q.y - p.y)*t;
    }

    bool operator<(const segment& rhs) const {
      if(same(p, rhs.p) && same(q, rhs.q)){
         return false;
      }

      int maxX = std::max(p.x, rhs.p.x);
      int yc = dcmp(CY(maxX), rhs.CY(maxX));

      if (yc == 0){
            return seg_idx < rhs.seg_idx;
      }

      return yc < 0;
    }
};


struct event {
    point p;
    int type, seg_idx;

    bool operator <(const event & rhs) const {
      if (dcmp(p.x, rhs.p.x) != 0){
        return dcmp(p.x, rhs.p.x) < 0;
      }

      if (type != rhs.type){
        return type > rhs.type;
      }

      return dcmp(p.y, rhs.p.y) < 0;
    }
 };

struct task_data {
    int ENTRY = +1, EXIT = -1;
    std::vector<point> vector_of_points;

    std::vector<point> res;

    std::vector<segment> segments;
    std::vector<segment> init_segments;

    event events[10000];
    std::set<segment> sweepSet;

    std::set<segment>::iterator after(std::set<segment>::iterator cur);
    std::set<segment>::iterator before(std::set<segment>::iterator cur);
    bool intersectSeg(std::set<segment>::iterator seg1Iter, std::set<segment>::iterator seg2Iter);

    task_data(){

    }

    bool run();
    void bentley_ottman(std::vector<segment> &vp);
    void FoundIntersection(int i, int j);

};

#endif // TASK_DATA_H
