#ifndef RAY_TRACER_H
#define RAY_TRACER_H
#define _USE_MATH_DEFINES

#include <math.h>
#include <vector>
#include <algorithm>
#include <iostream>
#include <fstream>

struct TVec3f
{
  double x;
  double y;
  double z;

  TVec3f() { }
  TVec3f(double iX, double iY, double iZ) : x(iX), y(iY), z(iZ) { }

  TVec3f operator+(const TVec3f& v) const
  {
    return TVec3f(x + v.x, y + v.y, z + v.z);
  }

  TVec3f operator-(const TVec3f& v) const
  {
    return TVec3f(x - v.x, y - v.y, z - v.z);
  }

  double operator*(const TVec3f& v) const
  {
    return x * v.x + y * v.y + z * v.z;
  }

  TVec3f operator*(const double& f) const
  {
    return TVec3f(x * f, y * f, z * f);
  }

  double length() const
  {
    return sqrt(x * x + y * y + z * z);
  }

  void Normalize()
  {
    double l = length();
    if(l > 0)
    {
      x /= l;
      y /= l;
      z /= l;
    }
  }
};

void read(const char *filename, std::vector<TVec3f> &verts, std::vector<std::vector<int>> &faces);

inline TVec3f operator*(const double& f, const TVec3f& v)
{
  return v * f;
}


/*---------------------------------------*/
struct Material {
    TVec3f colour;
    double ambient;
    double specular;
    double shininess;
    double reflectiveness;

    Material(const TVec3f col){
        colour = col;
    }

    Material(const TVec3f col, double a, double s, double alpha, double r){
        colour = col;
        ambient = a;
        specular = s;
        shininess = alpha;
        reflectiveness = r;
    }

    Material(){
        colour = TVec3f(0.9, 0.9, 0.6);
    }
};

struct Light {
    TVec3f position;
    TVec3f colour;
    double intensity;

    Light (const TVec3f &pos, double isty){
        position = pos;
        intensity = isty;
    }

    Light(const TVec3f &pos, const TVec3f &col, double isty){
        position = pos;
        colour = col;
        intensity = isty;
    }
};

/*------------------------------*/


class TObject
{
protected:
   Material material;
public:
   TObject(const Material & mat) :  material(mat) { }

   const Material& get_material() const { return material; }

   virtual bool IsIntersect(const TVec3f& ray_src,
                            const TVec3f& ray_dir,
                            double& tau) = 0;

   virtual bool IsIntersect(const TVec3f& ray_src,
                            const TVec3f& ray_dir,
                            double& tau,
                            TVec3f& pt,
                            TVec3f& nl) = 0;

   ~TObject(){}
};


class TTriangle : public TObject
{

public:
    TVec3f A;
    TVec3f B;
    TVec3f C;

    double u,v;

    TTriangle(const TVec3f& iA, const TVec3f& iB, const TVec3f& iC, const Material& M) :
        TObject (M), A(iA), B(iB), C(iC)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);

    ~TTriangle(){}
};

class TSphere : public TObject
{

public:
    TVec3f center;
    double R;

    TSphere(const TVec3f& iC, const double R_, Material &M) :
        TObject (M), center(iC), R(R_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);
};

class TCone : public TObject
{

public:
    TVec3f center;
    double H;
    double R;

    TCone(const TVec3f& iC, const double H_, const double R_, const Material& mat) :
        TObject (mat), center(iC), H(H_), R(R_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);
};

class TCylinder : public TObject
{

public:
    TVec3f center_bottom;
    TVec3f center_top;
    double R;
    TVec3f center;
    TVec3f normal_;

    TCylinder(const TVec3f& iB, const TVec3f& iT, const double R_, const Material& mat) :
        TObject (mat), center_bottom(iB), center_top(iT), R(R_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);
};


class TTorus : public TObject
{

public:
    TVec3f center;
    TVec3f axis;
    TVec3f normal;
    double r, R;

    TTorus(const TVec3f& iC,  const double R1, const double R2, const TVec3f& axis_, const Material& mat) :
            TObject (mat), center(iC), r(R1), R(R2), axis(axis_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);
};

class TPlane : public TObject
{

public:
    TVec3f A;
    TVec3f B;
    TVec3f C;
    TVec3f D;
    TVec3f normal;

    TPlane(const TVec3f& A_,const TVec3f& B_,
           const TVec3f& C_,const TVec3f& D_, const Material& mat ) :
           TObject (mat), A(A_), B(B_), C(C_), D(D_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);

    bool inside(TVec3f &pt);
};



class SimpleScene{
protected:

  double Vw;
  double Vh;
  double Dist;

  int CCx, CCy;

  int Cw;
  int Ch;

  int mode;
public:
  std :: vector<TObject*> objects;
  std::vector<Light> light_vector;

  SimpleScene(int W, int H, int M) : Cw(W), Ch(H), mode(M)
  {
      Vh = 1;
      Vw = double (Cw * Vh) / Ch; 1.0;

      Dist = 1;

      CCx = W / 2;
      CCy = H / 2;

      Material red(TVec3f(0.3, 0.1, 0.1), 0.8, 0.1, 10,0);
      Material mat(TVec3f(0.4, 0.4, 0.3), 0.1, 0.3, 40,0);
      Material glass(TVec3f(0.1, 0.1, 0.1), 0,  1, 50, 0.9);
      Material def_mat(TVec3f(.3, 0.0, 0), 0.8, 0, 0.1, 0.0);

      if (M == 0){
          objects.push_back(new TSphere(TVec3f(0, 0, -16), 5, red));
      }

      if (M == 1){
          std::vector<TVec3f> verts;
          std::vector<std::vector<int>> faces;
          read("C://Users//Butuzov//Desktop//new_start//duck.txt", verts, faces);

          for (size_t i=0;i<faces.size();i++){
              int id_1 = faces[i][0] - 1;
              int id_2 = faces[i][1] - 1;
              int id_3 = faces[i][2] - 1;

              objects.push_back(new TTriangle(verts[id_1], verts[id_2], verts[id_3], red));
          }

      }

      if (M == 2){
          objects.push_back(new TCone(TVec3f(0, -5.0, -16), 10, 5, red));
      }

      if (M == 3){
          objects.push_back(new TCylinder(TVec3f(0, 5, -16), TVec3f(0, -5, -16), 25, red));
      }

      if (M == 4){
          objects.push_back(new TTorus(TVec3f(0, 0, -16), 2, 5, TVec3f(-1, 0, -16), red));
      }

      if (M == 5){    
          objects.push_back(new TSphere(TVec3f(5, 1, -16), 3, glass));
          objects.push_back(new TSphere(TVec3f(-2, -1, -16), 3, mat));

          Material d1, d2, d3, d4, d5;
          d1 = def_mat;
          d2 = def_mat;
          d3 = def_mat;
          d4 = def_mat;
          d5 = def_mat;
          d1.colour = TVec3f(0,255,0);
          d2.colour = TVec3f(0,0,255);
          d3.colour = TVec3f(0,255,255);
          d4.colour = TVec3f(128,0,0);
          d5.colour = TVec3f(128,0,128);

          //центр
          //objects.push_back(new TPlane(TVec3f(-3,1.0,5),TVec3f(-3,-1.0,5),TVec3f(3,-1.0,5), TVec3f(3,1.0,5), d1));

          //боковые стенки
          //objects.push_back(new TPlane(TVec3f(-5,-4.0,5),TVec3f(-5,2,5),TVec3f(-3,1.0,5), TVec3f(-3,-1.0,5), d2));
          //objects.push_back(new TPlane(TVec3f(3,-1.0,5), TVec3f(3,1.0,5), TVec3f(5, 2.0,5), TVec3f(5,-3.0,5), d3));

          //пол и потолок
          //objects.push_back(new TPlane(TVec3f(-3,-1.0,5),TVec3f(-5, -3.0,5),TVec3f(5,-3.0,5), TVec3f(3,-1.0,5), d4));
          //objects.push_back(new TPlane(TVec3f(-2,-1.0,5), TVec3f(-5,2.0,5),TVec3f(5,2.0,5), TVec3f(5, 1.0,5), d5));


      }

   }

  ~SimpleScene(){

      for (int i=0;i<objects.size();i++){
          delete objects[i];
      }

      objects.clear();


  }

  TVec3f get_pixel(int x, int y, int w, int h);


};


#endif // RAY_TRACER_H
