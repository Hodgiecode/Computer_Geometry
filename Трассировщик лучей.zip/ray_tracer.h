#ifndef RAY_TRACER_H
#define RAY_TRACER_H
#define _USE_MATH_DEFINES

#include <QtCore>
#include <math.h>
#include <vector>
#include <algorithm>
#include <iostream>
#include <fstream>

struct TVec3f
{
  double x;
  double y;
  double z;

  TVec3f() { }
  TVec3f(double iX, double iY, double iZ) : x(iX), y(iY), z(iZ) { }

  TVec3f operator+(const TVec3f& v) const
  {
    return TVec3f(x + v.x, y + v.y, z + v.z);
  }

  TVec3f operator-(const TVec3f& v) const
  {
    return TVec3f(x - v.x, y - v.y, z - v.z);
  }

  double operator*(const TVec3f& v) const
  {
    return x * v.x + y * v.y + z * v.z;
  }

  TVec3f operator*(const double& f) const
  {
    return TVec3f(x * f, y * f, z * f);
  }

  double length() const
  {
    return sqrt(x * x + y * y + z * z);
  }

  void Normalize()
  {
    double l = length();
    if(l > 0)
    {
      x /= l;
      y /= l;
      z /= l;
    }
  }
};

void read(const char *filename, std::vector<TVec3f> &verts,
          std::vector<std::vector<int>> &faces);

inline TVec3f operator*(const double& f, const TVec3f& v)
{
  return v * f;
}


/*---------------------------------------*/

struct Material {
    double refractive_index = 1;
    double albedo_p1 = 1;
    double albedo_p2 = 0;
    double albedo_p3 = 0;
    double albedo_p4 = 0;
    double specular = 0;
    TVec3f color = TVec3f(0,0,0);
};

struct Light {
    TVec3f position;
    double intensity;
};

/*------------------------------*/


class TObject
{
protected:
   Material material;
public:
   TObject(const Material & mat) :  material(mat) { }

   const Material& get_material() const { return material; }

   virtual bool IsIntersect(const TVec3f& ray_src,
                            const TVec3f& ray_dir,
                            double& tau) = 0;

   virtual bool IsIntersect(const TVec3f& ray_src,
                            const TVec3f& ray_dir,
                            double& tau,
                            TVec3f& pt,
                            TVec3f& nl) = 0;

   ~TObject(){}
};


class TTriangle : public TObject
{

public:
    TVec3f A;
    TVec3f B;
    TVec3f C;

    double u,v;

    TTriangle(const TVec3f& iA, const TVec3f& iB, const TVec3f& iC, const Material& M) :
        TObject (M), A(iA), B(iB), C(iC)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);

    ~TTriangle(){}
};

class TSphere : public TObject
{

public:
    TVec3f center;
    double R;

    TSphere(const TVec3f& iC, const double R_, Material &M) :
        TObject (M), center(iC), R(R_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);
};

class TCone : public TObject
{

public:
    TVec3f center;
    double H;
    double R;

    TCone(const TVec3f& iC, const double H_, const double R_, const Material& mat) :
        TObject (mat), center(iC), H(H_), R(R_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);
};

class TCylinder : public TObject
{

public:
    TVec3f center_bottom;
    TVec3f center_top;
    double R;
    TVec3f center;
    TVec3f normal_;

    TCylinder(const TVec3f& iB, const TVec3f& iT, const double R_, const Material& mat) :
        TObject (mat), center_bottom(iB), center_top(iT), R(R_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);
};


class TTorus : public TObject
{

public:
    TVec3f center;
    TVec3f axis;
    TVec3f normal;
    double r, R;

    TTorus(const TVec3f& iC,  const double R1, const double R2, const TVec3f& axis_, const Material& mat) :
            TObject (mat), center(iC), r(R1), R(R2), axis(axis_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);
};


class TCube : public TObject
{

public:
    TVec3f normal;
    double side;
    TVec3f center;

     TCube(const TVec3f& center_, double side_,
               const Material& mat ) :
               TObject (mat), center(center_), side(side_)
      {

      }

      virtual bool IsIntersect(const TVec3f& ray_src,
                                 const TVec3f& ray_dir,
                                 double& tau);


      virtual bool IsIntersect(const TVec3f& ray_src,
                                 const TVec3f& ray_dir,
                                 double& tau,
                                 TVec3f& pt,
                                 TVec3f& nl);
};

/*------- ЛЕНТА МЕБИУСА --------*/
class TMobius : public TObject
{
public:
    double radius;
    double half_width;
    double xy;
    double z;

    TMobius(double& radius_, double &half_width_,
           const Material& mat ) :
           TObject (mat), radius(radius_), half_width(half_width_){

            xy = radius + half_width;
            z = half_width;
    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);
};

class SimpleScene{
protected:

  double Vw;
  double Vh;
  double Dist;

  int CCx, CCy;

  int Cw;
  int Ch;

public:
  std :: vector<TObject*> objects;
  std::vector<Light> light_vector;

  void fill_cube(TVec3f &shift, double scale, Material &mat){
      std::vector<TVec3f> vertices_vector;

  }

  void fill_dodecahedron(TVec3f &shift, double scale, Material &mat){
      std::vector<TVec3f> vertices_vector;

      double a = 0.57735;
      double b = 0.934172;
      double c = 0.356822;

      vertices_vector.push_back(scale * TVec3f(-a, -a, a)+ shift);
      vertices_vector.push_back(scale * TVec3f(b, c, 0)+ shift);
      vertices_vector.push_back(scale * TVec3f(b, -c, 0)+ shift);
      vertices_vector.push_back(scale * TVec3f(-b, c, 0)+ shift);
      vertices_vector.push_back(scale * TVec3f(-b, -c, 0)+ shift);

      vertices_vector.push_back(scale * TVec3f(0, b, c)+ shift);
      vertices_vector.push_back(scale * TVec3f(0, b, -c)+ shift);
      vertices_vector.push_back(scale * TVec3f(c, 0, -b)+ shift);
      vertices_vector.push_back(scale * TVec3f(-c, 0, -b)+ shift);
      vertices_vector.push_back(scale * TVec3f(0, -b, -c)+ shift);

      vertices_vector.push_back(scale * TVec3f(0, -b, c)+ shift);
      vertices_vector.push_back(scale * TVec3f(c, 0, b)+ shift);
      vertices_vector.push_back(scale * TVec3f(-c, 0, b)+ shift);
      vertices_vector.push_back(scale * TVec3f(a, a, -a)+ shift);
      vertices_vector.push_back(scale * TVec3f(a, a, a)+ shift);

      vertices_vector.push_back(scale * TVec3f(-a, a, -a)+ shift);
      vertices_vector.push_back(scale * TVec3f(-a, a, a)+ shift);
      vertices_vector.push_back(scale * TVec3f(a, -a, -a)+ shift);
      vertices_vector.push_back(scale * TVec3f(a, -a, a)+ shift);
      vertices_vector.push_back(scale * TVec3f(-a, -a, -a)+ shift);


      std::vector<int> faces_vector{19,3,2,12,19,2,15,12,2,8,14,2,18,8,2,3,18,2,20,5,4,
                                    9,20,4,16,9,4,13,17,4,1,13,4,5,1,4,7,16,4,6,7,4,17,6,4,
                                    6,15,2,7,6,2,14,7,2,10,18,2,11,10,3,19,11,3,11,1,5,10,11,5,
                                    20,10,5,20,9,8,10,20,8,18,10,8,9,16,7,8,9,7,14,8,7,12,15,6,
                                    13,12,6,17,13,6,13,1,11,12,13,11,19,12,11};

      for (size_t i=0;i<faces_vector.size();i=i+3){
          int id_1 = faces_vector[i] - 1;
          int id_2 = faces_vector[i+1] - 1;
          int id_3 = faces_vector[i+2] - 1;

          objects.push_back(new TTriangle(vertices_vector[id_1],
                                          vertices_vector[id_2],
                                          vertices_vector[id_3], mat));
      }
  }

  void fill_octahedron(TVec3f &shift, double scale, Material &mat){
      std::vector<TVec3f> vertices_vector;

      vertices_vector.push_back(scale * TVec3f(1, 0, 0)+ shift);
      vertices_vector.push_back(scale * TVec3f(-1, 0, 0)+ shift);
      vertices_vector.push_back(scale * TVec3f(0, 0, -1)+ shift);
      vertices_vector.push_back(scale * TVec3f(0, 0, 1)+ shift);
      vertices_vector.push_back(scale * TVec3f(0, 1, 0)+ shift);
      vertices_vector.push_back(scale * TVec3f(0, -1, 0)+ shift);

      std::vector<int> faces_vector{5,1,3,5,3,2,5,2,4,5,4,1,6,3,1,6,2,3,6,4,2,6,1,4};

      for (size_t i=0;i<faces_vector.size();i=i+3){
          int id_1 = faces_vector[i] - 1;
          int id_2 = faces_vector[i+1] - 1;
          int id_3 = faces_vector[i+2] - 1;

          objects.push_back(new TTriangle(vertices_vector[id_1],
                                          vertices_vector[id_2],
                                          vertices_vector[id_3], mat));
      }
  }

  void fill_tetrahedron(TVec3f &shift, double scale, Material &mat){
      std::vector<TVec3f> vertices_vector;

      double a = 0.433012703;
      double b = 0.409055926;
      double c = 0.1443337568;

      vertices_vector.push_back(scale * TVec3f(-a, -b, 0.5)+ shift);
      vertices_vector.push_back(scale * TVec3f(a, -b, 0)+ shift);
      vertices_vector.push_back(scale * TVec3f(-c, b, 0)+ shift);
      vertices_vector.push_back(scale * TVec3f(-a, -b, -0.5)+ shift);

      std::vector<int> faces_vector{4,2,1,1,3,4,2,3,1,4,3,2};

      for (size_t i=0;i<faces_vector.size();i=i+3){
          int id_1 = faces_vector[i] - 1;
          int id_2 = faces_vector[i+1] - 1;
          int id_3 = faces_vector[i+2] - 1;

          objects.push_back(new TTriangle(vertices_vector[id_1],
                                          vertices_vector[id_2],
                                          vertices_vector[id_3], mat));
      }
  }

  void fill_icosahedron(TVec3f &shift, double scale, Material &mat){
      std::vector<TVec3f> vertices_vector;

      vertices_vector.push_back(scale * TVec3f(-1, 1.618, 0)+ shift);
      vertices_vector.push_back(scale * TVec3f(1, 1.618, 0)+ shift);
      vertices_vector.push_back(scale * TVec3f(-1, -1.618, 0)+ shift);

      vertices_vector.push_back(scale * TVec3f(1, -1.618, 0)+ shift);
      vertices_vector.push_back(scale * TVec3f(0, -1, 1.618)+ shift);
      vertices_vector.push_back(scale * TVec3f(0, 1, 1.618)+ shift);

      vertices_vector.push_back(scale * TVec3f(0, -1, -1.618)+ shift);
      vertices_vector.push_back(scale * TVec3f(0, 1, -1.618)+ shift);
      vertices_vector.push_back(scale * TVec3f(1.618, 0, -1) + shift);

      vertices_vector.push_back(scale * TVec3f(1.618, 0, 1) + shift);
      vertices_vector.push_back(scale * TVec3f(-1.618, 0, -1) + shift);
      vertices_vector.push_back(scale * TVec3f(-1.618, 0, 1) + shift);

      std::vector<int> faces_vector{1,12,6,1,6,2,1,2,8,1,8,11,1,11,12,2,6,10,6,12,5,
        12,11,3,11,8,7,8,2,9,4,10,5,4,5,3,4,3,7,4,7,9,4,9,10,
        5,10,6,3,5,12,7,3,11,9,7,8,10,9,2};

      for (size_t i=0;i<faces_vector.size();i=i+3){
          int id_1 = faces_vector[i] - 1;
          int id_2 = faces_vector[i+1] - 1;
          int id_3 = faces_vector[i+2] - 1;

          objects.push_back(new TTriangle(vertices_vector[id_1],
                                          vertices_vector[id_2],
                                          vertices_vector[id_3], mat));
      }
  }


  SimpleScene(int W, int H, int M, std::string path) : Cw(W), Ch(H)
  {
      Vh = 1;
      Vw = double (Cw * Vh) / Ch; 1.0;

      Dist = 1;

      CCx = W / 2;
      CCy = H / 2;

      Material red, mat, glass, mirror;

      red.color = TVec3f(0.3, 0.1, 0.1);
      red.refractive_index = 1.0;
      red.albedo_p1 = 1.0;
      red.albedo_p2 = 0.0;
      red.albedo_p3 = 0.0;
      red.albedo_p4 = 0.0;
      red.specular =  0.0;

      mat.color = TVec3f(0.4, 0.4, 0.3);
      mat.refractive_index = 1.0;
      mat.albedo_p1 = 0.6;
      mat.albedo_p2 = 0.3;
      mat.albedo_p3 = 0.1;
      mat.albedo_p4 = 0.0;
      mat.specular = 50.0;

      mirror.color = TVec3f(1.0, 1.0, 1.0);
      mirror.refractive_index = 1.0;
      mirror.albedo_p1 = 0.0;
      mirror.albedo_p2 = 10.0;
      mirror.albedo_p3 = 0.8;
      mirror.albedo_p4 = 0.0;
      mirror.specular = 1425.0;

      glass.color = TVec3f(0.6, 0.7, 0.8);
      glass.refractive_index = 1.5;
      glass.albedo_p1 = 0.0;
      glass.albedo_p2 = 0.5;
      glass.albedo_p3 = 0.1;
      glass.albedo_p4 = 0.8;
      glass.specular = 125.0;

      /*--------------*/

      std::vector<TVec3f> verts;
      std::vector<std::vector<int>> faces;

       /*--------------*/

      if (M == 0){
          objects.push_back(new TSphere(TVec3f(0, 0, -16), 5, red));
      }

      if (M == 1){    

          read(path.c_str(), verts, faces);

          for (size_t i=0;i<faces.size();i++){
              int id_1 = faces[i][0] - 1;
              int id_2 = faces[i][1] - 1;
              int id_3 = faces[i][2] - 1;

              objects.push_back(new TTriangle(verts[id_1],
                                              verts[id_2],
                                              verts[id_3], mat));
          }

      }

      if (M == 2){
          objects.push_back(new TCone(TVec3f(0, -5.0, -16), 10, 5, red));
      }

      if (M == 3){
          objects.push_back(new TCylinder(TVec3f(0, 5, -16), TVec3f(0, -5, -16), 25, red));
      }

      if (M == 4){
          objects.push_back(new TTorus(TVec3f(0, 0, -16), 2, 5, TVec3f(-1, 0, -16), red));
      }

      if (M == 5){
          objects.push_back(new TCylinder(TVec3f(0, 5, -16), TVec3f(0, -5, -16), 25, mat));
          objects.push_back(new TSphere(TVec3f(6, 3, -16), 3, glass));
          objects.push_back(new TSphere(TVec3f(-2, -1, -16), 3, mirror));
          objects.push_back(new TCone(TVec3f(-6, -6.0, -16), 3, 3, red));
          objects.push_back(new TTorus(TVec3f(-6, 1, -16), 1.0, 2.5, TVec3f(-1, 0, -16), red));

          objects.push_back(new TCube(TVec3f(6, -3, -16), 2, red));
      }

      if (M == 6){
          objects.push_back(new TCube(TVec3f(-5, 0, -16), 3, mat));
          objects.push_back(new TCube(TVec3f(5, 0, -16), 3, red));
      }

      if (M == 8){
          TVec3f shift = TVec3f(0,4,-16);
          double scale = 2;

          fill_icosahedron(shift, scale, mat);

          shift = TVec3f(9,1,-16);
          scale = 8;
          fill_tetrahedron(shift, scale, mat);

          shift = TVec3f(-8,0,-16);
          scale = 4;
          fill_octahedron(shift, scale, mat);

          shift = TVec3f(0,-4,-16);
          scale = 4;
          fill_dodecahedron(shift,scale,mat);
      }

   }

  ~SimpleScene(){

      for (int i=0;i<objects.size();i++){
          delete objects[i];
      }

      objects.clear();


  }

  TVec3f get_pixel(int x, int y, int w, int h);


};


#endif // RAY_TRACER_H
