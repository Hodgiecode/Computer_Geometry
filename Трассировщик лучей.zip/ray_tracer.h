#ifndef RAY_TRACER_H
#define RAY_TRACER_H
#define _USE_MATH_DEFINES

#include <QtCore>
#include <math.h>
#include <vector>
#include <algorithm>
#include <iostream>
#include <fstream>

struct TVec3f
{
  double x;
  double y;
  double z;

  TVec3f() { }
  TVec3f(double iX, double iY, double iZ) : x(iX), y(iY), z(iZ) { }

  TVec3f operator+(const TVec3f& v) const
  {
    return TVec3f(x + v.x, y + v.y, z + v.z);
  }

  TVec3f operator-(const TVec3f& v) const
  {
    return TVec3f(x - v.x, y - v.y, z - v.z);
  }

  double operator*(const TVec3f& v) const
  {
    return x * v.x + y * v.y + z * v.z;
  }

  TVec3f operator*(const double& f) const
  {
    return TVec3f(x * f, y * f, z * f);
  }

  double length() const
  {
    return sqrt(x * x + y * y + z * z);
  }

  void Normalize()
  {
    double l = length();
    if(l > 0)
    {
      x /= l;
      y /= l;
      z /= l;
    }
  }
};

void read(const char *filename, std::vector<TVec3f> &verts,
          std::vector<std::vector<int>> &faces);

inline TVec3f operator*(const double& f, const TVec3f& v)
{
  return v * f;
}


/*---------------------------------------*/

struct Material {
    double refractive_index = 1;
    double albedo_p1 = 1;
    double albedo_p2 = 0;
    double albedo_p3 = 0;
    double albedo_p4 = 0;
    double specular = 0;
    TVec3f color = TVec3f(0,0,0);
};

struct Light {
    TVec3f position;
    double intensity;
};

/*------------------------------*/


class TObject
{
protected:
   Material material;
public:
   TObject(const Material & mat) :  material(mat) { }

   const Material& get_material() const { return material; }

   virtual bool IsIntersect(const TVec3f& ray_src,
                            const TVec3f& ray_dir,
                            double& tau) = 0;

   virtual bool IsIntersect(const TVec3f& ray_src,
                            const TVec3f& ray_dir,
                            double& tau,
                            TVec3f& pt,
                            TVec3f& nl) = 0;

   ~TObject(){}
};


class TTriangle : public TObject
{

public:
    TVec3f A;
    TVec3f B;
    TVec3f C;

    double u,v;

    TTriangle(const TVec3f& iA, const TVec3f& iB, const TVec3f& iC, const Material& M) :
        TObject (M), A(iA), B(iB), C(iC)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);

    ~TTriangle(){}
};

class TSphere : public TObject
{

public:
    TVec3f center;
    double R;

    TSphere(const TVec3f& iC, const double R_, Material &M) :
        TObject (M), center(iC), R(R_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);
};

class TCone : public TObject
{

public:
    TVec3f center;
    double H;
    double R;

    TCone(const TVec3f& iC, const double H_, const double R_, const Material& mat) :
        TObject (mat), center(iC), H(H_), R(R_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);
};

class TCylinder : public TObject
{

public:
    TVec3f center_bottom;
    TVec3f center_top;
    double R;
    TVec3f center;
    TVec3f normal_;

    TCylinder(const TVec3f& iB, const TVec3f& iT, const double R_, const Material& mat) :
        TObject (mat), center_bottom(iB), center_top(iT), R(R_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);
};


class TTorus : public TObject
{

public:
    TVec3f center;
    TVec3f axis;
    TVec3f normal;
    double r, R;

    TTorus(const TVec3f& iC,  const double R1, const double R2, const TVec3f& axis_, const Material& mat) :
            TObject (mat), center(iC), r(R1), R(R2), axis(axis_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);
};

class TPlane : public TObject
{

public:
    TVec3f A;
    TVec3f B;
    TVec3f C;
    TVec3f D;
    TVec3f normal;

    TPlane(const TVec3f& A_,const TVec3f& B_,
           const TVec3f& C_,const TVec3f& D_, const Material& mat ) :
           TObject (mat), A(A_), B(B_), C(C_), D(D_)
    {

    }

    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau);


    virtual bool IsIntersect(const TVec3f& ray_src,
                             const TVec3f& ray_dir,
                             double& tau,
                             TVec3f& pt,
                             TVec3f& nl);

    bool inside(TVec3f &pt);
};

class SimpleScene{
protected:

  double Vw;
  double Vh;
  double Dist;

  int CCx, CCy;

  int Cw;
  int Ch;

public:
  std :: vector<TObject*> objects;
  std::vector<Light> light_vector;

  void fill_cube(TVec3f &A1, double &H, double &W, Material &mat_0, Material &mat_1){
      TVec3f B1 = TVec3f(A1.x + H, A1.y, A1.z);
      TVec3f C1 = TVec3f(B1.x, B1.y + H, B1.z);
      TVec3f D1 = TVec3f(A1.x, A1.y + H, A1.z);

      //правый бок
      TVec3f A2 = TVec3f(B1.x, B1.y, B1.z);
      TVec3f B2 = TVec3f(A2.x + W, A2.y + W, A2.z);
      TVec3f C2 = TVec3f(B2.x, B2.y + H, B2.z);
      TVec3f D2 = TVec3f(C1.x, C1.y, C1.z);

      //левый бок
      TVec3f A4 = TVec3f(A1.x, A1.y, A1.z);
      TVec3f B4 = TVec3f(A4.x + W, A4.y + W, A4.z);
      TVec3f C4 = TVec3f(B4.x, B4.y + H, B4.z);
      TVec3f D4 = TVec3f(D1.x, D1.y, D1.z);

      //вверх
      TVec3f A3 = TVec3f(D1.x, D1.y, D1.z);
      TVec3f B3 = TVec3f(C1.x, C1.y, C1.z);
      TVec3f C3 = TVec3f(B3.x + W, B3.y + W, B3.z);
      TVec3f D3 = TVec3f(D1.x + W, D1.y + W, D1.z);

      //задняя стенка
      TVec3f A6 = TVec3f(A1.x + W, A1.y + W, A1.z);
      TVec3f B6 = TVec3f(A6.x + H, A6.y, A6.z);
      TVec3f C6 = TVec3f(B6.x, B6.y + H, B6.z);
      TVec3f D6 = TVec3f(A6.x, A6.y + H, A6.z);

      //дно
      TVec3f A5 = TVec3f(A1.x, A1.y, A1.z);
      TVec3f B5 = TVec3f(B1.x, B1.y, B1.z);
      TVec3f C5 = TVec3f(B1.x + W, B1.y + W, B1.z);
      TVec3f D5 = TVec3f(A1.x + W, A1.y + W, A1.z);

      objects.push_back(new TPlane(A6, B6, C6, D6, mat_0));
      objects.push_back(new TPlane(A5, B5, C5, D5, mat_0));
      objects.push_back(new TPlane(A2, B2, C2, D2, mat_0));
      objects.push_back(new TPlane(A4, B4, C4, D4, mat_0));

      objects.push_back(new TPlane(A3, B3, C3, D3, mat_0));
      objects.push_back(new TPlane(A1, B1, C1, D1, mat_1));
  }

  SimpleScene(int W, int H, int M, std::string path) : Cw(W), Ch(H)
  {
      Vh = 1;
      Vw = double (Cw * Vh) / Ch; 1.0;

      Dist = 1;

      CCx = W / 2;
      CCy = H / 2;

      Material red, mat, glass, mirror;

      red.color = TVec3f(0.3, 0.1, 0.1);
      red.refractive_index = 1.0;
      red.albedo_p1 = 1.0;
      red.albedo_p2 = 0.0;
      red.albedo_p3 = 0.0;
      red.albedo_p4 = 0.0;
      red.specular =  0.0;

      mat.color = TVec3f(0.4, 0.4, 0.3);
      mat.refractive_index = 1.0;
      mat.albedo_p1 = 0.6;
      mat.albedo_p2 = 0.3;
      mat.albedo_p3 = 0.1;
      mat.albedo_p4 = 0.0;
      mat.specular = 50.0;

      mirror.color = TVec3f(1.0, 1.0, 1.0);
      mirror.refractive_index = 1.0;
      mirror.albedo_p1 = 0.0;
      mirror.albedo_p2 = 10.0;
      mirror.albedo_p3 = 0.8;
      mirror.albedo_p4 = 0.0;
      mirror.specular = 1425.0;

      glass.color = TVec3f(0.6, 0.7, 0.8);
      glass.refractive_index = 1.5;
      glass.albedo_p1 = 0.0;
      glass.albedo_p2 = 0.5;
      glass.albedo_p3 = 0.1;
      glass.albedo_p4 = 0.8;
      glass.specular = 125.0;

      /*--------------*/

      std::vector<TVec3f> verts;
      std::vector<std::vector<int>> faces;

       /*--------------*/

      if (M == 0){
          objects.push_back(new TSphere(TVec3f(0, 0, -16), 5, red));
      }

      if (M == 1){    

          read(path.c_str(), verts, faces);

          for (size_t i=0;i<faces.size();i++){
              int id_1 = faces[i][0] - 1;
              int id_2 = faces[i][1] - 1;
              int id_3 = faces[i][2] - 1;

              objects.push_back(new TTriangle(verts[id_1],
                                              verts[id_2],
                                              verts[id_3], mat));
          }

      }

      if (M == 2){
          objects.push_back(new TCone(TVec3f(0, -5.0, -16), 10, 5, red));
      }

      if (M == 3){
          objects.push_back(new TCylinder(TVec3f(0, 5, -16), TVec3f(0, -5, -16), 25, red));
      }

      if (M == 4){
          objects.push_back(new TTorus(TVec3f(0, 0, -16), 2, 5, TVec3f(-1, 0, -16), red));
      }

      if (M == 5){
          objects.push_back(new TCylinder(TVec3f(0, 5, -16), TVec3f(0, -5, -16), 25, mat));
          objects.push_back(new TSphere(TVec3f(6, 3, -16), 3, glass));
          objects.push_back(new TSphere(TVec3f(-2, -1, -16), 3, mirror));
          objects.push_back(new TCone(TVec3f(-6, -6.0, -16), 3, 3, red));
          objects.push_back(new TTorus(TVec3f(-6, 1, -16), 1.0, 2.5, TVec3f(-1, 0, -16), red));

          TVec3f A1 = TVec3f(3.5,-5.0,-16);
          double H = 3;
          double W = 1.5;
          fill_cube(A1, H, W, red, mat);
      }

      if (M == 6){
          TVec3f A1 = TVec3f(0,-3,-16);
          double H = 6;
          double W = 2;
          fill_cube(A1, H, W, red, mat);

          TVec3f A2 = TVec3f(-5,-6,-16);
          double H2 = 4;
          double W2 = 2;
          fill_cube(A2, H2, W2, red, mat);

      }

   }

  ~SimpleScene(){

      for (int i=0;i<objects.size();i++){
          delete objects[i];
      }

      objects.clear();


  }

  TVec3f get_pixel(int x, int y, int w, int h);


};


#endif // RAY_TRACER_H
