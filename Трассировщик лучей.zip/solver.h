#ifndef SOLVER_H
#define SOLVER_H

int  SolveP4(double *x,double a,double b,double c,double d);

#endif // SOLVER_H
