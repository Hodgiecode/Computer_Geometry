#include "ray_tracer.h"
#include "solver.h"
#include <math.h>
#include <QtCore>

void read(const char *filename, std::vector<TVec3f> &verts,
          std::vector<std::vector<int>> &faces){

    std::string m, x, y, z;
    std::ifstream fin(filename);
    std::vector<int> tmp;
    int scale = 1;

    fin >> x >> y >> z >> m;
    TVec3f pos = TVec3f(atof(x.c_str()) , atof(y.c_str()), atof(z.c_str()));
    scale = atoi(m.c_str());

    while (fin >> m >> x >> y >> z){
        if (m == "v"){
            TVec3f p = TVec3f(atof(x.c_str()) , atof(y.c_str()), atof(z.c_str()));
            p = scale * p + pos;
            verts.push_back(p);
        }

        if (m == "f"){
            tmp.push_back(atof(x.c_str()));
            tmp.push_back(atof(y.c_str()));
            tmp.push_back(atof(z.c_str()));

            faces.push_back(tmp);

            tmp.clear();
        }
    }
}

TVec3f crossProduct(TVec3f vect_A, TVec3f vect_B){
    TVec3f cross_P;
    cross_P.x = vect_A.y * vect_B.z - vect_A.z * vect_B.y;
    cross_P.y = vect_A.z * vect_B.x - vect_A.x * vect_B.z;
    cross_P.z = vect_A.x * vect_B.y - vect_A.y * vect_B.x;

    return cross_P;
}

TVec3f reflect(const TVec3f &i, const TVec3f &n){
    return i - n * 2.0 * (i * n);
}

TVec3f refract(const TVec3f &i, const TVec3f &n,
               const double eta_t,
               const double eta_i = 1.0){

    double cosi = (-1) * std::max(-1.0, std::min(1.0, i*n));

    if (cosi < 0){
        return refract(i, (-1) * n, eta_i, eta_t);
    }

    double eta = eta_i / eta_t;
    double k = 1 - eta * eta * (1 - cosi * cosi);

    if (k<0){
        return TVec3f(1,0,0);
    } else {
        return i * eta + n *(eta*cosi - std::sqrt(k));
    }
}



TVec3f cast_ray(const TVec3f &ray_src, const TVec3f &ray_dir,
                const std::vector<TObject *> &objects,
                const std::vector<Light> &lights,
                size_t depth = 0) {

    TVec3f pt, n;
    Material m;
    double t;

    if (depth>4){
         return TVec3f(0.2, 0.7, 0.8);
    }

    bool intersect_flag = false;
    for (int q=0;q<objects.size();q++){
         if (objects[q]->IsIntersect(ray_src, ray_dir, t, pt, n)){
            m = objects[q]->get_material();
            intersect_flag = true;
         }
    }


    if (intersect_flag == false){
        return TVec3f(0.2, 0.7, 0.8);
    }

    TVec3f reflect_dir = reflect(ray_dir, n);
    reflect_dir.Normalize();

    TVec3f refract_dir = refract(ray_dir, n, m.refractive_index);
    refract_dir.Normalize();

    TVec3f reflect_color = cast_ray(pt, reflect_dir, objects, lights, depth + 1);
    TVec3f refract_color = cast_ray(pt, refract_dir, objects, lights, depth + 1);

    double diffuse_light_intensity = 0;
    double specular_light_intensity = 0;

    for (size_t i = 0; i < lights.size(); i++){
        TVec3f light_dir = (lights[i].position - pt);
        light_dir.Normalize();

        TVec3f shadow_pt, shadow_nrm;
        Material shadow_mat;
        double shadow_t;

        bool shadow_intersect = false;

        for (int q=0;q<objects.size();q++){
             if (objects[q]->IsIntersect(pt, light_dir, shadow_t, shadow_pt, shadow_nrm)){
                shadow_mat = objects[q]->get_material();
                shadow_intersect = true;
                break;
             }
        }

        if (shadow_intersect == true){
            TVec3f t1 = shadow_pt - pt;
            TVec3f t2 = lights[i].position - pt;

            if (sqrt(t1.x * t1.x + t1.y * t1.y + t1.z * t1.z) < sqrt(t2.x * t2.x + t2.y * t2.y + t2.z * t2.z)){
                continue;
            }
        }

        diffuse_light_intensity  = diffuse_light_intensity + lights[i].intensity * std::max(0.0, light_dir * n);
        specular_light_intensity = specular_light_intensity + std::pow(std::max(0.0, (-1) * reflect((-1)*light_dir, n) * ray_dir),
                                             m.specular) * lights[i].intensity;
     }

    return m.color * diffuse_light_intensity * m.albedo_p1 + TVec3f(1.0, 1.0, 1.0) *
            specular_light_intensity * m.albedo_p2 + reflect_color * m.albedo_p3 +
            refract_color * m.albedo_p4;
}


TVec3f SimpleScene ::  get_pixel(int x, int y, int w, int h){    
    std::vector<Light> lv;
    Light l1, l2, l3;

    l1.position = TVec3f(-20, 20, 20);
    l1.intensity = 1.5;

    l2.position = TVec3f(30, 50, -25);
    l2.intensity = 1.8;

    l3.position = TVec3f(30, 20, 30);
    l3.intensity = 1.7;

    lv.push_back(l1);
    lv.push_back(l2);
    lv.push_back(l3);

    double fov = 3.14/3.0;
    double dir_x = (x+0.5)-w/2.0;
    double dir_y = -(y+0.5)+h/2.0;
    double dir_z =  -h/(2.0*tan(fov/2.0));

    TVec3f ray_dir = TVec3f(dir_x, dir_y, dir_z);
    ray_dir.Normalize();

    TVec3f c = cast_ray(TVec3f(0,0,0), ray_dir, objects, lv);

    double mx = std::max(c.x, std::max(c.y, c.z));
    if (mx > 1){
        c = c * (1.0 / mx);
    }

    c.x = 255 * std::max(0.0, std::min(1.0, c.x));
    c.y = 255 * std::max(0.0, std::min(1.0, c.y));
    c.z = 255 * std::max(0.0, std::min(1.0, c.z));

    return c;
 }

/*--------------- СФЕРЫ -----------------------------*/

bool TSphere :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau){

  TVec3f v = center - ray_src;
  double tca = v * ray_dir;
  double d2 = v * v - tca * tca;

  if (d2 > R * R){
      return false;
  }

  double thc = sqrt(R * R - d2);
  tau = tca - thc;

  double t1 = tca + thc;

  if (tau < 1e-3){
      tau = t1;
  }

  if (tau < 1e-3){
      return false;
  }

  return true;
}

bool TSphere :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl)
{
  if(IsIntersect(ray_src, ray_dir, tau))
  {
    pt = ray_src + tau * ray_dir;
    nl = pt - center;

    nl.Normalize();
    return true;
  }
  return false;
}

/*---------------- КОНУС  ----------------------------*/

bool TCone :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau){

    double eps = 1e-9;

    TVec3f top;
    top.x = center.x;
    top.y = center.y + H;
    top.z = center.z;

    double a = (ray_dir.x * ray_dir.x) + (ray_dir.z * ray_dir.z) - (R/H * R/H) * (ray_dir.y * ray_dir.y);
    double b = 2 *((ray_src.x - center.x) * ray_dir.x + (ray_src.z - center.z) * ray_dir.z -
                   (R/H) * (R/H) *(-H + ray_src.y - center.y) * ray_dir.y);

    double c = -(R/H)*(R/H) *(H - ray_src.y + center.y) * (H - ray_src.y + center.y) +
            (ray_src.x - center.x) * (ray_src.x - center.x) +
            (ray_src.z - center.z) * (ray_src.z - center.z);

    double delta = b*b - (4*a*c);
    if (fabs(delta)<eps){
        return false;
    }

    double t1 = (-b - sqrt(delta))/(2*a);
    double t2 = (-b + sqrt(delta))/(2*a);

    TVec3f pt = ray_src + t1 * ray_dir;
    if (pt.y >= center.y && pt.y <= center.y + H){
        tau = t1;
        return true;
    }

    pt = ray_src + t2 * ray_dir;
    if (pt.y >= center.y && pt.y <= center.y + H){
        tau = t2;
        return true;
    }

    return false;
}

bool TCone :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl){

    TVec3f top;
    top.x = center.x;
    top.y = center.y + H;
    top.z = center.z;

    double eps = 1e-9;

    if(IsIntersect(ray_src, ray_dir, tau)){
      TVec3f p = ray_src + tau * ray_dir;
      double r_ = sqrt((p.x - center.x) * (p.x - center.x) + (p.z - center.z) * (p.z - center.z));
      nl = TVec3f(p.x - center.x, r_*(R/H), p.z - center.z);
      nl.Normalize();

      return true;
    }

    return false;
}

/*---------------- ЦИЛИНДР ----------------------------*/

double cap_hit(TVec3f c, TVec3f N, TVec3f ray_src, TVec3f ray_dir, double r) {
    double t = -1;

    double ldotn = ray_dir * N;
    if (ldotn > 0) {
        t = ((c - ray_src)* N) / ldotn;
        TVec3f ip = ray_src + t * ray_dir;
        bool v = (ip - c)*(ip - c) < r*r;
        if (!v) {
            t = -1;
        }
    }

    return t;
}

bool TCylinder :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau){

    TVec3f h = center_top - center_bottom;
    TVec3f a_bottom = ray_src - center_bottom;
    TVec3f a_bottom_h = crossProduct(a_bottom, h);
    TVec3f ray_dir_h = crossProduct(ray_dir, h);

    double h2 = h * h;

    double a = ray_dir_h * ray_dir_h;
    double b = 2 * ray_dir_h * a_bottom_h;
    double c = a_bottom_h * a_bottom_h - (R * R - h2);
    double d = b * b - 4 * a * c;

    tau = -1;
    double t2;

    TVec3f ip;

    if (d>=0){
        tau = (-b - sqrt(d))/(2*a);
        t2 = (-b + sqrt(d))/(2*a);

        if (t2 < tau && t2 >= 0) {
            tau = t2;
        }

        if (tau >=0){
            ip = ray_src + tau * ray_dir;
            TVec3f h_ = center_top - center_bottom;
            bool v = h_ * (ip - center_bottom) > 0 && h_ * (ip - center_top) < 0;
            if (!v){
                tau = -1;
            }
        }
    }

    TVec3f v = ip - center_bottom;
    TVec3f tmp = (v * h * h);
    tmp.x = tmp.x / (h*h);
    tmp.y = tmp.y / (h*h);
    tmp.z = tmp.z / (h*h);

    normal_ = v - tmp;

    TVec3f ncap = center_top - center_bottom;
    double tcap = cap_hit(center_bottom, ncap, ray_src, ray_dir, R);

    if ((tcap >= 0 && tcap < tau) || tau < 0) {
        tau = tcap;
        normal_ = ncap;
    }

    ncap = (center_bottom - center_top);
    tcap = cap_hit(center_top, ncap, ray_src, ray_dir, R);

    if ((tcap >= 0 && tcap < tau) || tau < 0) {
        tau = tcap;
        normal_ = ncap;
    }

    if (tau < 0) {
        return false;
    }

    return true;
}

bool TCylinder :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl){

    if(IsIntersect(ray_src, ray_dir, tau))
    {
       pt = ray_src + tau * ray_dir;
       nl = normal_;
       nl.Normalize();

       return true;
    }

    return false;
}

/*------------------- ТОР ---------------------------*/

bool TTorus :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau){

    axis.Normalize();

    TVec3f e = ray_src - center;
    TVec3f d = ray_dir;

    d.Normalize();

    double iR = R * R - r * r;
    double oR = 4 * R * R;
    double L = (e.x * e.x + e.y * e.y + e.z * e.z) + iR;
    double e_dot_d = e * d;

    double c4 = pow(d.x * d.x + d.y * d.y + d.z * d.z, 2);
    double c3 = 4 * (d.x * d.x + d.y * d.y + d.z * d.z) * e_dot_d;
    double c2 = 2 * (2 * pow((e_dot_d), 2) + (d.x * d.x + d.y * d.y + d.z * d.z) * L) - oR * (pow(d.x,2) + pow(d.y,2));
    double c1 = 4 * e_dot_d * L - 2 * oR * (e.x * d.x + e.y * d.y);
    double c0 = pow(L,2) - oR * (pow(e.x,2) + pow(e.y, 2));

    double roots[4];
    int num_roots = SolveP4(roots, c3/c4, c2/c4, c1/c4, c0/c4);

    if (num_roots == 0){
      return false;
    }

    bool intersect = false;
    double min_t = DBL_MAX;

    for (int i = 0; i < num_roots; i++){
        double t = roots[i];
        if (t > 1e-5 && t < min_t){
            min_t = t;
            intersect = true;
        }
    }

    if (intersect == false){
        return false;
    }

    tau = min_t;
    return true;
}

bool TTorus :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl){

    if(IsIntersect(ray_src, ray_dir, tau))
    {
        pt = ray_src + tau * ray_dir;
        TVec3f p = pt - center;

        double cos_theta = (axis * p)/(sqrt(p.x * p.x + p.y * p.y + p.z * p.z));
        double sin_theta = sqrt(1 - cos_theta * cos_theta);

        TVec3f p_ = p;
        p_.Normalize();

        nl = p - R * (p_ - cos_theta * axis) * (1.0/sin_theta);
        nl = nl * (1.0 / r);
        nl.Normalize();

        return true;
    }

    return false;
}

/*------------------- ПЛОСКОСТИ ---------------*/
bool TPlane :: inside(TVec3f &pt){
    TVec3f ua = B - A;
    TVec3f ub = C - B;
    TVec3f uc = D - C;
    TVec3f ud = A - D;
    TVec3f va = pt - A;
    TVec3f vb = pt - B;
    TVec3f vc = pt - C;
    TVec3f vd = pt - D;

    double ka = (crossProduct(ua, va) * normal);
    double kb = (crossProduct(ub, vb) * normal);
    double kc = (crossProduct(uc, vc) * normal);
    double kd = (crossProduct(ud, vd) * normal);

    if (ka > 0 && kb > 0 && kc > 0 && kd > 0){
        return true;
    }

    if (ka < 0 && kb < 0 && kc < 0 && kd < 0){
        return true;
    }

    return false;
}

bool TPlane :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau){

    double eps = 1e-9;

    normal = crossProduct((C - B), (A - B));
    normal.Normalize();

    TVec3f vdif = A - ray_src;
    double d_dot_n = ray_dir * normal;
    if (fabs(d_dot_n) < eps){
        return false;
    }

    tau = (vdif * normal)/d_dot_n;
    if (tau < eps){
        return false;
    }

    TVec3f pt = ray_src + ray_dir * tau;
    if (inside(pt)){
        return true;
    }

    return false;
}

bool TPlane :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl){

    if(IsIntersect(ray_src, ray_dir, tau))
    {
       pt = ray_src + tau * ray_dir;
       nl = normal;
       return true;
    }

    return false;
}


/*------------ ТРЕУГОЛЬНИКИ ----------------------------------*/


bool TTriangle :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau){

    double eps = 1e-2;
    TVec3f e1 = B - A;
    TVec3f e2 = C - A;
    TVec3f p = crossProduct(ray_dir, e2);

    double det = e1 * p;
    if (det < eps){
        return false;
    }

    TVec3f tvec = ray_src - A;
    double u = tvec * p;

    if (u<0 || u>det){
        return false;
    }

    TVec3f qvec = crossProduct(tvec, e1);
    double v = ray_dir * qvec;

    if (v<0 || u + v > det){
        return false;
    }

    tau = e2 * qvec * (1.0/det);

    return tau > 1e-5;
}

bool TTriangle :: IsIntersect(const TVec3f& ray_src,
                        const TVec3f& ray_dir,
                        double& tau,
                        TVec3f& pt,
                        TVec3f& nl){

    if(IsIntersect(ray_src, ray_dir, tau))
    {
      pt = ray_src + tau * ray_dir;
      nl = crossProduct(B - A, C - A);
      nl.Normalize();
      return true;
    }

    return false;
}
