#include "task_data.h"

bool task_data :: testIntersection()
{

  double delta = (B.x - A.x) * (C.y - D.y) - (B.y - A.y) * (C.x - D.x);

  if(delta != 0) //// ха-ха
  {

    double lambda = ((C.x - A.x) * (C.y - D.y) - (C.y - A.y) * (C.x - D.x)) / delta;
    double mu = ((B.x - A.x) * (C.y - A.y) - (B.y - A.y) * (C.x - A.x)) / delta;

    if(lambda >= 0 && lambda <= 1 && mu >= 0 && mu <= 1)
    {
      this->ptIntersection = (1 - lambda) * A + lambda * B ;
      this->m_bIntFlag = true;
      return true;
    }
  }
  this->m_bIntFlag = false;
  return false;
}
