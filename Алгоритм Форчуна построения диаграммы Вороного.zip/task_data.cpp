#include <iostream>
#include <vector>
#include "task_data.h"
#include <algorithm>
#include <queue>
#include <cassert>

double point::a(double d){
    return 1/(2*(y-d));
}

double point::b(double d){
    return (2*x)/(2*(d-y));
}

double point::c(double d){
    return (x*x + y*y - d*d)/(2*(y-d));
}

bool point::liesWithinBoundingBox(double mnx, double mxx, double mny, double mxy){
    return mnx <= x && x <= mxx && mny <= y && y <= mxy;
}


double GrowingEdge::a(){
    return vy;
}

double GrowingEdge::b(){
    return -vx;
}


double GrowingEdge::c() {
    return -a()*x - b()*y;
}

double Edge::a(){
    return pnt2->y - pnt1->y;
}

double Edge::b(){
    return pnt1->x - pnt2->x;
}

double Edge::c(){
    return -a()*pnt1->x - b()*pnt1->y;
}


bool GrowingEdge::doesContainPoint(double a, double b){
    if (std::fabs(vy) < 1e-7){
        if (vx > 0) return a + 1e-7 >= x;
        else return a - 1e-7 <= x;
    }

    if (vy > 0) return b + 1e-7 >= y;
    else return b - 1e-7 <= y;
}

bool Edge::doesContainPoint(double a, double b){
    if (pnt1->x != pnt2->x && pnt1->y != pnt2->y)
        return std::min(pnt1->x, pnt2->x) <= a && a <= std::max(pnt1->x, pnt2->x)
        && std::min(pnt1->y, pnt2->y) <= b && b <= std::max(pnt1->y, pnt2->y);
    else if (pnt1->x != pnt2->x)
        return std::min(pnt1->x, pnt2->x) <= a && a <= std::max(pnt1->x, pnt2->x);
    else
        return std::min(pnt1->y, pnt2->y) <= b && b <= std::max(pnt1->y, pnt2->y);
}


std::pair<pedge, pedge> findGrowingEdges(double startx, double starty, ppoint a, ppoint b){
    pedge left = new GrowingEdge();
    pedge right = new GrowingEdge();

    left->x = right->x = startx;
    left->y = right->y = starty;

    left->vx = a->y - b->y;
    left->vy = b->x - a->x;

    right->vx = -left->vx;
    right->vy = -left->vy;

    if (left->vx > right->vx) std::swap(left, right);

    return { left, right };
}

std::pair<double, double> quadraticSolution(double a, double b, double c){
    if (fabs(a) < 1e-9){
        return { -c/b, -c/b };
    }

    double d = b*b - 4*a*c;

    assert(d >= 0);
    d = sqrt(d);
    d /= 2*a;

    if (d < 0) d = -d;

    double ans = -b/(2*a);

    return { ans-d, ans+d };
}

double TreapNode::leftBoundary(double d){
    if (!leftHyperbola()) return -1e18;

    if (fabs(d-focus->y) < 1e-6) { return focus->x; }

    if (fabs(d-leftHyperbola()->y) < 1e-6) { return leftHyperbola()->x; }

    std::pair<double, double> inters = quadraticSolution(focus->a(d) - leftHyperbola()->a(d), focus->b(d) - leftHyperbola()->b(d), focus->c(d) - leftHyperbola()->c(d));

    if (focus->y < leftHyperbola()->y) return inters.first;
    else return inters.second;
}

double TreapNode::rightBoundary(double d){
    if (!rightHyperbola()) return 1e18;

    if (fabs(d-focus->y) < 1e-6) { return focus->x; }

    if (fabs(d-rightHyperbola()->y) < 1e-6) { return rightHyperbola()->x; }

    std::pair<double, double> inters = quadraticSolution(focus->a(d) - rightHyperbola()->a(d), focus->b(d) - rightHyperbola()->b(d), focus->c(d) - rightHyperbola()->c(d));

    if (focus->y < rightHyperbola()->y) return inters.second;

    else return inters.first;
}

void TreapNode::updateDetails(){
    sz = 1;
    if (left) sz += left->sz, left->par = this;
    if (right) sz += right->sz, right->par = this;
}

int TreapNode::leftSubtreeSize(){
    if (!left) return 0;
    return left->sz;
}

double xCoordOfEdgeIntersection;
double yCoordOfEdgeIntersection;

std::pair<bool, double> TreapNode::edgeIntersection(){

    if (!leftEdge || !rightEdge) return { 0, 0.0 };

    double det = leftEdge->a()*rightEdge->b() - rightEdge->a()*leftEdge->b();

    if (std::fabs(det) < 1e-7) return { 0, 0.0 };

    double x = (leftEdge->b()*rightEdge->c() - rightEdge->b()*leftEdge->c()) / det;
    double y = (rightEdge->a()*leftEdge->c() - leftEdge->a()*rightEdge->c()) / det;

    if (!leftEdge->doesContainPoint(x, y) || !rightEdge->doesContainPoint(x, y)) return { 0, 0.0 };

    xCoordOfEdgeIntersection = x;
    yCoordOfEdgeIntersection = y;

    y -= hypot(x-focus->x, y-focus->y);
    return { 1, y };
}

bool edgeIntersection(pfulledge edge1, pfulledge edge2){
    if (!edge1 || !edge2) return 0;

    double det = edge1->a()*edge2->b() - edge2->a()*edge1->b();
    if (fabs(det) < 1e-7) return 0;

    double x = (edge1->b()*edge2->c() - edge2->b()*edge1->c()) / det;
    double y = (edge2->a()*edge1->c() - edge1->a()*edge2->c()) / det;

    if (!edge1->doesContainPoint(x, y) || !edge2->doesContainPoint(x, y)) return 0;

    xCoordOfEdgeIntersection = x;
    yCoordOfEdgeIntersection = y;
    return 1;
}

pnode leftmost(pnode a) {
    if (a->left) return leftmost(a->left);
    else return a;
}

pnode rightmost(pnode a){
    if (a->right) return rightmost(a->right);
    else return a;
}

void split(pnode a, pnode &left, pnode &right, int am){
    actualsplit(a, left, right, am);

    if (left && right){
        pnode r = rightmost(left);
        pnode l = leftmost(right);
        r->rightInBeachLine = l->leftInBeachLine = nullptr;
    }
}

void actualsplit(pnode a, pnode &left, pnode &right, int am){
    if (!a){
        left = right = nullptr;
        return;
    }

    if (a->leftSubtreeSize()+1 <= am){
        am -= a->leftSubtreeSize()+1;
        actualsplit(a->right, a->right, right, am);
        left = a;
        left->updateDetails();
    }

    else {
        actualsplit(a->left, left, a->left, am);
        right = a;
        right->updateDetails();
    }
}

void merge(pnode &a, pnode left, pnode right){
    if (left && right){
        pnode r = rightmost(left);
        pnode l = leftmost(right);
        r->rightInBeachLine = l;
        l->leftInBeachLine = r;
    }

    actualmerge(a, left, right);
}

void actualmerge(pnode &a, pnode left, pnode right){
    if (!left || !right){
        a = left ? left : right;
        return;
    }

    if (left->prior > right->prior){
        actualmerge(left->right, left->right, right);
        a = left;
    }
    else {
        actualmerge(right->left, left, right->left);
        a = right;
    }
    a->updateDetails();
}

std::pair<bool, int> findOnBeachLine(pnode a, double x, double d){
    double l = a->leftBoundary(d);
    double r = a->rightBoundary(d);

    if (fabs(x-l) < 1e-6) return { 0, a->leftSubtreeSize() };
    if (fabs(x-r) < 1e-6) return { 0, a->leftSubtreeSize() + 1 };
    if (l <= x && x <= r) return { 1, a->leftSubtreeSize() + 1 };
    else if (x < l)
    {
        return findOnBeachLine(a->left, x, d);
    }
    else {
        std::pair<bool, int> ans = findOnBeachLine(a->right, x, d);
        ans.second += a->leftSubtreeSize() + 1;
        return ans;
    }
}

int findIndexOnBeachLine(pnode a){
    int am = a->leftSubtreeSize() + 1;

    while (a->par){
        pnode par = a->par;
        if (par->right == a) am += par->leftSubtreeSize() + 1;
        a = par;
    }

    return am;
}

int findAmongEqualHeight(pnode a, double x){
    if (!a) return 0;
    if (a->focus->x > x) return findAmongEqualHeight(a->left, x);
    else return findAmongEqualHeight(a->right, x) + a->leftSubtreeSize()+1;
}

void pushEdgeIntersectionEvent(std::priority_queue<PqNode> &pq, pnode node){
    std::pair<bool, double> inter = node->edgeIntersection();
    if (!inter.first) return;

    PqNode* event = new PqNode();
    event->y = inter.second;
    event->siteEvent = 0;
    event->node = node;

    pq.push(*event);
}

std::pair<double, double> extendRayToInfinity(point p, pedge e){
    double x, y;
    if (fabs(e->vx) > fabs(e->vy)){
        double am;
        if (e->vx > 0) am = 1e10 - p.x;
        else am = -1e10 - p.x;
        double multam = am / e->vx;
        x = p.x + multam*e->vx;
        y = p.y + multam*e->vy;
    }
    else {
        double am;
        if (e->vy > 0) am = 1e10 - p.y;
        else am = -1e10 - p.y;
        double multam = am / e->vy;
        y = p.y + multam*e->vy;
        x = p.x + multam*e->vx;
    }
    return { x, y };
}

void Edge::increaseToInfinity(){
    if (pnt1 && pnt2) return;

    if (!pnt1 && !pnt2) {
        std::pair<double, double> a, b;

        a = extendRayToInfinity(point(edge1->x, edge1->y, -1), edge1);
        b = extendRayToInfinity(point(edge2->x, edge2->y, -1), edge2);

        pnt1 = new point(a.first, a.second, -1);
        pnt2 = new point(b.first, b.second, -1);
        return;
    }

    if (pnt2) std::swap(pnt1, pnt2), std::swap(edge1, edge2);

    pnt2 = new point(0, 0, -1);
    std::pair<double, double> coords = extendRayToInfinity(*pnt1, edge2);
    pnt2->x = coords.first;
    pnt2->y = coords.second;
}

bool Edge::encaseInBoundingBox(double mnx, double mxx, double mny, double mxy)
{
    increaseToInfinity();
    bool point1within = pnt1->liesWithinBoundingBox(mnx, mxx, mny, mxy);
    bool point2within = pnt2->liesWithinBoundingBox(mnx, mxx, mny, mxy);

    if (point1within && point2within) return 1;

    if (point2within) std::swap(pnt1, pnt2), std::swap(edge1, edge2), std::swap(point1within, point2within);

    if (point1within){
        pfulledge side = new Edge();
        side->pnt1 = new point(0, 0, -1);
        side->pnt2 = new point(0, 0, -1);
        side->pnt1->x = mxx, side->pnt2->x = mxx, side->pnt1->y = mny, side->pnt2->y = mxy;

        if (edgeIntersection(this, side)){
            pnt2->x = xCoordOfEdgeIntersection, pnt2->y = yCoordOfEdgeIntersection; return 1;
        }

        side->pnt1->x = mnx, side->pnt2->x = mnx, side->pnt1->y = mny, side->pnt2->y = mxy;

        if (edgeIntersection(this, side)){
            pnt2->x = xCoordOfEdgeIntersection, pnt2->y = yCoordOfEdgeIntersection; return 1;
        }

        side->pnt1->x = mnx, side->pnt2->x = mxx, side->pnt1->y = mny, side->pnt2->y = mny;

        if (edgeIntersection(this, side)){
            pnt2->x = xCoordOfEdgeIntersection, pnt2->y = yCoordOfEdgeIntersection; return 1;
        }

        side->pnt1->x = mnx, side->pnt2->x = mxx, side->pnt1->y = mxy, side->pnt2->y = mxy;

        if (edgeIntersection(this, side)){
            pnt2->x = xCoordOfEdgeIntersection, pnt2->y = yCoordOfEdgeIntersection; return 1;
        }

        assert(0);
        return 0;
    }
    else{
        std::vector<std::pair<double, double> > intersections;

        pfulledge side = new Edge();
        side->pnt1 = new point(0, 0, -1);
        side->pnt2 = new point(0, 0, -1);
        side->pnt1->x = mxx, side->pnt2->x = mxx, side->pnt1->y = mny, side->pnt2->y = mxy;

        if (edgeIntersection(this, side)){
            intersections.emplace_back(xCoordOfEdgeIntersection, yCoordOfEdgeIntersection);
        }

        side->pnt1->x = mnx, side->pnt2->x = mnx, side->pnt1->y = mny, side->pnt2->y = mxy;

        if (edgeIntersection(this, side)){
            intersections.emplace_back(xCoordOfEdgeIntersection, yCoordOfEdgeIntersection);
        }

        side->pnt1->x = mnx, side->pnt2->x = mxx, side->pnt1->y = mny, side->pnt2->y = mny;

        if (edgeIntersection(this, side)){
            intersections.emplace_back(xCoordOfEdgeIntersection, yCoordOfEdgeIntersection);
        }

        side->pnt1->x = mnx, side->pnt2->x = mxx, side->pnt1->y = mxy, side->pnt2->y = mxy;

        if (edgeIntersection(this, side)){
            intersections.emplace_back(xCoordOfEdgeIntersection, yCoordOfEdgeIntersection);
        }

        std::sort(intersections.begin(), intersections.end());
        intersections.erase(std::unique(intersections.begin(), intersections.end()), intersections.end());
        assert(intersections.size() < 3);

        if (intersections.size() == 2){
            pnt1->x = intersections[0].first;
            pnt1->y = intersections[0].second;
            pnt2->x = intersections[1].first;
            pnt2->y = intersections[1].second;
            return 1;
        }

        else return 0;
    }
}

void Edge::updateBorderingCells(){
    cell1->points.push_back(*pnt1);
    cell1->points.push_back(*pnt2);
    cell2->points.push_back(*pnt1);
    cell2->points.push_back(*pnt2);
}


point sortingpoint(0, 0, -1);

void VoronoiCell::sortPoints(){
    std::vector<point> left, right;
    for (auto a : points){
        if (a.x < pnt.x || (a.x == pnt.x && a.y < pnt.y)) left.push_back(a);
        else right.push_back(a);
    }

    sortingpoint = pnt;

    std::sort(left.begin(), left.end(), comp);
    std::sort(right.begin(), right.end(), comp);

    points.clear();
    for (auto a : right) points.push_back(a);
    for (auto a : left) points.push_back(a);
}

bool comp(point a, point b){
    return cross(a.x - sortingpoint.x, a.y - sortingpoint.y, b.x - sortingpoint.x, b.y - sortingpoint.y);
}

bool cross(double x, double y, double a, double b){
    return x*b - y*a > 0;
}

void updateFullEdge(pedge a, double x, double y){
    if (a->fullEdge->edge1 == a){
        a->fullEdge->pnt1 = new point(x, y, -1);
    }
    else
    {
        a->fullEdge->pnt2 = new point(x, y, -1);
    }
}

void sameHeightCreateEdges(pnode a, pnode b, double mxhei, std::vector<pfulledge> &edges){
    if (a->rightEdge) a->rightEdge->fullEdge->edge1->vy = 1;

    if (b->leftEdge) b->leftEdge->fullEdge->edge1->vy = 1;

    pedge growingEdge = new GrowingEdge();
    growingEdge->x = (a->focus->x + b->focus->x)/2;
    growingEdge->y = 1e15;
    growingEdge->vx = 0;
    growingEdge->vy = -1;

    pfulledge fullEdge = new Edge();
    fullEdge->edge1 = growingEdge;
    fullEdge->pnt2 = new point(growingEdge->x, 1e15, -1);
    fullEdge->cell1 = a->cell;
    fullEdge->cell2 = b->cell;
    growingEdge->fullEdge = fullEdge;
    edges.push_back(fullEdge);

    a->rightEdge = b->leftEdge = growingEdge;
}

void VoronoiDiagram::addPoint(double x, double y){
    pcell closest = nullptr;
    double dis = 1e18;
    for (auto cell : cells){
        double d = hypot(cell->pnt.x - x, cell->pnt.y - y);
        if (d < dis) dis = d, closest = cell;
    }
    closest->points.push_back(point(x, y, -1));
}

VoronoiDiagram* makeVoronoi(int n, std::vector<point> vp, double mnx, double mxx, double mny, double mxy){
    VoronoiDiagram* diagram = new VoronoiDiagram(mnx, mxx, mny, mxy);
    std::vector<pfulledge> edges;

    std::priority_queue<PqNode> pq;
    for (int i = 0; i < n; i++)
    {
        PqNode* a = new PqNode();
        a->siteEvent = 1;
        a->pnt = new point(vp[i].x, vp[i].y, -1);
        a->y = vp[i].y;
        pq.push(*a);
        diagram->points.push_back(*a->pnt);
    }

    pnode treap = nullptr;
    double mxhei;
    while (!pq.empty()){
        PqNode a = pq.top();
        pq.pop();

        if (a.siteEvent){
            if (!treap){
                mxhei = a.y;
                treap = new TreapNode();
                treap->focus = a.pnt;
                treap->updateDetails();
                treap->cell = new VoronoiCell(a.pnt);
                diagram->cells.push_back(treap->cell);
                continue;
            }
            else if (mxhei-a.y < 1e-3){
                int loc = findAmongEqualHeight(treap, a.pnt->x);
                pnode newmid = new TreapNode();
                newmid->focus = a.pnt;
                newmid->cell = new VoronoiCell(a.pnt);
                diagram->cells.push_back(newmid->cell);
                pnode left, right;
                split(treap, left, right, loc);

                if (left){
                    sameHeightCreateEdges(rightmost(left), newmid, mxhei, edges);
                }

                if (right){
                    sameHeightCreateEdges(newmid, leftmost(right), mxhei, edges);
                }


                merge(treap, left, newmid);
                merge(treap, treap, right);
                continue;
            }

            std::pair<bool, int> locOnBeachLine = findOnBeachLine(treap, a.pnt->x, a.y);
            int loc = locOnBeachLine.second;
            if (!locOnBeachLine.first){

                pnode left, right;
                split(treap, left, right, loc);

                pnode last = rightmost(left);
                pnode fir = leftmost(right);

                double interx = a.pnt->x;
                double intery = last->focus->a(a.y)*interx*interx + last->focus->b(a.y)*interx + last->focus->c(a.y);

                updateFullEdge(last->rightEdge, interx, intery);

                pnode newmid = new TreapNode();
                newmid->focus = a.pnt;
                newmid->cell = new VoronoiCell(a.pnt);
                diagram->cells.push_back(newmid->cell);
                newmid->leftEdge = last->rightEdge = findGrowingEdges(interx, intery, a.pnt, last->focus).first;
                newmid->rightEdge = fir->leftEdge = findGrowingEdges(interx, intery, a.pnt, fir->focus).second;

                pfulledge fullEdge = new Edge();
                fullEdge->edge2 = newmid->leftEdge;
                fullEdge->pnt1 = new point(interx, intery, -1);
                fullEdge->cell1 = newmid->cell;
                fullEdge->cell2 = last->cell;
                newmid->leftEdge->fullEdge = fullEdge;
                edges.push_back(fullEdge);

                fullEdge = new Edge();
                fullEdge->edge2 = newmid->rightEdge;
                fullEdge->pnt1 = new point(interx, intery, -1);
                fullEdge->cell1 = newmid->cell;
                fullEdge->cell2 = fir->cell;
                newmid->rightEdge->fullEdge = fullEdge;
                edges.push_back(fullEdge);

                pushEdgeIntersectionEvent(pq, fir);
                pushEdgeIntersectionEvent(pq, last);

                merge(treap, left, newmid);
                merge(treap, treap, right);
                continue;
            }

            pnode left, mid, right;
            split(treap, left, right, loc);
            split(left, left, mid, loc-1);
            assert(mid->sz == 1);

            double interx = a.pnt->x;
            double intery = mid->focus->a(a.y)*interx*interx + mid->focus->b(a.y)*interx + mid->focus->c(a.y);

            std::pair<pedge, pedge> growingEdges = findGrowingEdges(interx, intery, a.pnt, mid->focus);
            pfulledge fullEdge = new Edge();
            fullEdge->edge1 = growingEdges.first;
            fullEdge->edge2 = growingEdges.second;

            growingEdges.first->fullEdge = growingEdges.second->fullEdge = fullEdge;
            fullEdge->cell1 = mid->cell;
            fullEdge->cell2 = new VoronoiCell(a.pnt);
            diagram->cells.push_back(fullEdge->cell2);
            edges.push_back(fullEdge);

            pnode newleft = new TreapNode();
            pnode newmid = new TreapNode();
            pnode newright = new TreapNode();

            newleft->focus = newright->focus = mid->focus;
            newleft->cell = newright->cell = mid->cell;

            newmid->focus = a.pnt;
            newmid->cell = fullEdge->cell2;

            newleft->leftEdge = mid->leftEdge;
            newright->rightEdge = mid->rightEdge;
            newleft->rightEdge = newmid->leftEdge = growingEdges.first;
            newright->leftEdge = newmid->rightEdge = growingEdges.second;

            mid->leftEdge = mid->rightEdge = nullptr;
            pushEdgeIntersectionEvent(pq, newleft);
            pushEdgeIntersectionEvent(pq, newmid);
            pushEdgeIntersectionEvent(pq, newright);

            merge(newleft, newleft, newmid);
            merge(newleft, newleft, newright);
            merge(treap, left, newleft);
            merge(treap, treap, right);
        }
        else {
            std::pair<bool, double> inter = a.node->edgeIntersection();
            if (inter != std::make_pair(true, a.y)) continue;

            updateFullEdge(a.node->leftEdge, xCoordOfEdgeIntersection, yCoordOfEdgeIntersection);
            updateFullEdge(a.node->rightEdge, xCoordOfEdgeIntersection, yCoordOfEdgeIntersection);

            pnode left = a.node->leftInBeachLine;
            pnode right = a.node->rightInBeachLine;

            double startx = xCoordOfEdgeIntersection;
            double starty = yCoordOfEdgeIntersection;

            std::pair<pedge, pedge> growingEdges = findGrowingEdges(startx, starty, left->focus, right->focus);

            pedge downwardsEdge;
            if (cross(a.node->leftEdge->vx, a.node->leftEdge->vy, growingEdges.first->vx, growingEdges.first->vy)
             == cross(a.node->leftEdge->vx, a.node->leftEdge->vy, a.node->rightEdge->vx, a.node->rightEdge->vy))
                downwardsEdge = growingEdges.first;
            else downwardsEdge = growingEdges.second;

            pfulledge fullEdge = new Edge();
            fullEdge->edge2 = downwardsEdge;
            fullEdge->pnt1 = new point(startx, starty, -1);
            fullEdge->cell1 = left->cell;
            fullEdge->cell2 = right->cell;

            downwardsEdge->fullEdge = fullEdge;
            edges.push_back(fullEdge);

            left->rightEdge = right->leftEdge = downwardsEdge;
            pushEdgeIntersectionEvent(pq, left);
            pushEdgeIntersectionEvent(pq, right);

            int loc = findIndexOnBeachLine(a.node);
            pnode treapLeft, treapMid, treapRight;
            split(treap, treapLeft, treapRight, loc);
            split(treapLeft, treapLeft, treapMid, loc-1);
            assert(treapMid->sz == 1);
            assert(treapMid == a.node);

            merge(treap, treapLeft, treapRight);
            a.node->leftEdge = a.node->rightEdge = nullptr;
        }
    }

    diagram->addPoint(mnx, mny);
    diagram->addPoint(mnx, mxy);
    diagram->addPoint(mxx, mny);
    diagram->addPoint(mxx, mxy);

    for (auto a : edges){
        if (a->encaseInBoundingBox(mnx, mxx, mny, mxy)) diagram->edges.push_back({ *a->pnt1, *a->pnt2 }), a->updateBorderingCells();
    }
    return diagram;
}

bool task_data::run(){
    int n = vector_of_points.size();
    double maxx, maxy, minx, miny;

    minx = INT_MAX;
    miny = INT_MAX;

    maxy = -1;
    maxx = -1;

    for (size_t i=0;i<n;i++){
       if (vector_of_points[i].x < minx){
          minx = vector_of_points[i].x;
       }

       if (vector_of_points[i].y < miny){
          miny = vector_of_points[i].y;
       }


       if (vector_of_points[i].x > maxx){
          maxx = vector_of_points[i].x;
       }

       if (vector_of_points[i].y > maxy){
          maxy = vector_of_points[i].y;
        }
    }

    auto diagram = makeVoronoi(n, vector_of_points, minx, maxx, miny, maxy);

    std::vector<point> tmp;
    for (auto a: diagram->edges){
        tmp.push_back(point(a.first.x, a.first.y, -1));
        tmp.push_back(point(a.second.x, a.second.y, -1));
        vector_of_edges.push_back(tmp);
        tmp.clear();
    }

    //граница
    tmp.push_back(point(minx, miny, -1));
    tmp.push_back(point(minx, maxy, -1));
    vector_of_edges.push_back(tmp);
    tmp.clear();

    tmp.push_back(point(minx, maxy, -1));
    tmp.push_back(point(maxx, maxy, -1));
    vector_of_edges.push_back(tmp);
    tmp.clear();

    tmp.push_back(point(maxx, maxy, -1));
    tmp.push_back(point(maxx, miny, -1));
    vector_of_edges.push_back(tmp);
    tmp.clear();

    tmp.push_back(point(maxx, miny, -1));
    tmp.push_back(point(minx, miny, -1));
    vector_of_edges.push_back(tmp);
    tmp.clear();

    return true;
}
