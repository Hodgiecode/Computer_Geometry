#include "drawwidget.h"
#include <QPainter>
#include <QMouseEvent>

const int circ_size = 20;

DrawWidget::DrawWidget(QWidget *parent) : QWidget(parent)
{
    pTask = 0;
    m_bMovePointFlag = false;
}


void DrawWidget::paintEvent(QPaintEvent *event){
    QPainter p(this);

    if(pTask){
        QPen penHLines(QColor("#8B0000"),3);
        p.setPen(penHLines);

        for (int i=0;i<pTask->vector_of_points.size();i++){
             p.drawArc(pTask->vector_of_points[i].x - circ_size / 2, pTask->vector_of_points[i].y - circ_size / 2, circ_size, circ_size, 0, 360 * 16);
        }

        QPen penHLines1(QColor("#000000"),3);
        p.setPen(penHLines1);

        for (int i=0;i<pTask->vector_of_edges.size();i++){
            p.drawLine(pTask->vector_of_edges[i][0].x, pTask->vector_of_edges[i][0].y,
                                pTask->vector_of_edges[i][1].x, pTask->vector_of_edges[i][1].y);
        }


        pTask->vector_of_edges.clear();

    }

}

void DrawWidget::SetDefaultPoints()
{
    int amount_of_points = 10;

    if(pTask){
        int w = width();
        int h = height();

        for (int i=0;i<amount_of_points;i++){
            pTask->vector_of_points.push_back( point(100+i*40,100+i*20,i));
        }

        repaint();
      }
}


void DrawWidget::voronoy(){
    pTask->run();
    repaint();
}

void DrawWidget::clean(){
    pTask->vector_of_points.clear();
    SetDefaultPoints();
}



void DrawWidget::mouseMoveEvent(QMouseEvent *event)
{
  if(m_bMovePointFlag)
  {
    for (int i=0;i<pTask->vector_of_points.size();i++){
       int id = pTask->vector_of_points[i].id;

       if(last_moved_point_id == id)
        {
          pTask->vector_of_points[i].x = event->x();
          pTask->vector_of_points[i].y = event->y();

          repaint();

          break;
        }
    }
  }
}

void DrawWidget::mousePressEvent(QMouseEvent *event)
{
   if(event->button() == Qt::LeftButton)
    {
      int XX = event->x();
      int YY = event->y();

       point v(XX, YY, -1);
       for (int i=0;i<pTask->vector_of_points.size();i++){

          if((v - pTask->vector_of_points[i]).length() < circ_size / 2){
              m_bMovePointFlag = true;
              last_moved_point_id = i;
              break;
          }
       }

    }
}

void DrawWidget::mouseReleaseEvent(QMouseEvent *event)
{
  m_bMovePointFlag = false;
}
