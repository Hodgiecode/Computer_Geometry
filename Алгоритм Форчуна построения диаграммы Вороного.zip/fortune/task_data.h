#ifndef TASK_DATA_H
#define TASK_DATA_H
#include <math.h>
#include <vector>

typedef struct point* ppoint;
typedef struct GrowingEdge* pedge;
typedef struct Edge* pfulledge;
typedef struct VoronoiCell* pcell;
typedef struct TreapNode* pnode;


struct point {
    double x;
    double y;
    double z;
    int id;

    point() {} //конструктор без параметров
    point(double x_, double y_, int id_): x(x_), y(y_), id(id_) {} //конструктор с параметрами

    double length() { return sqrt(x * x + y * y); }

    point operator+(const point& op) const
    {
        return point(x + op.x, y + op.y, -1);
    }

    point operator-(const point& op) const
    {
        return  point(x - op.x, y - op.y, -1);
    }

    double a(double d);
    double b(double d);
    double c(double d);

    bool liesWithinBoundingBox(double mnx, double mxx, double mny, double mxy);

};

inline point operator*(const double& t, const point& v){
  return point(t * v.x, t * v.y, -1);
}


/////////////////////////////////

struct GrowingEdge {
    double x, y;
    double vx, vy;
    pfulledge fullEdge;

    double a();
    double b();
    double c();

    bool doesContainPoint(double a, double b);
};

////////////////////////////////

struct Edge {
    pedge edge1 = nullptr, edge2 = nullptr;
    ppoint pnt1 = nullptr, pnt2 = nullptr;
    pcell cell1, cell2;

    void increaseToInfinity();
    bool encaseInBoundingBox(double mnx, double mxx, double mny, double mxy);
    void updateBorderingCells();

    double a();
    double b();
    double c();

    bool doesContainPoint(double a, double b);
};

/////////////////////////////////

struct TreapNode{
    ppoint focus;
    pnode left = nullptr, right = nullptr, par = nullptr;
    pedge leftEdge = nullptr, rightEdge = nullptr;
    pnode leftInBeachLine = nullptr, rightInBeachLine = nullptr;
    pcell cell;
    ppoint leftHyperbola() { return leftInBeachLine ? leftInBeachLine->focus : nullptr; };
    ppoint rightHyperbola() { return rightInBeachLine ? rightInBeachLine->focus : nullptr; };

    int sz = 1;
    int leftSubtreeSize();
    int prior;

    double leftBoundary(double d);
    double rightBoundary(double d);

    void updateDetails();

    std::pair<bool, double> edgeIntersection();

    TreapNode(){
        prior = rand();
    }
};

std::pair<pedge, pedge> findGrowingEdges(double startx, double starty, ppoint a, ppoint b);

//////////////////////////////////

struct PqNode {
    double y;
    bool siteEvent;
    double compy() const { return siteEvent ? y : y + 1e-3; }

    ppoint pnt;
    pnode node;

    bool operator<(const PqNode &o) const {
        return compy() < o.compy();
    }

    bool operator>(const PqNode &o) const {
        return compy() > o.compy();
    }
};

//////////////////////////////////

struct VoronoiCell {
    point pnt;
    std::vector<point> points;
    VoronoiCell(ppoint p) : pnt (*p) {}
    void sortPoints();
};

bool comp(point a, point b);


struct  VoronoiDiagram {
    std::vector<std::pair<point, point> > edges;
    std::vector<VoronoiCell*> cells;
    std::vector<point> points;
    double mnx, mxx, mny, mxy;

    VoronoiDiagram(double MNX, double MXX, double MNY, double MXY){
        mnx = MNX, mxx = MXX, mny = MNY, mxy = MXY;
    }

    void addPoint(double x, double y);
};

VoronoiDiagram* makeVoronoi(int n, std::vector<point> vp, double mnx, double mxx, double mny, double mxy);

bool edgeIntersection(pedge edge1, pedge edge2);

void split(pnode a, pnode &left, pnode &right, int am);
void actualsplit(pnode a, pnode &left, pnode &right, int am);
void merge(pnode &a, pnode left, pnode right);
void actualmerge(pnode &a, pnode left, pnode right);

bool cross(double x, double y, double a, double b);


struct task_data {
    std::vector<point> vector_of_points;
    std::vector<std::vector<point>> vector_of_edges;

    task_data(){

    }

    bool run();
};

#endif // TASK_DATA_H
