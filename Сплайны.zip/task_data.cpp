#include "task_data.h"

double lagrange_coeff(int i, int n, double t){
    double ret = 1.0;
    for(int q = 0; q < n; q++){
        if(q != i){
            ret = ret * ((t - q)/(i - q));
        }
    }

    return ret;
}


point lagrange_point_get(std::vector<point>&points, double t){
    point p(0, 0, -1);

    for (size_t i = 0; i < points.size(); i++){
        p = p + lagrange_coeff(i, points.size(), t) * points[i];
    }

    return p;
}

bool task_data::lagrange_spline(){
    int n = vector_of_points.size();
    int curve_points_num = 4096 * n;

    double step = (double(n - 1))/(curve_points_num - 1);

    curve.resize(curve_points_num);

    for(size_t q=0; q < curve.size(); q++){
        curve[q] = lagrange_point_get(vector_of_points, step * q);
    }

    return true;
}

/*--------------------------------------------------*/
std::vector <double> new_parametr(std::vector <point>& c_points, int x){
    std::vector <double> tmp(c_points.size());
    tmp[0] = 0;
    for (int i = 1; i < c_points.size(); i++)
    {
        if (x == 0)
            tmp[i] = tmp[i - 1] + (c_points[i] - c_points[i - 1]).length();
        else tmp[i] = i;
    }

    return tmp;
}

std::vector <point> gauss_cubic(std::vector <double> &A,
                            std::vector <double> &B,
                            std::vector <double> &C,
                            std::vector <point> &D){

    for (size_t i = 2; i < D.size(); i++){
        B[i] = B[i] - C[i - 1] * (A[i] / B[i - 1]);
        D[i] = D[i] - D[i - 1] * (A[i] / B[i - 1]);
    }

    std::vector <point> X(D.size());
    X[D.size() - 1] = D[D.size() - 1] * (1/ B[D.size() - 1]);

    for (size_t i = D.size() - 2; i > 0; i--){
        X[i] = (D[i] - C[i] * X[i + 1]) * (1/ B[i]);
    }

    return X;
}

std::vector <point> coeff_cubic(std::vector <point>& c_points, std::vector <double> par_t){
    int sz = c_points.size();

    point null_elem(0,0,-1);
    std::vector <point> tmpSVec(sz), D(sz - 1);
    std::vector <double> A(sz - 1), B(sz - 1), C(sz - 1), X(sz), Y(sz);

    point a, b;

    for (size_t i = 1; i < sz - 1; i++){
        a = 6*((c_points[i + 1] - c_points[i]) *(1/ (par_t[i + 1] - par_t[i])));
        b = 6*((c_points[i] - c_points[i - 1]) *(1/ (par_t[i] - par_t[i - 1])));

        if (i > 1) {
            A[i - 1] = par_t[i] - par_t[i - 1];
        }

        B[i] = 2 * (par_t[i + 1] - par_t[i - 1]);
        C[i] = par_t[i + 1] - par_t[i];
        D[i] = a - b;
    }

    tmpSVec = gauss_cubic(A, B, C, D);

    tmpSVec.resize(sz);
    tmpSVec[sz - 1] = null_elem;
    tmpSVec[0] = null_elem;

    return tmpSVec;
}

point cubic_curve_point_get(std::vector <point>& c_points, double t,
                            std::vector <double> par_t,
                            std::vector <point>& S){

    point a, b, c, d, tmpSVec(0, 0,-1);
    double w, e;

    int i = 0;
    for (i = 0; i < par_t.size() - 1; i++){
        if (t >= par_t[i] && t <= par_t[i + 1]){
            w = (t - par_t[i]) / (par_t[i + 1] - par_t[i]);
            break;
        }
    }


    a = (1 - w) * c_points[i];
    b = w * c_points[i + 1];
    c = (-2 * w + 3 * w * w - w * w * w) * S[i];
    d = (-w + w * w *w) * S[i + 1];
    e = ((par_t[i + 1] - par_t[i]) * (par_t[i + 1] - par_t[i])) / 6;

    tmpSVec = a + b + (c + d) * e;

    return tmpSVec;
}

bool task_data::cubic_spline(){

    double t = 0.0;
    std::vector <double> parameter_t;
    std::vector <point> S;

    int n = vector_of_points.size();
    int curve_points_num = 128 * n;

    parameter_t = new_parametr(vector_of_points, 0);

    S = coeff_cubic(vector_of_points, parameter_t);

    double step = (parameter_t[parameter_t.size() - 1] - 1) / (curve_points_num - 1);
    curve.resize(curve_points_num);

    for(int q=0; q < curve_points_num; q++, t += step){
       curve[q] = cubic_curve_point_get(vector_of_points, t, parameter_t, S);
    }

    return true;
}

/*--------------------------------*/
point point_get(const std::vector<point>& points,
                const std::vector<double> &coeff,
                const std::vector<point> &tan,
                int param,
                double t){

  int k = -1;

  if (t >= coeff.back()){
     return points.back();
  }

  for(size_t i=0; i < coeff.size() - 1; i++){
    if (t >= coeff[i] && t < coeff[i + 1]){
        k = i;
    }
  }

  if(k < 0){
     throw 1;
  }

  double w = (t - coeff[k]) / (coeff[k + 1] - coeff[k]);

  double g0 = 1 - 3.0 * pow(w,2) + 2.0 * pow(w,3);
  double g1 = w - 2.0 * pow(w,2) + pow(w,3);

  double h0 = 3.0 * pow(w,2) - 2.0 * pow(w,3);
  double h1 = -pow(w,2) + pow(w,3);

  point p = g0 * points[k] + param * g1 * tan[k] +
          h0 * points[k + 1] + param * h1 * tan[k + 1];

  return p;
}

bool task_data::hermite_spline(){
    std::vector<double> coeff;
    std::vector<double> tmp;
    std::vector<point> tvectors;

    int n = vector_of_points.size();
    if (n < 2){
        return false;
    }

    coeff.resize(n);
    tmp.resize(n);
    tmp[0] = 0.0;

    for(size_t i = 1; i < n; i++) {
        tmp[i] = (vector_of_points[i] - vector_of_points[i-1]).length() + tmp[i-1];
    }

    coeff = tmp;

    if(coeff.empty()){
      return false;
    }

    int points_num = 100;
    int param = 100;

    double step = (coeff.back() - coeff.front()) / (points_num - 1);
    curve.resize(points_num);

    for (int i=0;i<coeff.size();i++){
        tvectors.push_back(point(1,0,-1));
    }

    for(size_t i = 0; i < points_num; i++){
        curve[i] = point_get(vector_of_points, coeff, tvectors, param, coeff[0] + (step * i));
    }


    return true;
}

/* ------------------------ */
std::vector<double>solve(const std::vector<double>&a,
                         const std::vector<double>&b,
                         const std::vector<double>&c,
                         const std::vector<double>&d){
    std::vector<double>mod_b;
    mod_b.resize(b.size());
    mod_b[0]=b[0];
    for(int q = 1; q < b.size();q++){
        mod_b[q] = b[q]-c[q-1]*a[q]/b[q-1];
    }
    std::vector<double>ret;
    ret.resize(a.size());
    ret.back()=d.back()/mod_b.back();
    for(int l = d.size()-2;l>=0;l--){
        ret[l]=(d[l]-c[l]*ret[l+1])/mod_b[l];
    }
    return ret;
}

point elastic_point_get(double t,
                        const std::vector<point>& points,
                        const std::vector<double> &t_vect,
                        const std::vector<point>& derivatives){
    int cnum=-1;
    if(t<0){
        return points.front();
    }

    if(t>=t_vect.back()){
        return points.back();
    }

    for(int q = 0; q < points.size()-1; q++){
        if(t>=t_vect[q] && t< t_vect[q+1]){
            cnum = q;
            break;
        }
    }
    double w = (t - t_vect[cnum])/(t_vect[cnum+1] - t_vect[cnum]);
    double g0 = 1 - 3.0*pow(w,2) + 2.0*pow(w,3);
    double g1 = w - 2.0*pow(w,2) + pow(w,3);
    double h0 = 3.0*pow(w,2) - 2.0*pow(w,3);
    double h1 = -pow(w,2) + pow(w,3);
    return points[cnum]*g0+g1*derivatives[cnum] + points[cnum+1]*h0+derivatives[cnum+1]*h1;
}


bool task_data::pseudo_spline(){
    std::vector<double> t_vect;
    t_vect.resize(vector_of_points.size());
    t_vect.front()=0;

    for(int q=1;q<t_vect.size();q++){
        t_vect[q] = t_vect[q-1] + (vector_of_points[q] - vector_of_points[q-1]).length();
    }

    std::vector<double> a, b, c, d, k, x_new,y_new;
    std::vector<point> derivatives;

    a.resize(vector_of_points.size());
    b.resize(vector_of_points.size());
    c.resize(vector_of_points.size());
    d.resize(vector_of_points.size());
    x_new.resize(vector_of_points.size());
    y_new.resize(vector_of_points.size());
    derivatives.resize(vector_of_points.size());

    k.resize(vector_of_points.size());

    a.front()=0;
    b.front()=2;
    c.back()=0;
    k.front()=0;
    k.back()=1;

    for(int q = 1; q < vector_of_points.size()-1;q++){
        k[q]=(t_vect[q] - t_vect[q-1])/(t_vect[q+1] - t_vect[q]);
    }

    c.front()=k[1];
    d.front()=3*(vector_of_points[1].x-vector_of_points[0].x);
    a.back()=1;
    b.back()=2;
    d.back()=3*(vector_of_points[vector_of_points.size()-1].x - vector_of_points[vector_of_points.size()-2].x);

    for(int q = 1;q < vector_of_points.size()-1;q++){
            a[q] = 1;
            b[q] = 2*(k[q]+k[q]*k[q]);
            c[q] = k[q]*k[q];
            d[q] = 3*(vector_of_points[q]-vector_of_points[q-1]).x+
                   3*(vector_of_points[q+1]-vector_of_points[q]).x*k[q]*k[q];
    }

   x_new = solve(a,b,c,d);

   for(int q = 0; q < vector_of_points.size();q++)
       derivatives[q].x=x_new[q];

    for(int q = 1;q < vector_of_points.size()-2;q++){
            d[q]=3*(vector_of_points[q]-vector_of_points[q-1]).y+
                 3*(vector_of_points[q+1]-vector_of_points[q]).y*k[q]*k[q];
    }

    y_new=solve(a,b,c,d);

    for(int q = 0; q < vector_of_points.size();q++)
        derivatives[q].y=y_new[q];

    int curve_points_num = 200;
    int n = vector_of_points.size();
    double step = (t_vect.back()-t_vect.front())/(curve_points_num - 1);

    curve.resize(curve_points_num);
    for(size_t q=0; q < curve_points_num; q++)
            curve[q] = elastic_point_get(step*q, vector_of_points, t_vect, derivatives);
    return true;
}
