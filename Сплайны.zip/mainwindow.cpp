#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->draw_widget->SetTaskPtr(&current_task);
    ui->draw_widget->SetDefaultPoints();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked(){
    ui->draw_widget->LagrangeSpline();
}

void MainWindow::on_pushButton_2_clicked(){
    ui->draw_widget->HermiteSpline();
}

void MainWindow::on_pushButton_3_clicked(){
    ui->draw_widget->CubicSpline();
}

void MainWindow::on_pushButton_4_clicked(){
    ui->draw_widget->PseudoElasticSpline();
}

void MainWindow::on_pushButton_5_clicked(){
    std::string p = ui->lineEdit->text().toStdString();

    if (p == ""){
        ui->draw_widget->points = 10;
        p = "10";
        QString v1 = QString::fromUtf8(p.c_str());
        ui->lineEdit->setText(v1);
    }

    ui->draw_widget->points = atoi(ui->lineEdit->text().toStdString().c_str());
    ui->draw_widget->create_points();
}
