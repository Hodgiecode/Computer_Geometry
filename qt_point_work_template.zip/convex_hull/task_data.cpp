#include "task_data.h"
#include <iostream>


bool task_data :: run()
{
   //здесь решаете задачу входные данные находятся в vector_of_points
   //обратится к элементу с номером i vector_of_points[i]
   //текущий размер вектора vector_of_points.size()
   //после того как решите задачу результирующие точки нужно положить в  result_vector

   //допустим задачу решили. Возьмем для примера что первые 5 точек решение задачи

   for (int i=0;i < 5;i++){
       result_vector.push_back(vector_of_points[i]);
   }

   //for (int i = 0; i < result_vector.size(); i++)
           //std::cout << "(" << result_vector[i].x << ", "
             //    << result_vector[i].y << ")\n";

    return true ;
}
