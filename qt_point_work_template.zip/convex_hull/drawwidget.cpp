#include "drawwidget.h"
#include <QPainter>
#include <QMouseEvent>
#include <iostream>

const int circ_size = 20;

DrawWidget::DrawWidget(QWidget *parent) : QWidget(parent)
{
    pTask = 0;
    m_bMovePointFlag = false;
}


void DrawWidget::paintEvent(QPaintEvent *event){
    QPainter p(this);

    if(pTask){
        //рисуем точки
        for (int i=0;i<pTask->vector_of_points.size();i++){
            p.drawArc(pTask->vector_of_points[i].x - circ_size / 2, pTask->vector_of_points[i].y - circ_size / 2, circ_size, circ_size, 0, 360 * 16);
        }

        //если что-то есть в result_vector (точки) выводим точки (соединяем линией соседние) и последнюю с первой
        int result_size = pTask->result_vector.size();
        for (int i=0;i < result_size;i++){
            if (i < result_size - 1){
                p.drawLine(pTask->result_vector[i].x, pTask->result_vector[i].y, pTask->result_vector[i+1].x, pTask->result_vector[i+1].y);
            } else {
                p.drawLine(pTask->result_vector[i].x, pTask->result_vector[i].y, pTask->result_vector[0].x, pTask->result_vector[0].y);
            }
        }

        //чистим за собой
        pTask->result_vector.clear();
    }

}

void DrawWidget::SetPoints(int amount_of_points)
{
    //первоначальное кол-во и положение точек. По хорошему можно сделать добавлять точку по клику,
    //но делать этого мы конечно не будем
    /*int amount_of_points = 10;*/


    if(pTask){
        int w = width();
        int h = height();

        pTask->vector_of_points.clear();

        for (int i=0; i<amount_of_points;i++){
            point p((i+1)*25 + 200,(i+1)*35, i); //у точки есть координаты и ее номер
            pTask->vector_of_points.push_back(p);
        }

        repaint();
      }
}

void DrawWidget::mouseMoveEvent(QMouseEvent *event)
{
  if(m_bMovePointFlag)
  {
    for (int i=0;i<pTask->vector_of_points.size();i++){
       int id = pTask->vector_of_points[i].id;

       if(last_moved_point_id == id) //у точки которую передвинули заменяем координаты
        {
          pTask->vector_of_points[i].x = event->x();
          pTask->vector_of_points[i].y = event->y();

          pTask->run();
          repaint();

          break;
        }
    }
  }
}

void DrawWidget::mousePressEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
    {
      int XX = event->x();
      int YY = event->y();

       point v(XX, YY, -1);
       //находим ту точку что последнюю двигали
       for (int i=0;i<pTask->vector_of_points.size();i++){

          if((v - pTask->vector_of_points[i]).length() < circ_size / 2){
              m_bMovePointFlag = true;
              last_moved_point_id = i;
              break;
          }
       }
    }

    if(event->button() == Qt::RightButton)
    {
      int XX = event->x();
      int YY = event->y();

      point v(XX, YY, pTask->vector_of_points.size());
      pTask->vector_of_points.push_back(v);
      repaint();
    }
}

void DrawWidget::mouseReleaseEvent(QMouseEvent *event)
{
  m_bMovePointFlag = false;
}
