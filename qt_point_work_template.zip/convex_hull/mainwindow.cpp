#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "drawwidget.h"
#include "QMessageBox"
#include <iostream>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->draw_widget->SetTaskPtr(&current_task);
    //ui->draw_widget->SetDefaultPoints();
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    QString amount_of_points = ui->lineEdit->text();
    //std::cout << amount_of_points.toInt() << std::endl;
    ui->draw_widget->SetPoints(amount_of_points.toInt());
}
